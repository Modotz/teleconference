import { TeleconfError, codeForStatus } from './errors';
import type { Attachment } from './types';

export interface HttpOptions {
  serverUrl: string;
  getToken: () => string | null;
  /** Called on a 401 for an authenticated request (token expired/revoked). */
  onUnauthorized: () => void;
}

type Query = Record<string, string | number | undefined | null>;

/** REST transport. Everything lives under `${serverUrl}/api`. */
export class Http {
  constructor(private readonly opts: HttpOptions) {}

  get serverUrl(): string {
    return this.opts.serverUrl;
  }

  async request<T>(
    method: 'GET' | 'POST' | 'DELETE',
    path: string,
    body?: unknown,
    query?: Query
  ): Promise<T> {
    const token = this.opts.getToken();
    let res: Response;
    try {
      res = await fetch(`${this.opts.serverUrl}/api${path}${toQuery(query)}`, {
        method,
        headers: {
          ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}),
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: body !== undefined ? JSON.stringify(body) : undefined,
      });
    } catch (err) {
      // fetch only rejects on network/CORS failure — see docs/troubleshooting.md.
      throw new TeleconfError(
        `Cannot reach ${this.opts.serverUrl} (${(err as Error).message}). ` +
          'Check the server URL and that CLIENT_ORIGIN allows this app.',
        'network'
      );
    }

    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      if (res.status === 401 && token) this.opts.onUnauthorized();
      throw new TeleconfError(
        data.error || `Request failed: ${res.status}`,
        codeForStatus(res.status, data.code),
        res.status
      );
    }
    return data as T;
  }

  get<T>(path: string, query?: Query) {
    return this.request<T>('GET', path, undefined, query);
  }
  post<T>(path: string, body: unknown = {}) {
    return this.request<T>('POST', path, body);
  }
  delete<T>(path: string) {
    return this.request<T>('DELETE', path);
  }

  /**
   * Upload one file (max 25 MB). Uses XHR so progress (0–100) can be reported.
   * The file is encrypted at rest on the server; the returned `url` is a
   * server path to pass along with a chat message.
   */
  upload(
    file: Blob,
    fileName?: string,
    onProgress?: (percent: number) => void
  ): Promise<Attachment> {
    const token = this.opts.getToken();
    const form = new FormData();
    const name = fileName ?? (file as File).name ?? 'file';
    form.append('file', file, name);

    return new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      xhr.open('POST', `${this.opts.serverUrl}/api/upload`);
      if (token) xhr.setRequestHeader('Authorization', `Bearer ${token}`);
      xhr.upload.onprogress = (e) => {
        if (e.lengthComputable) onProgress?.(Math.round((e.loaded / e.total) * 100));
      };
      xhr.onload = () => {
        let data: any = {};
        try {
          data = JSON.parse(xhr.responseText);
        } catch {
          /* non-JSON error page */
        }
        if (xhr.status >= 200 && xhr.status < 300) return resolve(data as Attachment);
        if (xhr.status === 401 && token) this.opts.onUnauthorized();
        reject(
          new TeleconfError(
            data.error || `Upload failed: ${xhr.status}`,
            codeForStatus(xhr.status),
            xhr.status
          )
        );
      };
      xhr.onerror = () => reject(new TeleconfError('Upload network error', 'network'));
      xhr.send(form);
    });
  }

  /**
   * Absolute URL for an attachment path. Attachments sit behind auth and
   * `<img>`/`<audio>` can't send headers, so the token rides as `?token=`.
   */
  fileUrl(path: string | null | undefined): string | null {
    if (!path) return null;
    if (/^https?:\/\//.test(path)) return path;
    const token = this.opts.getToken();
    const base = `${this.opts.serverUrl}${path}`;
    return token ? `${base}?token=${encodeURIComponent(token)}` : base;
  }

  /** Download an attachment as a Blob (sends the token as a header). */
  async download(path: string): Promise<Blob> {
    const token = this.opts.getToken();
    const res = await fetch(`${this.opts.serverUrl}${path}`, {
      headers: token ? { Authorization: `Bearer ${token}` } : {},
    });
    if (!res.ok) {
      throw new TeleconfError(`Download failed: ${res.status}`, codeForStatus(res.status), res.status);
    }
    return res.blob();
  }
}

function toQuery(q?: Query): string {
  if (!q) return '';
  const parts = Object.entries(q)
    .filter(([, v]) => v !== undefined && v !== null && v !== '')
    .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(String(v))}`);
  return parts.length ? `?${parts.join('&')}` : '';
}
