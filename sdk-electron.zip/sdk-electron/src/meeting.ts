import type { Socket } from 'socket.io-client';
import { Emitter } from './emitter';
import { TeleconfError } from './errors';
import type { Http } from './http';
import { openSocket, request, waitConnected } from './realtime';
import {
  CAMERA_SIMULCAST,
  MIC_CODEC_OPTIONS,
  MIC_ENCODINGS,
  MediaSession,
  type MediaSource,
} from './media/session';
import type { LocalMediaOptions, MediaDevicesHelper } from './media/devices';
import type {
  Attachment,
  BreakoutRoom,
  ConnectionQuality,
  MeetingChatMessage,
  Poll,
  Question,
  Session,
  WhiteboardStroke,
} from './types';

export type MeetingState = 'idle' | 'joining' | 'lobby' | 'joined' | 'reconnecting' | 'left';

/** Why `left` fired. */
export type LeaveReason =
  | 'left' // you called leave()
  | 'ended' // the host ended the meeting
  | 'kicked' // a moderator removed you
  | 'moved' // moveTo() — e.g. into a breakout room
  | 'error'; // connection lost for good / rejoin failed

export interface Participant {
  peerId: string;
  displayName: string;
  isHost: boolean;
  isCoHost: boolean;
  micEnabled: boolean;
  cameraEnabled: boolean;
  handRaised: boolean;
  raisedAt: string | null;
  quality: ConnectionQuality | null;
  audioTrack: MediaStreamTrack | null;
  videoTrack: MediaStreamTrack | null;
  screenVideoTrack: MediaStreamTrack | null;
  screenAudioTrack: MediaStreamTrack | null;
  /**
   * Camera + microphone in one stream — set it as a `<video>`'s srcObject
   * once. The object is stable; tracks are added/removed in place.
   */
  stream: MediaStream;
  /** Screen share (video + optional audio), or null when not sharing. */
  screenStream: MediaStream | null;
}

export interface LocalParticipant {
  peerId: string;
  userId: string;
  displayName: string;
  isHost: boolean;
  isCoHost: boolean;
  micEnabled: boolean;
  cameraEnabled: boolean;
  handRaised: boolean;
  quality: ConnectionQuality;
}

export interface JoinOptions {
  /** Name shown to others. Defaults to the account username. */
  displayName?: string;
  /** Meeting PIN, if the host set one. */
  pin?: string;
  /**
   * What to publish: a MediaStream you already have, device options for the
   * SDK to open, or `false` to join receive-only. Default: camera + mic.
   */
  media?: MediaStream | LocalMediaOptions | false;
  /** Join muted? Default true (mic on). */
  micEnabled?: boolean;
  /** Join with camera off? Default true (camera on). */
  cameraEnabled?: boolean;
  /**
   * Stop local tracks when leaving. Default: true when the SDK opened the
   * devices, false when you passed your own MediaStream.
   */
  stopMediaOnLeave?: boolean;
  /** Rejoin automatically after a network drop. Default true. */
  autoReconnect?: boolean;
  /** Apply moderator mute / camera-off requests automatically. Default true. */
  obeyModerator?: boolean;
  /** Send camera as 3 simulcast layers. Default true. */
  simulcast?: boolean;
  /** Measure uplink and share a good/ok/poor signal with peers. Default true. */
  reportQuality?: boolean;
}

export interface MeetingInfo {
  roomId: string;
  isBreakout: boolean;
  /** Set while inside a breakout room. */
  breakout: { name: string; mainRoomId: string } | null;
  locked: boolean;
  hasPin: boolean;
  /** Current PIN — only known to the host. */
  pin: string;
  /** Epoch ms the session started (first person joined). */
  startedAt: number;
}

export interface WaitingPeer {
  peerId: string;
  username: string;
}

export interface MeetingEvents {
  state: (state: MeetingState) => void;
  /** Waiting for a moderator to admit you. */
  lobby: () => void;
  /** In the meeting (also fires again after an automatic rejoin). */
  joined: () => void;
  participantJoined: (p: Participant) => void;
  participantLeft: (p: Participant) => void;
  /** Any change to a participant: tracks, mute state, name, role, hand, quality. */
  participantUpdated: (p: Participant) => void;
  track: (e: { participant: Participant; source: MediaSource; track: MediaStreamTrack }) => void;
  trackRemoved: (e: { participant: Participant; source: MediaSource; track: MediaStreamTrack }) => void;
  /** Loudest speaker's peerId (may be your own `self.peerId`), or null. */
  activeSpeaker: (peerId: string | null) => void;
  /** Your own state changed (mute, role, name, hand). */
  selfUpdated: (self: LocalParticipant) => void;
  /** A local track was replaced (device switch, camera re-opened). */
  localTrackChanged: (e: { kind: 'audio' | 'video'; track: MediaStreamTrack | null }) => void;
  chatMessage: (m: MeetingChatMessage) => void;
  reaction: (r: { peerId: string; displayName: string; emoji: string }) => void;
  handRaised: (h: { peerId: string; raised: boolean; raisedAt: string | null }) => void;
  caption: (c: { peerId: string; displayName: string; text: string; isFinal: boolean }) => void;
  pollAdded: (p: Poll) => void;
  pollUpdated: (p: Poll) => void;
  questionAdded: (q: Question) => void;
  questionUpdated: (q: Question) => void;
  whiteboardSegment: (s: WhiteboardStroke) => void;
  whiteboardCleared: () => void;
  lockChanged: (locked: boolean) => void;
  pinChanged: (hasPin: boolean) => void;
  hostChanged: (e: { hostPeerId: string }) => void;
  /** Lobby list changed (moderators only). */
  waitingListChanged: (list: WaitingPeer[]) => void;
  /** A moderator asked you to turn mic/camera on or off (already applied if obeyModerator). */
  moderatorRequest: (r: { kind: 'mic' | 'camera'; enabled: boolean }) => void;
  /** `myRoom` is where you were assigned (null for the host who opened them). */
  breakoutOpened: (e: { rooms: BreakoutRoom[]; myRoom: BreakoutRoom | null }) => void;
  /** Breakouts closed — call `moveTo(returnTo)` if you are in one. */
  breakoutClosed: (e: { returnTo: string }) => void;
  breakoutMessage: (text: string) => void;
  /** Your uplink quality changed. */
  quality: (level: ConnectionQuality) => void;
  /** Network dropped; the SDK is trying to rejoin. */
  disconnected: () => void;
  /** Back in after a drop (participants were rebuilt). */
  reconnected: () => void;
  left: (reason: LeaveReason) => void;
  error: (err: Error) => void;
}

/** Internal wiring handed over by TeleconfClient. */
export interface MeetingContext {
  serverUrl: string;
  http: Http;
  devices: MediaDevicesHelper;
  getSession: () => Session | null;
}

const QUALITY_INTERVAL = 4000;

/**
 * One meeting room. Create with `client.meetings.room(id)`, subscribe to
 * events, then `join()`.
 */
export class Meeting extends Emitter<MeetingEvents> {
  readonly roomId: string;
  state: MeetingState = 'idle';

  /** You. `peerId` is assigned on join. */
  self: LocalParticipant;
  /** Everyone else, by peerId. */
  readonly participants = new Map<string, Participant>();
  info: MeetingInfo;
  messages: MeetingChatMessage[] = [];
  polls: Poll[] = [];
  questions: Question[] = [];
  whiteboard: WhiteboardStroke[] = [];
  /** People waiting in the lobby (moderators only). */
  waitingList: WaitingPeer[] = [];
  breakout: { open: boolean; rooms: BreakoutRoom[]; myRoom: BreakoutRoom | null } = {
    open: false,
    rooms: [],
    myRoom: null,
  };
  activeSpeakerId: string | null = null;

  /** Your camera + mic. Tracks are swapped in place on device switches. */
  localStream: MediaStream | null = null;
  screenStream: MediaStream | null = null;

  private opts: Required<Omit<JoinOptions, 'media' | 'pin' | 'displayName' | 'stopMediaOnLeave'>> &
    Pick<JoinOptions, 'pin' | 'displayName'> & { stopMediaOnLeave: boolean } = {
    micEnabled: true,
    cameraEnabled: true,
    autoReconnect: true,
    obeyModerator: true,
    simulcast: true,
    reportQuality: true,
    stopMediaOnLeave: true,
  };
  private socket: Socket | null = null;
  private media: MediaSession | null = null;
  private mediaReady = false;
  private pendingProducers: Array<{ producerId: string; peerId: string; username: string }> = [];
  private leaving = false;
  private cancelLobby: ((err: Error) => void) | null = null;
  private qualityTimer: ReturnType<typeof setInterval> | null = null;
  private lastCameraId: string | undefined;
  private lastMicId: string | undefined;

  constructor(private readonly ctx: MeetingContext, roomId: string) {
    super();
    this.roomId = roomId;
    const user = ctx.getSession()?.user;
    this.self = {
      peerId: '',
      userId: user?.id ?? '',
      displayName: user?.username ?? '',
      isHost: false,
      isCoHost: false,
      micEnabled: true,
      cameraEnabled: true,
      handRaised: false,
      quality: 'good',
    };
    this.info = {
      roomId,
      isBreakout: roomId.includes('::bo::'),
      breakout: null,
      locked: false,
      hasPin: false,
      pin: '',
      startedAt: 0,
    };
  }

  /** Seconds since the meeting session started. */
  get elapsedSeconds(): number {
    return this.info.startedAt ? Math.max(0, Math.floor((Date.now() - this.info.startedAt) / 1000)) : 0;
  }

  get isModerator(): boolean {
    return this.self.isHost || this.self.isCoHost;
  }

  // ================================================================ lifecycle

  /**
   * Join the meeting. Resolves once you are in — if the room has a lobby this
   * waits (emitting `lobby`) until a moderator admits you.
   *
   * Rejects with TeleconfError code `locked`, `pin`, `denied`, `not-found`,
   * `breakout-closed`, or `unauthorized`.
   */
  async join(options: JoinOptions = {}): Promise<void> {
    if (this.state !== 'idle') throw new TeleconfError('join() can only be called once', 'bad-request');
    const session = this.ctx.getSession();
    if (!session) throw new TeleconfError('Sign in (or loginAsGuest) before joining', 'unauthorized');

    const { media: _media, ...settings } = options;
    const ownsMedia = !(options.media instanceof MediaStream);
    this.opts = {
      ...this.opts,
      ...stripUndefined(settings),
      stopMediaOnLeave: options.stopMediaOnLeave ?? ownsMedia,
    };
    if (options.displayName) this.self.displayName = options.displayName;
    this.self.micEnabled = this.opts.micEnabled;
    this.self.cameraEnabled = this.opts.cameraEnabled;
    this.setState('joining');

    try {
      // Open devices first so a permission prompt can't stall the handshake.
      if (options.media instanceof MediaStream) {
        this.localStream = options.media;
      } else if (options.media !== false) {
        const m = options.media ?? {};
        this.lastCameraId = m.cameraId;
        this.lastMicId = m.microphoneId;
        this.localStream = await this.ctx.devices.getLocalStream(m);
      }
      this.applyLocalEnabled();

      const socket = openSocket(this.ctx.serverUrl, session.token);
      this.socket = socket;
      this.bindLifecycle(socket);
      this.bindRoomEvents(socket);
      await waitConnected(socket);
      await this.handshake();
    } catch (err) {
      this.teardown();
      this.setState('left');
      throw err;
    }
  }

  /** Leave the meeting (others stay). For the host, see `endForAll()`. */
  async leave(): Promise<void> {
    this.finish('left');
  }

  /** Host only: end the meeting for everyone. */
  async endForAll(): Promise<void> {
    // The server broadcasts `meetingEnded` before it acks. Our handler for it
    // tears the socket down, which fails the pending ack — so a failed ack
    // after we have already left still means the meeting ended.
    this.leaving = true;
    try {
      await this.req('endRoom');
    } catch (err) {
      if ((this.state as MeetingState) === 'left') return;
      this.leaving = false; // e.g. not the host — still in the meeting
      throw err;
    }
    this.finish('ended');
  }

  /**
   * Move to another room keeping your camera/mic — used for breakout rooms
   * (`breakoutOpened.myRoom.boId`) and back (`breakoutClosed.returnTo`).
   * Returns the new Meeting; this one emits `left('moved')`.
   */
  async moveTo(roomId: string): Promise<Meeting> {
    const stream = this.localStream;
    const stopMedia = this.opts.stopMediaOnLeave;
    // Hand the tracks over instead of stopping them.
    this.opts.stopMediaOnLeave = false;
    const next = new Meeting(this.ctx, roomId);
    const { pin: _pin, ...rest } = this.opts;
    this.finish('moved');
    await next.join({
      ...rest,
      displayName: this.self.displayName,
      micEnabled: this.self.micEnabled,
      cameraEnabled: this.self.cameraEnabled,
      media: stream ?? false,
      stopMediaOnLeave: stopMedia,
    });
    return next;
  }

  // ============================================================ local media

  async setMicEnabled(enabled: boolean): Promise<void> {
    let track = this.localStream?.getAudioTracks()[0] ?? null;
    if (enabled && !track) {
      // Joined without a mic — open one now.
      const s = await this.ctx.devices.getLocalStream({ audio: true, video: false, microphoneId: this.lastMicId });
      track = s.getAudioTracks()[0];
      this.ensureLocalStream().addTrack(track);
      if (this.mediaReady) await this.produceMic(track);
      this.emit('localTrackChanged', { kind: 'audio', track });
    }
    if (track) track.enabled = enabled;
    const producer = this.media?.producers.get('mic');
    if (producer) enabled ? producer.resume() : producer.pause();
    this.self.micEnabled = enabled;
    this.socket?.emit('setMicState', { enabled });
    this.emit('selfUpdated', { ...this.self });
  }

  /**
   * Camera on/off. When the SDK owns the camera it is released while off
   * (the camera light goes out) and re-opened when turned back on.
   */
  async setCameraEnabled(enabled: boolean): Promise<void> {
    const producer = this.media?.producers.get('camera');
    let track = this.localStream?.getVideoTracks()[0] ?? null;

    if (enabled) {
      if (!track || track.readyState === 'ended') {
        const s = await this.ctx.devices.getLocalStream({ audio: false, video: true, cameraId: this.lastCameraId });
        const fresh = s.getVideoTracks()[0];
        if (track) this.localStream?.removeTrack(track);
        this.ensureLocalStream().addTrack(fresh);
        track = fresh;
        if (producer) await producer.replaceTrack({ track: fresh });
        else if (this.mediaReady) await this.produceCamera(fresh);
        this.emit('localTrackChanged', { kind: 'video', track: fresh });
      }
      track.enabled = true;
      producer?.resume();
    } else {
      producer?.pause();
      if (track) {
        track.enabled = false;
        if (this.opts.stopMediaOnLeave) {
          track.stop();
          this.localStream?.removeTrack(track);
          this.emit('localTrackChanged', { kind: 'video', track: null });
        }
      }
    }
    this.self.cameraEnabled = enabled;
    this.socket?.emit('setCamState', { enabled });
    this.emit('selfUpdated', { ...this.self });
  }

  toggleMic() {
    return this.setMicEnabled(!this.self.micEnabled);
  }
  toggleCamera() {
    return this.setCameraEnabled(!this.self.cameraEnabled);
  }

  /** Switch microphone without renegotiating. */
  async switchMicrophone(deviceId: string): Promise<void> {
    this.lastMicId = deviceId;
    const s = await this.ctx.devices.getLocalStream({ audio: true, video: false, microphoneId: deviceId });
    await this.swapLocalTrack('audio', s.getAudioTracks()[0]);
  }

  /** Switch camera without renegotiating. */
  async switchCamera(deviceId: string): Promise<void> {
    this.lastCameraId = deviceId;
    if (!this.self.cameraEnabled) return; // used next time the camera turns on
    const s = await this.ctx.devices.getLocalStream({ audio: false, video: true, cameraId: deviceId });
    await this.swapLocalTrack('video', s.getVideoTracks()[0]);
  }

  /**
   * Send a different video track as your camera (e.g. a virtual-background
   * canvas track). `localStream` is left untouched.
   */
  async setOutgoingVideoTrack(track: MediaStreamTrack): Promise<void> {
    const producer = this.media?.producers.get('camera');
    if (producer) await producer.replaceTrack({ track });
    else if (this.mediaReady) await this.produceCamera(track);
  }

  /**
   * Share a screen or window. In Electron pass `sourceId` from
   * `client.media.getScreenSources()` to skip the picker.
   */
  async startScreenShare(opts: { sourceId?: string; audio?: boolean; frameRate?: number } = {}): Promise<MediaStream> {
    if (this.screenStream) throw new TeleconfError('Already sharing', 'bad-request');
    this.requireJoined();
    const stream = await this.ctx.devices.getDisplayStream(opts);
    this.screenStream = stream;
    await this.publishScreen();
    stream.getVideoTracks()[0]?.addEventListener('ended', () => void this.stopScreenShare());
    return stream;
  }

  async stopScreenShare(): Promise<void> {
    if (!this.screenStream) return;
    this.media?.closeProducer('screen-video');
    this.media?.closeProducer('screen-audio');
    this.screenStream.getTracks().forEach((t) => t.stop());
    this.screenStream = null;
  }

  // ============================================================= in-meeting

  /** Send a chat message to the meeting, optionally with a file (max 25 MB). */
  async sendChat(
    content: string,
    opts: { file?: Blob; fileName?: string; attachment?: Attachment; onProgress?: (percent: number) => void } = {}
  ): Promise<void> {
    this.requireJoined();
    let attachment = opts.attachment;
    if (opts.file) attachment = await this.ctx.http.upload(opts.file, opts.fileName, opts.onProgress);
    if (!content.trim() && !attachment) return;
    this.socket!.emit('chatMessage', { content, attachment });
  }

  sendReaction(emoji: string): void {
    this.socket?.emit('reaction', { emoji });
  }

  async raiseHand(raised = true): Promise<void> {
    await this.req('raiseHand', { raised });
  }

  /** Rename yourself — works in the lobby and in the meeting. */
  async setDisplayName(name: string): Promise<void> {
    this.self.displayName = name;
    this.opts.displayName = name;
    if (this.state === 'lobby') this.socket?.emit('setLobbyName', { name });
    else if (this.state === 'joined') await this.req('setName', { name });
    this.emit('selfUpdated', { ...this.self });
  }

  /** Broadcast a live caption line (your own speech-to-text result). */
  sendCaption(text: string, isFinal: boolean): void {
    this.socket?.emit('caption', { text, isFinal });
  }

  // polls & Q&A
  createPoll(question: string, options: string[]) {
    return this.req('createPoll', { question, options });
  }
  votePoll(pollId: string, optionIndex: number): void {
    this.socket?.emit('votePoll', { pollId, optionIndex });
  }
  closePoll(pollId: string) {
    return this.req('closePoll', { pollId });
  }
  askQuestion(text: string): void {
    this.socket?.emit('askQuestion', { text });
  }
  /** Toggles your upvote. */
  upvoteQuestion(questionId: string): void {
    this.socket?.emit('upvoteQuestion', { questionId });
  }
  /** Moderators: toggle a question's answered flag. */
  toggleAnswered(questionId: string) {
    return this.req('answerQuestion', { questionId });
  }

  // whiteboard
  /**
   * Send a stroke or a stroke segment (same `id` = continue the stroke).
   * Points are normalized 0..1. Applied locally too.
   */
  drawWhiteboard(segment: WhiteboardStroke): void {
    this.mergeStroke(segment);
    this.socket?.emit('wbSegment', segment);
  }
  clearWhiteboard(): void {
    this.socket?.emit('wbClear');
  }

  // breakouts (moderators)
  openBreakouts(count: number) {
    return this.req('openBreakouts', { count });
  }
  closeBreakouts() {
    return this.req('closeBreakouts');
  }
  broadcastToBreakouts(text: string) {
    return this.req('broadcastBreakout', { text });
  }

  // ============================================================= moderation

  /** Ask a participant to mute (enabled=false) or unmute. */
  setParticipantMic(peerId: string, enabled: boolean) {
    return this.req('hostMute', { peerId, enabled });
  }
  setParticipantCamera(peerId: string, enabled: boolean) {
    return this.req('hostCam', { peerId, enabled });
  }
  muteAll() {
    return this.req('hostMuteAll');
  }
  kick(peerId: string) {
    return this.req('hostKick', { peerId });
  }
  /** Host only. */
  setCoHost(peerId: string, value: boolean) {
    return this.req('hostSetCoHost', { peerId, value });
  }
  /** Host only. */
  transferHost(peerId: string) {
    return this.req('transferHost', { peerId });
  }
  admit(peerId: string) {
    return this.req('admitPeer', { peerId });
  }
  admitAll() {
    return this.req('admitAll');
  }
  deny(peerId: string) {
    return this.req('denyPeer', { peerId });
  }
  /** Host only. Locked = nobody new can join. */
  setLocked(locked: boolean) {
    return this.req('setLock', { locked });
  }
  /** Host only. Empty string removes the PIN (lobby mode again). */
  async setPin(pin: string): Promise<string> {
    const res = await this.req<{ pin: string }>('setPin', { pin });
    this.info.pin = res.pin || '';
    return this.info.pin;
  }

  // =============================================================== internals

  private async handshake(): Promise<void> {
    const socket = this.socket!;
    let res = await request<any>(socket, 'joinRoom', {
      roomId: this.roomId,
      displayName: this.self.displayName,
      pin: this.opts.pin,
    });

    if (res?.inLobby) {
      this.setState('lobby');
      this.emit('lobby');
      await new Promise<void>((resolve, reject) => {
        const onAdmitted = () => done(resolve);
        const onDenied = () => done(() => reject(new TeleconfError('A moderator declined your request', 'denied')));
        const done = (fn: () => void) => {
          socket.off('admitted', onAdmitted);
          socket.off('denied', onDenied);
          this.cancelLobby = null;
          fn();
        };
        socket.on('admitted', onAdmitted);
        socket.on('denied', onDenied);
        this.cancelLobby = (err) => done(() => reject(err));
      });
      res = await request<any>(socket, 'finalizeJoin', {
        roomId: this.roomId,
        displayName: this.self.displayName,
      });
    }

    this.applySnapshot(res);
    this.media = new MediaSession(socket);
    await this.media.load(res.rtpCapabilities);
    await this.publishLocal();
    if (this.screenStream) await this.publishScreen();
    this.mediaReady = true;

    const queued = [...(res.existingProducers || []), ...this.pendingProducers];
    this.pendingProducers = [];
    for (const p of queued) await this.consumeSafe(p.producerId, p.peerId, p.username);

    this.setState('joined');
    this.emit('joined');
    this.startQuality();
  }

  private applySnapshot(res: any) {
    this.self.peerId = this.socket!.id ?? '';
    this.self.isHost = !!res.isHost;
    this.self.isCoHost = !!res.isCoHost;
    this.self.handRaised = false;
    this.info = {
      ...this.info,
      breakout: res.breakout ?? null,
      locked: !!res.locked,
      hasPin: !!res.hasPin,
      pin: res.pin || '',
      startedAt: res.startedAt || Date.now(),
    };
    this.messages = res.messages || [];
    this.polls = res.polls || [];
    this.questions = res.questions || [];
    this.whiteboard = res.whiteboard || [];
    this.waitingList = res.waitingList || [];
    this.breakout = {
      open: !!res.breakoutOpen,
      rooms: res.breakoutRooms || [],
      myRoom: null,
    };

    for (const p of res.peers || []) {
      const part = this.makeParticipant(p.peerId, p.username);
      part.micEnabled = p.micEnabled !== false;
      part.cameraEnabled = p.camEnabled !== false;
      part.isHost = !!p.isHost;
      part.isCoHost = !!p.isCoHost;
      this.participants.set(p.peerId, part);
      this.emit('participantJoined', part);
    }
    for (const h of res.raisedHands || []) {
      const part = this.participants.get(h.peerId);
      if (part) {
        part.handRaised = true;
        part.raisedAt = h.raisedAt ?? null;
      }
    }
    this.emit('selfUpdated', { ...this.self });
  }

  private bindLifecycle(socket: Socket) {
    socket.on('disconnect', (reason) => {
      this.stopQuality();
      if (this.leaving || this.state === 'left') return;
      if (reason === 'io server disconnect' || !this.opts.autoReconnect || this.state !== 'joined') {
        this.finish('error');
        return;
      }
      this.mediaReady = false;
      this.setState('reconnecting');
      this.emit('disconnected');
    });
    socket.on('connect', () => {
      if (this.state !== 'reconnecting') return;
      void this.rejoin();
    });
    socket.on('meetingEnded', () => {
      this.leaving = true;
      this.cancelLobby?.(new TeleconfError('The meeting has ended', 'not-found'));
      this.finish('ended');
    });
    socket.on('kicked', () => {
      this.leaving = true;
      this.finish('kicked');
    });
  }

  /** Server state is gone after a drop — rebuild media and roster from scratch. */
  private async rejoin() {
    this.media?.close();
    this.media = null;
    for (const p of Array.from(this.participants.values())) {
      this.participants.delete(p.peerId);
      this.emit('participantLeft', p);
    }
    try {
      await this.handshake();
      this.emit('reconnected');
    } catch (err) {
      this.emit('error', err as Error);
      this.finish('error');
    }
  }

  private bindRoomEvents(socket: Socket) {
    socket.on('peerJoined', ({ peerId, username, isHost, isCoHost }) => {
      const p = this.participants.get(peerId) ?? this.makeParticipant(peerId, username);
      p.displayName = username;
      p.isHost = !!isHost;
      p.isCoHost = !!isCoHost;
      const isNew = !this.participants.has(peerId);
      this.participants.set(peerId, p);
      this.emit(isNew ? 'participantJoined' : 'participantUpdated', p);
    });

    socket.on('peerLeft', ({ peerId }) => {
      const p = this.participants.get(peerId);
      if (!p) return;
      for (const c of Array.from(this.media?.consumed.values() ?? [])) {
        if (c.peerId === peerId) this.media?.dropProducer(c.producerId);
      }
      this.participants.delete(peerId);
      this.emit('participantLeft', p);
    });

    socket.on('newProducer', ({ producerId, peerId, username }) => {
      if (!this.mediaReady) {
        this.pendingProducers.push({ producerId, peerId, username });
        return;
      }
      void this.consumeSafe(producerId, peerId, username);
    });

    socket.on('producerClosed', ({ producerId }) => {
      const entry = this.media?.dropProducer(producerId);
      if (entry) this.detachTrack(entry.peerId, entry.source, entry.consumer.track);
    });

    socket.on('consumerClosed', ({ consumerId }) => {
      const entry = this.media?.dropConsumer(consumerId);
      if (entry) this.detachTrack(entry.peerId, entry.source, entry.consumer.track);
    });

    socket.on('activeSpeaker', ({ peerId }) => {
      this.activeSpeakerId = peerId ?? null;
      this.emit('activeSpeaker', this.activeSpeakerId);
    });

    socket.on('micState', ({ peerId, enabled }) => this.patch(peerId, { micEnabled: !!enabled }));
    socket.on('camState', ({ peerId, enabled }) => this.patch(peerId, { cameraEnabled: !!enabled }));
    socket.on('nameChanged', ({ peerId, name }) => this.patch(peerId, { displayName: name }));
    socket.on('peerQuality', ({ peerId, level }) => this.patch(peerId, { quality: level }));

    socket.on('handState', ({ peerId, raised, raisedAt }) => {
      if (peerId === this.self.peerId) {
        this.self.handRaised = !!raised;
        this.emit('selfUpdated', { ...this.self });
      } else {
        this.patch(peerId, { handRaised: !!raised, raisedAt: raisedAt ?? null });
      }
      this.emit('handRaised', { peerId, raised: !!raised, raisedAt: raisedAt ?? null });
    });

    socket.on('coHostState', ({ peerId, value }) => {
      if (peerId === this.self.peerId) {
        this.self.isCoHost = !!value;
        this.emit('selfUpdated', { ...this.self });
      } else {
        this.patch(peerId, { isCoHost: !!value });
      }
    });

    socket.on('hostChanged', ({ hostPeerId }) => {
      this.self.isHost = hostPeerId === this.self.peerId;
      if (this.self.isHost) this.self.isCoHost = false;
      for (const p of this.participants.values()) {
        const isHost = p.peerId === hostPeerId;
        if (p.isHost !== isHost) this.patch(p.peerId, { isHost, isCoHost: isHost ? false : p.isCoHost });
      }
      this.emit('selfUpdated', { ...this.self });
      this.emit('hostChanged', { hostPeerId });
    });

    socket.on('forceMic', ({ enabled }) => {
      if (this.opts.obeyModerator) void this.setMicEnabled(!!enabled);
      this.emit('moderatorRequest', { kind: 'mic', enabled: !!enabled });
    });
    socket.on('forceCam', ({ enabled }) => {
      if (this.opts.obeyModerator) void this.setCameraEnabled(!!enabled);
      this.emit('moderatorRequest', { kind: 'camera', enabled: !!enabled });
    });

    socket.on('waitingPeer', ({ peerId, username }) => {
      const rest = this.waitingList.filter((w) => w.peerId !== peerId);
      this.waitingList = [...rest, { peerId, username }];
      this.emit('waitingListChanged', this.waitingList);
    });
    socket.on('waitingPeerLeft', ({ peerId }) => {
      this.waitingList = this.waitingList.filter((w) => w.peerId !== peerId);
      this.emit('waitingListChanged', this.waitingList);
    });
    socket.on('waitingList', ({ list }) => {
      this.waitingList = list || [];
      this.emit('waitingListChanged', this.waitingList);
    });

    socket.on('lockState', ({ locked }) => {
      this.info.locked = !!locked;
      this.emit('lockChanged', !!locked);
    });
    socket.on('pinState', ({ hasPin }) => {
      this.info.hasPin = !!hasPin;
      this.emit('pinChanged', !!hasPin);
    });

    socket.on('chatMessage', (m: MeetingChatMessage) => {
      this.messages.push(m);
      this.emit('chatMessage', m);
    });
    socket.on('reaction', ({ peerId, username, emoji }) =>
      this.emit('reaction', { peerId, displayName: username, emoji })
    );
    socket.on('caption', ({ peerId, username, text, isFinal }) =>
      this.emit('caption', { peerId, displayName: username, text, isFinal: !!isFinal })
    );

    socket.on('pollAdded', (p: Poll) => {
      this.polls.push(p);
      this.emit('pollAdded', p);
    });
    socket.on('pollUpdated', (p: Poll) => {
      this.polls = this.polls.map((x) => (x.id === p.id ? p : x));
      this.emit('pollUpdated', p);
    });
    socket.on('questionAdded', (q: Question) => {
      this.questions.push(q);
      this.emit('questionAdded', q);
    });
    socket.on('questionUpdated', (q: Question) => {
      this.questions = this.questions.map((x) => (x.id === q.id ? q : x));
      this.emit('questionUpdated', q);
    });

    socket.on('wbSegment', (seg: WhiteboardStroke) => {
      this.mergeStroke(seg);
      this.emit('whiteboardSegment', seg);
    });
    socket.on('wbClear', () => {
      this.whiteboard = [];
      this.emit('whiteboardCleared');
    });

    socket.on('breakoutOpened', ({ rooms, assignments }) => {
      const mine = assignments?.[this.self.userId] ?? null;
      this.breakout = { open: true, rooms: rooms || [], myRoom: mine };
      this.emit('breakoutOpened', { rooms: this.breakout.rooms, myRoom: mine });
    });
    socket.on('breakoutClosed', ({ returnTo }) => {
      this.breakout = { open: false, rooms: [], myRoom: null };
      this.emit('breakoutClosed', { returnTo });
    });
    socket.on('breakoutMessage', ({ text }) => this.emit('breakoutMessage', text));
  }

  private async publishLocal() {
    const audio = this.localStream?.getAudioTracks()[0];
    const video = this.localStream?.getVideoTracks()[0];
    if (audio) await this.produceMic(audio);
    if (video && video.readyState === 'live') await this.produceCamera(video);

    // Peers assume "on" until told otherwise.
    const mic = this.media!.producers.get('mic');
    const cam = this.media!.producers.get('camera');
    if (mic && !this.self.micEnabled) mic.pause();
    if (cam && !this.self.cameraEnabled) cam.pause();
    this.socket!.emit('setMicState', { enabled: !!audio && this.self.micEnabled });
    this.socket!.emit('setCamState', { enabled: !!video && this.self.cameraEnabled });
  }

  private async produceMic(track: MediaStreamTrack) {
    await this.media!.produce('mic', track, { codecOptions: MIC_CODEC_OPTIONS, encodings: MIC_ENCODINGS });
  }

  private async produceCamera(track: MediaStreamTrack) {
    await this.media!.produce('camera', track, {
      encodings: this.opts.simulcast ? CAMERA_SIMULCAST : undefined,
      codecOptions: { videoGoogleStartBitrate: 1000 },
    });
  }

  private async publishScreen() {
    const s = this.screenStream;
    if (!s || !this.media) return;
    const v = s.getVideoTracks()[0];
    const a = s.getAudioTracks()[0];
    if (v) await this.media.produce('screen-video', v);
    if (a) await this.media.produce('screen-audio', a);
  }

  private async swapLocalTrack(kind: 'audio' | 'video', track: MediaStreamTrack) {
    const stream = this.ensureLocalStream();
    const old = kind === 'audio' ? stream.getAudioTracks()[0] : stream.getVideoTracks()[0];
    track.enabled = kind === 'audio' ? this.self.micEnabled : this.self.cameraEnabled;
    const producer = this.media?.producers.get(kind === 'audio' ? 'mic' : 'camera');
    if (producer) await producer.replaceTrack({ track });
    else if (this.mediaReady) await (kind === 'audio' ? this.produceMic(track) : this.produceCamera(track));
    if (old) {
      stream.removeTrack(old);
      if (this.opts.stopMediaOnLeave) old.stop();
    }
    stream.addTrack(track);
    this.emit('localTrackChanged', { kind, track });
  }

  private async consumeSafe(producerId: string, peerId: string, username: string) {
    try {
      const entry = await this.media?.consume(producerId, peerId);
      if (!entry) return;
      let p = this.participants.get(peerId);
      if (!p) {
        // Producer can arrive before peerJoined.
        p = this.makeParticipant(peerId, username);
        this.participants.set(peerId, p);
        this.emit('participantJoined', p);
      }
      const track = entry.consumer.track;
      switch (entry.source) {
        case 'mic':
        case 'mic-call':
          replaceIn(p.stream, p.audioTrack, track);
          p.audioTrack = track;
          break;
        case 'camera':
          replaceIn(p.stream, p.videoTrack, track);
          p.videoTrack = track;
          break;
        case 'screen-video':
          p.screenStream ??= new MediaStream();
          replaceIn(p.screenStream, p.screenVideoTrack, track);
          p.screenVideoTrack = track;
          break;
        case 'screen-audio':
          p.screenStream ??= new MediaStream();
          replaceIn(p.screenStream, p.screenAudioTrack, track);
          p.screenAudioTrack = track;
          break;
      }
      this.emit('track', { participant: p, source: entry.source, track });
      this.emit('participantUpdated', p);
    } catch (err) {
      this.emit('error', err as Error);
    }
  }

  private detachTrack(peerId: string, source: MediaSource, track: MediaStreamTrack) {
    const p = this.participants.get(peerId);
    if (!p) return;
    if (p.audioTrack === track) p.audioTrack = null;
    if (p.videoTrack === track) p.videoTrack = null;
    if (p.screenVideoTrack === track) p.screenVideoTrack = null;
    if (p.screenAudioTrack === track) p.screenAudioTrack = null;
    p.stream.removeTrack(track);
    p.screenStream?.removeTrack(track);
    if (p.screenStream && !p.screenVideoTrack && !p.screenAudioTrack) p.screenStream = null;
    this.emit('trackRemoved', { participant: p, source, track });
    this.emit('participantUpdated', p);
  }

  private makeParticipant(peerId: string, displayName: string): Participant {
    return {
      peerId,
      displayName,
      isHost: false,
      isCoHost: false,
      micEnabled: true,
      cameraEnabled: true,
      handRaised: false,
      raisedAt: null,
      quality: null,
      audioTrack: null,
      videoTrack: null,
      screenVideoTrack: null,
      screenAudioTrack: null,
      stream: new MediaStream(),
      screenStream: null,
    };
  }

  private patch(peerId: string, changes: Partial<Participant>) {
    const p = this.participants.get(peerId);
    if (!p) return;
    Object.assign(p, changes);
    this.emit('participantUpdated', p);
  }

  private mergeStroke(seg: WhiteboardStroke) {
    const existing = this.whiteboard.find((s) => s.id === seg.id);
    if (existing) existing.points.push(...(seg.points || []));
    else this.whiteboard.push({ ...seg, points: [...(seg.points || [])] });
  }

  private startQuality() {
    this.stopQuality();
    if (!this.opts.reportQuality) return;
    this.qualityTimer = setInterval(async () => {
      try {
        const s = await this.media?.uplinkStats();
        if (!s) return;
        const level: ConnectionQuality =
          s.loss >= 0.08 || s.rtt >= 0.5 ? 'poor' : s.loss >= 0.03 || s.rtt >= 0.25 ? 'ok' : 'good';
        if (level !== this.self.quality) {
          this.self.quality = level;
          this.socket?.emit('quality', { level });
          this.emit('quality', level);
        }
      } catch {
        /* transport closing */
      }
    }, QUALITY_INTERVAL);
  }

  private stopQuality() {
    if (this.qualityTimer) clearInterval(this.qualityTimer);
    this.qualityTimer = null;
  }

  private applyLocalEnabled() {
    this.localStream?.getAudioTracks().forEach((t) => (t.enabled = this.self.micEnabled));
    this.localStream?.getVideoTracks().forEach((t) => (t.enabled = this.self.cameraEnabled));
  }

  private ensureLocalStream(): MediaStream {
    this.localStream ??= new MediaStream();
    return this.localStream;
  }

  private requireJoined() {
    if (this.state !== 'joined') throw new TeleconfError('Not in the meeting', 'not-connected');
  }

  private req<T = any>(event: string, data?: unknown): Promise<T> {
    if (!this.socket) return Promise.reject(new TeleconfError('Not in the meeting', 'not-connected'));
    return request<T>(this.socket, event, data);
  }

  private finish(reason: LeaveReason) {
    if (this.state === 'left') return;
    this.leaving = true;
    this.cancelLobby?.(new TeleconfError('Left before being admitted', 'bad-request'));
    this.teardown();
    this.setState('left');
    this.emit('left', reason);
  }

  private teardown() {
    this.leaving = true;
    this.stopQuality();
    this.mediaReady = false;
    this.media?.close();
    this.media = null;
    if (this.socket) {
      this.socket.removeAllListeners();
      this.socket.disconnect();
      this.socket = null;
    }
    this.screenStream?.getTracks().forEach((t) => t.stop());
    this.screenStream = null;
    if (this.opts.stopMediaOnLeave) this.localStream?.getTracks().forEach((t) => t.stop());
  }

  private setState(state: MeetingState) {
    if (this.state === state) return;
    this.state = state;
    this.emit('state', state);
  }
}

function replaceIn(stream: MediaStream, old: MediaStreamTrack | null, next: MediaStreamTrack) {
  if (old) stream.removeTrack(old);
  stream.addTrack(next);
}

function stripUndefined<T extends object>(o: T): Partial<T> {
  return Object.fromEntries(Object.entries(o).filter(([, v]) => v !== undefined)) as Partial<T>;
}
