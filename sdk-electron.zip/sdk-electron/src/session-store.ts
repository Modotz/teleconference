import { getBridge } from './bridge';
import { TeleconfError } from './errors';
import type { Session } from './types';

/** Where the signed-in session (JWT + user) is persisted between app runs. */
export interface SessionStore {
  get(): Session | null | Promise<Session | null>;
  set(session: Session | null): void | Promise<void>;
}

/** Keeps the session for this run only — the user signs in on every launch. */
export function memorySessionStore(): SessionStore {
  let current: Session | null = null;
  return {
    get: () => current,
    set: (s) => {
      current = s;
    },
  };
}

/**
 * Renderer localStorage. Simple, but the JWT is stored in plain text in the
 * profile directory — prefer `electronSessionStore()` for production.
 */
export function localStorageSessionStore(key = 'teleconf.session'): SessionStore {
  return {
    get() {
      try {
        const raw = localStorage.getItem(key);
        return raw ? (JSON.parse(raw) as Session) : null;
      } catch {
        return null;
      }
    },
    set(s) {
      try {
        if (s) localStorage.setItem(key, JSON.stringify(s));
        else localStorage.removeItem(key);
      } catch {
        /* storage unavailable */
      }
    },
  };
}

/**
 * Encrypted with the OS keychain via Electron `safeStorage` in the main
 * process. Requires `setupTeleconfMain()` + the preload bridge.
 */
export function electronSessionStore(): SessionStore {
  const bridge = getBridge();
  if (!bridge) {
    throw new TeleconfError(
      'electronSessionStore() needs the preload bridge — see docs/electron-setup.md',
      'unsupported'
    );
  }
  return { get: () => bridge.session.get(), set: (s) => bridge.session.set(s) };
}
