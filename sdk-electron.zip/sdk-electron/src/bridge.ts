import type { Session } from './types';

/**
 * What `exposeTeleconfBridge()` (preload) puts on `window.teleconfBridge`.
 * Everything here crosses the context-isolation boundary via IPC to the
 * handlers installed by `setupTeleconfMain()` (main process).
 */
export interface ScreenSource {
  /** Pass to `meeting.startScreenShare({ sourceId })`. */
  id: string;
  name: string;
  /** PNG data URL thumbnail. */
  thumbnail: string;
  /** App icon (windows only), PNG data URL, if available. */
  appIcon: string | null;
  kind: 'screen' | 'window';
}

export interface TeleconfBridge {
  session: {
    get(): Promise<Session | null>;
    set(session: Session | null): Promise<void>;
  };
  screen: {
    getSources(opts?: { types?: Array<'screen' | 'window'>; thumbnailSize?: { width: number; height: number } }): Promise<ScreenSource[]>;
    /** Pick the source the next getDisplayMedia() call will receive. */
    select(sourceId: string): Promise<void>;
  };
  /** Subscribe to deep links (e.g. `teleconf://room/<id>`). Returns unsubscribe. */
  onDeepLink(cb: (url: string) => void): () => void;
  platform: string;
}

/** The preload bridge, or null when running without it (e.g. in a browser). */
export function getBridge(): TeleconfBridge | null {
  return ((globalThis as any).teleconfBridge as TeleconfBridge | undefined) ?? null;
}
