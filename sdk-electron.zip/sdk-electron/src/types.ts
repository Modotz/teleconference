/** Data models returned by the Teleconference server. Dates are ISO strings. */

export interface User {
  id: string;
  username: string;
  email?: string;
  createdAt?: string;
  /** Guest sessions (join-by-name) — can join meetings only. */
  guest?: boolean;
  // Employee profile (filled from HR data; null until imported).
  fullName?: string | null;
  nik?: string | null;
  title?: string | null;
  division?: string | null;
  company?: string | null;
  site?: string | null;
  managerId?: string | null;
  photoUrl?: string | null;
  orgId?: string | null;
  /** e.g. ['staff'], ['manager'], ['pic_site'], ['hr_admin'], ['it_admin'] */
  roles?: string[];
  active?: boolean;
}

/** One signed-in device (`auth.sessions()`). */
export interface DeviceSession {
  id: string;
  deviceType: 'desktop' | 'mobile' | 'web';
  deviceName: string | null;
  createdAt: string;
  lastSeenAt: string;
  expiresAt: string;
  /** This device. */
  current: boolean;
}

export interface Session {
  token: string;
  user: User;
}

// ---------------------------------------------------------------- meetings

export interface Room {
  id: string;
  name: string;
  description: string | null;
  ownerId: string;
  owner?: { id: string; username: string };
  isActive: boolean;
  /** Set for scheduled meetings; null for instant ones. */
  scheduledAt: string | null;
  durationMinutes: number;
  createdAt: string;
  endedAt: string | null;
  _count?: { participants: number };
}

export interface CreateMeetingInput {
  name: string;
  description?: string;
  /** Date or ISO string. Omit for an instant meeting. */
  scheduledAt?: Date | string;
  /** 5–480, default 60. */
  durationMinutes?: number;
}

/** A meeting the current user joined (from GET /rooms/history). */
export interface MeetingHistoryEntry {
  id: string;
  name: string;
  isActive: boolean;
  endedAt: string | null;
  owner: { id: string; username: string } | null;
  lastJoinedAt: string;
  /** Distinct signed-in attendees (guests are not counted). */
  participantCount: number;
}

// -------------------------------------------------------------------- chat

export interface Attachment {
  /** Server path, e.g. `/uploads/<id>.bin`. Turn into a URL with `chat.attachmentUrl()`. */
  url: string;
  name: string;
  type: string;
  size: number;
}

export type MemberRole = 'owner' | 'admin' | 'member';

export interface ConversationMember {
  id: string;
  conversationId: string;
  userId: string;
  joinedAt: string;
  lastReadAt: string | null;
  lastDeliveredAt?: string | null;
  role: MemberRole;
  /** Set by a group admin: cannot send until then. */
  mutedByAdminUntil?: string | null;
  user: { id: string; username: string; fullName?: string | null; title?: string | null };
}

export interface ChatMessage {
  id: string;
  conversationId: string;
  senderId: string;
  /** Your own id for this message (idempotent resend). */
  clientId: string | null;
  /**
   * 'text', 'system' (e.g. "Andi added Rina" — see `data.event`), 'deleted'
   * (deleted for everyone), or an app-defined type (voice, location, card…)
   * carried in `data`.
   */
  type: string;
  content: string;
  data: unknown;
  attachmentUrl: string | null;
  attachmentName: string | null;
  attachmentType: string | null;
  attachmentSize: number | null;
  replyTo: {
    id: string;
    senderId: string;
    senderName: string | null;
    type: string;
    /** First 200 characters. */
    content: string;
    attachmentName: string | null;
  } | null;
  forwarded: boolean;
  /** userIds, or 'all'. */
  mentions: string[];
  /** One per person. */
  reactions: { userId: string; emoji: string }[];
  editedAt: string | null;
  deletedAt: string | null;
  createdAt: string;
  sender: { id: string; username: string; fullName?: string | null; title?: string | null } | null;
}

/** Per-member delivery / read state of one message. */
export interface MessageReceipt {
  user: { id: string; username: string; fullName?: string | null };
  status: 'sent' | 'delivered' | 'read';
  deliveredAt: string | null;
  readAt: string | null;
}

/** Your per-chat settings, shared by all your devices. */
export interface ChatPreferences {
  pinned: boolean;
  /** Muted until (ISO). A far-future date means "until unmuted". */
  mutedUntil: string | null;
  archived: boolean;
  markedUnread: boolean;
}

export interface Conversation {
  id: string;
  /** Group name; null for 1-on-1. Use `chat.titleOf()` for a display title. */
  name: string | null;
  description: string | null;
  isGroup: boolean;
  ownerId: string | null;
  /** 'chat' | 'announcement' | 'system' */
  type: string;
  /** HR-managed group: members cannot leave or be changed. */
  official: boolean;
  /** Announcement mode: only owner/admins may send. */
  onlyAdminsCanSend: boolean;
  pinnedMessageId: string | null;
  createdAt: string;
  updatedAt: string;
  members: ConversationMember[];
}

export interface ConversationSummary extends Conversation, ChatPreferences {
  /** When *you* last read this conversation. */
  lastReadAt: string | null;
  lastMessage: ChatMessage | null;
  /** Messages from others after lastReadAt. */
  unreadCount: number;
  /** unreadCount > 0, or you marked it unread. */
  hasUnread: boolean;
  /** Your role here. */
  myRole: MemberRole;
}

// ------------------------------------------------------------------- calls

export interface CallInvite {
  conversationId: string;
  fromUserId: string;
  fromUsername: string;
  conversation: {
    id: string;
    name: string | null;
    isGroup: boolean;
    members: { id: string; username: string }[];
  };
}

// --------------------------------------------------------- in-meeting data

export interface MeetingChatMessage {
  id: string;
  userId: string;
  /** Display name at send time. */
  username: string;
  content: string;
  attachmentUrl: string | null;
  attachmentName: string | null;
  attachmentType: string | null;
  attachmentSize: number | null;
  createdAt?: string;
}

export interface Poll {
  id: string;
  question: string;
  closed: boolean;
  options: { text: string; count: number }[];
}

export interface Question {
  id: string;
  text: string;
  authorName: string;
  upvotes: number;
  answered: boolean;
}

/** One whiteboard stroke (or a segment of one). Coordinates are normalized 0..1. */
export interface WhiteboardStroke {
  id: string;
  color: string;
  size: number;
  /** Eraser stroke. */
  erase: boolean;
  points: { x: number; y: number }[];
}

export interface BreakoutRoom {
  /** Join this id like any room: `client.meetings.room(boId).join()`. */
  boId: string;
  name: string;
}

export type ConnectionQuality = 'good' | 'ok' | 'poor';

// ------------------------------------------------- agenda & rooms (Tahap 2)

export type AgendaResponse = 'pending' | 'yes' | 'maybe' | 'no';

export interface AgendaAttendee {
  id: string;
  userId: string | null;
  email: string | null;
  optional: boolean;
  response: AgendaResponse;
  note: string | null;
  respondedAt: string | null;
}

export interface AgendaEvent {
  id: string;
  ownerId: string;
  kind: 'meeting' | 'activity';
  title: string;
  description: string | null;
  mode: 'online' | 'offline' | 'hybrid';
  /** Telepati meeting room — join with `client.meetings.room(roomId)`. */
  roomId: string | null;
  location: string | null;
  category: string | null;
  isPrivate: boolean;
  allDay: boolean;
  start: string;
  end: string;
  showAs: 'busy' | 'free';
  color: string | null;
  /** iCalendar RRULE as stored (expansion is up to the app for now). */
  recurrence: string | null;
  reminderMinutes: number | null;
  done: boolean;
  attendees: AgendaAttendee[];
  bookings: (RoomBooking & { room: { id: string; name: string; siteId: string } })[];
}

export interface AgendaEventInput {
  title: string;
  start: Date | string;
  end: Date | string;
  kind?: 'meeting' | 'activity';
  mode?: 'online' | 'offline' | 'hybrid';
  description?: string;
  location?: string;
  category?: string;
  isPrivate?: boolean;
  allDay?: boolean;
  showAs?: 'busy' | 'free';
  color?: string;
  recurrence?: string;
  reminderMinutes?: number;
  attendees?: { userId?: string; email?: string; optional?: boolean }[];
  /** Book this physical room for the same time (fails with `conflict` if taken). */
  bookableRoomId?: string;
  /** Use an existing Telepati room instead of creating one. */
  roomId?: string;
}

export interface Site {
  id: string;
  name: string;
  timezone: string;
}

export interface BookableRoom {
  id: string;
  siteId: string;
  name: string;
  type: 'meeting' | 'operational';
  capacity: number;
  facilities: string[];
  hasCamera: boolean;
  openFrom: string;
  openTo: string;
}

export interface RoomBooking {
  id: string;
  bookableRoomId: string;
  userId?: string;
  eventId: string | null;
  start: string;
  end: string;
  purpose?: string | null;
  note?: string | null;
}
