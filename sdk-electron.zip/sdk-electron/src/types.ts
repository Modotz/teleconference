/** Data models returned by the Teleconference server. Dates are ISO strings. */

export interface User {
  id: string;
  username: string;
  email?: string;
  createdAt?: string;
  /** Guest sessions (join-by-name) — can join meetings only. */
  guest?: boolean;
}

export interface Session {
  token: string;
  user: User;
}

// ---------------------------------------------------------------- meetings

export interface Room {
  id: string;
  name: string;
  description: string | null;
  ownerId: string;
  owner?: { id: string; username: string };
  isActive: boolean;
  /** Set for scheduled meetings; null for instant ones. */
  scheduledAt: string | null;
  durationMinutes: number;
  createdAt: string;
  endedAt: string | null;
  _count?: { participants: number };
}

export interface CreateMeetingInput {
  name: string;
  description?: string;
  /** Date or ISO string. Omit for an instant meeting. */
  scheduledAt?: Date | string;
  /** 5–480, default 60. */
  durationMinutes?: number;
}

/** A meeting the current user joined (from GET /rooms/history). */
export interface MeetingHistoryEntry {
  id: string;
  name: string;
  isActive: boolean;
  endedAt: string | null;
  owner: { id: string; username: string } | null;
  lastJoinedAt: string;
  /** Distinct signed-in attendees (guests are not counted). */
  participantCount: number;
}

// -------------------------------------------------------------------- chat

export interface Attachment {
  /** Server path, e.g. `/uploads/<id>.bin`. Turn into a URL with `chat.attachmentUrl()`. */
  url: string;
  name: string;
  type: string;
  size: number;
}

export interface ConversationMember {
  id: string;
  conversationId: string;
  userId: string;
  joinedAt: string;
  lastReadAt: string | null;
  user: { id: string; username: string };
}

export interface ChatMessage {
  id: string;
  conversationId: string;
  senderId: string;
  content: string;
  attachmentUrl: string | null;
  attachmentName: string | null;
  attachmentType: string | null;
  attachmentSize: number | null;
  createdAt: string;
  sender: { id: string; username: string } | null;
}

export interface Conversation {
  id: string;
  /** Group name; null for 1-on-1. Use `chat.titleOf()` for a display title. */
  name: string | null;
  isGroup: boolean;
  ownerId: string | null;
  createdAt: string;
  updatedAt: string;
  members: ConversationMember[];
}

export interface ConversationSummary extends Conversation {
  /** When *you* last read this conversation. */
  lastReadAt: string | null;
  lastMessage: ChatMessage | null;
  /** Last message is from someone else and newer than lastReadAt. */
  hasUnread: boolean;
}

// ------------------------------------------------------------------- calls

export interface CallInvite {
  conversationId: string;
  fromUserId: string;
  fromUsername: string;
  conversation: {
    id: string;
    name: string | null;
    isGroup: boolean;
    members: { id: string; username: string }[];
  };
}

// --------------------------------------------------------- in-meeting data

export interface MeetingChatMessage {
  id: string;
  userId: string;
  /** Display name at send time. */
  username: string;
  content: string;
  attachmentUrl: string | null;
  attachmentName: string | null;
  attachmentType: string | null;
  attachmentSize: number | null;
  createdAt?: string;
}

export interface Poll {
  id: string;
  question: string;
  closed: boolean;
  options: { text: string; count: number }[];
}

export interface Question {
  id: string;
  text: string;
  authorName: string;
  upvotes: number;
  answered: boolean;
}

/** One whiteboard stroke (or a segment of one). Coordinates are normalized 0..1. */
export interface WhiteboardStroke {
  id: string;
  color: string;
  size: number;
  /** Eraser stroke. */
  erase: boolean;
  points: { x: number; y: number }[];
}

export interface BreakoutRoom {
  /** Join this id like any room: `client.meetings.room(boId).join()`. */
  boId: string;
  name: string;
}

export type ConnectionQuality = 'good' | 'ok' | 'poor';
