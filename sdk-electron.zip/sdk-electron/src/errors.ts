/**
 * Every failure the SDK surfaces is a TeleconfError.
 *
 * `status` is the HTTP status for REST calls. `code` is a stable machine
 * string — branch on it rather than on `message`:
 *
 *   unauthorized    token missing/expired (the session is cleared)
 *   unverified      login before the email was verified
 *   forbidden       not allowed (e.g. guest calling an account-only API)
 *   not-found       room / conversation does not exist or is inactive
 *   locked          meeting is locked by the host
 *   pin             meeting needs a PIN (or the PIN was wrong)
 *   denied          a moderator declined the lobby request
 *   breakout-closed breakout room closed / not assigned to you
 *   timeout         the server did not answer in time
 *   not-connected   realtime connection is not up
 *   network         could not reach the server
 *   server          any other server-side error
 */
export type TeleconfErrorCode =
  | 'unauthorized'
  | 'unverified'
  | 'forbidden'
  | 'not-found'
  | 'conflict'
  | 'bad-request'
  | 'locked'
  | 'pin'
  | 'denied'
  | 'breakout-closed'
  | 'timeout'
  | 'not-connected'
  | 'network'
  | 'unsupported'
  | 'server';

export class TeleconfError extends Error {
  readonly code: TeleconfErrorCode;
  readonly status?: number;

  constructor(message: string, code: TeleconfErrorCode = 'server', status?: number) {
    super(message);
    this.name = 'TeleconfError';
    this.code = code;
    this.status = status;
  }
}

export function codeForStatus(status: number, serverCode?: string): TeleconfErrorCode {
  if (serverCode === 'unverified') return 'unverified';
  if (status === 400) return 'bad-request';
  if (status === 401) return 'unauthorized';
  if (status === 403) return 'forbidden';
  if (status === 404) return 'not-found';
  if (status === 409) return 'conflict';
  return 'server';
}

/** Map a socket acknowledgement error string to a TeleconfError. */
export function socketError(message: string): TeleconfError {
  switch (message) {
    case 'locked':
    case 'pin':
    case 'denied':
    case 'breakout-closed':
      return new TeleconfError(message, message);
    case 'Room not found or inactive':
    case 'Conversation not found':
    case 'No active call':
      return new TeleconfError(message, 'not-found');
    case 'Not a member':
    case 'Not allowed':
    case 'Not host':
      return new TeleconfError(message, 'forbidden');
    default:
      return new TeleconfError(message, 'server');
  }
}
