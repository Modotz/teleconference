/**
 * Every failure the SDK surfaces is a TeleconfError.
 *
 * `status` is the HTTP status for REST calls. `code` is a stable machine
 * string — branch on it rather than on `message` (server messages are
 * English and not meant for end users):
 *
 *   unauthorized    token missing/expired (the session is cleared)
 *   session-revoked this device was signed out (logout elsewhere, admin, deactivated)
 *   inactive        the account was deactivated
 *   unverified      login before the email was verified
 *   forbidden       not allowed (e.g. guest calling an account-only API)
 *   admins-only     only group admins can do this
 *   muted           a group admin muted you
 *   read-only       system / announcement conversation
 *   edit-window     the 15-minute edit window has passed
 *   not-found       room / conversation / message does not exist
 *   conflict        already exists / room already booked (see `details`)
 *   locked          meeting is locked by the host
 *   pin             meeting needs a PIN (or the PIN was wrong)
 *   denied          a moderator declined the lobby request
 *   breakout-closed breakout room closed / not assigned to you
 *   call-ended      the call ended (declined, cancelled) while connecting
 *   timeout         the server did not answer in time
 *   not-connected   realtime connection is not up
 *   network         could not reach the server
 *   server          any other server-side error
 */
export type TeleconfErrorCode =
  | 'unauthorized'
  | 'session-revoked'
  | 'inactive'
  | 'unverified'
  | 'forbidden'
  | 'admins-only'
  | 'muted'
  | 'read-only'
  | 'edit-window'
  | 'not-found'
  | 'conflict'
  | 'bad-request'
  | 'locked'
  | 'pin'
  | 'denied'
  | 'breakout-closed'
  | 'call-ended'
  | 'timeout'
  | 'not-connected'
  | 'network'
  | 'unsupported'
  | 'server';

export class TeleconfError extends Error {
  readonly code: TeleconfErrorCode;
  readonly status?: number;
  /** Extra data from the server, e.g. `{ bookedBy, start, end }` for a booking conflict. */
  readonly details?: Record<string, unknown>;

  constructor(message: string, code: TeleconfErrorCode = 'server', status?: number, details?: Record<string, unknown>) {
    super(message);
    this.name = 'TeleconfError';
    this.code = code;
    this.status = status;
    this.details = details;
  }
}

/** Server `code` values → SDK codes. */
const SERVER_CODES: Record<string, TeleconfErrorCode> = {
  unverified: 'unverified',
  inactive: 'inactive',
  session_revoked: 'session-revoked',
  admins_only: 'admins-only',
  muted_by_admin: 'muted',
  read_only: 'read-only',
  edit_window_passed: 'edit-window',
  room_conflict: 'conflict',
  official_group: 'forbidden',
  forbidden: 'forbidden',
  too_many: 'bad-request',
};

export function codeForStatus(status: number, serverCode?: string): TeleconfErrorCode {
  if (serverCode && SERVER_CODES[serverCode]) return SERVER_CODES[serverCode];
  if (status === 400 || status === 413) return 'bad-request';
  if (status === 401) return 'unauthorized';
  if (status === 403) return 'forbidden';
  if (status === 404) return 'not-found';
  if (status === 409) return 'conflict';
  return 'server';
}

/** Map a socket acknowledgement error to a TeleconfError. */
export function socketError(message: string, serverCode?: string): TeleconfError {
  if (serverCode && SERVER_CODES[serverCode]) return new TeleconfError(message, SERVER_CODES[serverCode]);
  switch (message) {
    case 'locked':
    case 'pin':
    case 'denied':
    case 'breakout-closed':
      return new TeleconfError(message, message);
    case 'Room not found or inactive':
    case 'Conversation not found':
    case 'No active call':
      return new TeleconfError(message, 'not-found');
    case 'Not a member':
    case 'Not allowed':
    case 'Not host':
      return new TeleconfError(message, 'forbidden');
    default:
      return new TeleconfError(message, 'server');
  }
}
