/** IPC channel names shared by the main-process helpers and the preload bridge. */
export const CHANNELS = {
  sessionGet: 'teleconf:session:get',
  sessionSet: 'teleconf:session:set',
  screenSources: 'teleconf:screen:sources',
  screenSelect: 'teleconf:screen:select',
  deepLink: 'teleconf:deeplink',
  deepLinkPending: 'teleconf:deeplink:pending',
} as const;
