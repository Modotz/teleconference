// Ready-made preload: `webPreferences.preload = require.resolve('@teleconf/electron-sdk/preload-script')`.
import { exposeTeleconfBridge } from './index';

exposeTeleconfBridge();
