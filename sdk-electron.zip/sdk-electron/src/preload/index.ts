/**
 * @teleconf/electron-sdk/preload — call from your preload script.
 *
 *   import { exposeTeleconfBridge } from '@teleconf/electron-sdk/preload';
 *   exposeTeleconfBridge();
 *
 * Exposes a narrow, typed API as `window.teleconfBridge` — never ipcRenderer
 * itself — so it is safe with contextIsolation + sandbox on.
 */
import { contextBridge, ipcRenderer } from 'electron';
import type { TeleconfBridge } from '../bridge';
import { CHANNELS } from './channels';

export function exposeTeleconfBridge(): void {
  const bridge: TeleconfBridge = {
    session: {
      get: () => ipcRenderer.invoke(CHANNELS.sessionGet),
      set: (s) => ipcRenderer.invoke(CHANNELS.sessionSet, s),
    },
    screen: {
      getSources: (opts) => ipcRenderer.invoke(CHANNELS.screenSources, opts),
      select: (id) => ipcRenderer.invoke(CHANNELS.screenSelect, id),
    },
    onDeepLink(cb) {
      const handler = (_e: unknown, url: string) => cb(url);
      ipcRenderer.on(CHANNELS.deepLink, handler);
      // Deliver a link that launched the app before anyone was listening.
      ipcRenderer
        .invoke(CHANNELS.deepLinkPending)
        .then((url: string | null) => url && cb(url))
        .catch(() => {
          /* deep links not enabled in main */
        });
      return () => ipcRenderer.removeListener(CHANNELS.deepLink, handler);
    },
    platform: process.platform,
  };

  if (process.contextIsolated) {
    contextBridge.exposeInMainWorld('teleconfBridge', bridge);
  } else {
    (globalThis as any).teleconfBridge = bridge;
  }
}

export type { TeleconfBridge } from '../bridge';
