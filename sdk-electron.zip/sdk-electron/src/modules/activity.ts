import { Emitter } from '../emitter';
import type { ChatModule } from './chat';
import type { CallsModule } from './calls';
import type { MeetingsModule } from './meetings';
import type { User } from '../types';

export type ActivityKind = 'meeting' | 'scheduled' | 'message';

export interface ActivityItem {
  key: string;
  kind: ActivityKind;
  time: Date;
  title: string;
  /** Ready-to-show subtitle, e.g. "You hosted · 3 people · Ended". */
  text: string;
  unread: boolean;
  /** What to open on click. */
  target: { type: 'meeting'; roomId: string } | { type: 'conversation'; conversationId: string };
}

export type ActivityFilter = 'all' | 'meetings' | 'chats';

/**
 * The Activity feed (same rules as the web app): meetings you joined in the
 * last 30 days, scheduled meetings (upcoming or within the last 2 days), and
 * the latest message of each conversation. `client.activity`.
 */
export class ActivityModule extends Emitter<{
  /** Something happened that changes the feed — call `feed()` again. */
  changed: () => void;
}> {
  constructor(
    private readonly meetings: MeetingsModule,
    private readonly chat: ChatModule,
    calls: CallsModule,
    private readonly me: () => User | null
  ) {
    super();
    const changed = () => this.emit('changed');
    chat.on('notify', changed);
    chat.on('read', changed);
    chat.on('conversationAdded', changed);
    chat.on('conversationRemoved', changed);
    calls.on('ended', changed);
  }

  async feed(filter: ActivityFilter = 'all'): Promise<ActivityItem[]> {
    const now = Date.now();
    const myId = this.me()?.id;
    const [rooms, history, convos] = await Promise.all([
      this.meetings.list(),
      this.meetings.history().catch(() => []),
      this.chat.listConversations().catch(() => []),
    ]);
    const out: ActivityItem[] = [];

    const joined = new Set<string>();
    for (const m of history) {
      joined.add(m.id);
      const host = m.owner?.id === myId ? 'You hosted' : `Hosted by ${m.owner?.username || '?'}`;
      const people = `${m.participantCount} ${m.participantCount === 1 ? 'person' : 'people'}`;
      out.push({
        key: `hist-${m.id}`,
        kind: 'meeting',
        time: new Date(m.lastJoinedAt),
        title: m.name,
        text: `${host} · ${people}${m.isActive ? '' : ' · Ended'}`,
        unread: false,
        target: { type: 'meeting', roomId: m.id },
      });
    }

    for (const r of rooms) {
      if (!r.scheduledAt) continue;
      const t = new Date(r.scheduledAt).getTime();
      if (t < now - 2 * 86_400_000) continue;
      if (t < now && joined.has(r.id)) continue;
      out.push({
        key: `room-${r.id}`,
        kind: 'scheduled',
        time: new Date(t),
        title: r.name,
        text: t >= now ? 'Upcoming meeting' : 'Scheduled meeting',
        unread: false,
        target: { type: 'meeting', roomId: r.id },
      });
    }

    for (const c of convos) {
      const last = c.lastMessage;
      if (!last) continue;
      const fromMe = last.senderId === myId;
      const preview = last.content || (last.attachmentUrl ? '📎 Attachment' : '');
      out.push({
        key: `conv-${c.id}`,
        kind: 'message',
        time: new Date(last.createdAt),
        title: this.chat.titleOf(c),
        text: `${fromMe ? 'You' : last.sender?.username || '?'}: ${preview}`,
        unread: c.hasUnread,
        target: { type: 'conversation', conversationId: c.id },
      });
    }

    out.sort((a, b) => b.time.getTime() - a.time.getTime());
    if (filter === 'meetings') return out.filter((i) => i.kind !== 'message');
    if (filter === 'chats') return out.filter((i) => i.kind === 'message');
    return out;
  }

  /** Number of conversations with unread messages (for a dock/taskbar badge). */
  async unreadCount(): Promise<number> {
    const convos = await this.chat.listConversations();
    return convos.filter((c) => c.hasUnread).length;
  }
}
