import type { Http } from '../http';
import { Meeting, type MeetingContext } from '../meeting';
import type { CreateMeetingInput, MeetingHistoryEntry, Room } from '../types';

/** Create / list / manage meetings, and open live sessions. `client.meetings`. */
export class MeetingsModule {
  constructor(
    private readonly http: Http,
    private readonly ctx: MeetingContext,
    private readonly webUrl: string | undefined
  ) {}

  /**
   * A live meeting session for this room. Attach listeners, then `join()`.
   *
   *   const meeting = client.meetings.room(id);
   *   meeting.on('participantJoined', …);
   *   await meeting.join({ displayName: 'Budi' });
   */
  room(roomId: string): Meeting {
    return new Meeting(this.ctx, roomId);
  }

  /** Create an instant (no `scheduledAt`) or scheduled meeting. */
  async create(input: CreateMeetingInput): Promise<Room> {
    const scheduledAt =
      input.scheduledAt instanceof Date ? input.scheduledAt.toISOString() : input.scheduledAt;
    const { room } = await this.http.post<{ room: Room }>('/rooms', { ...input, scheduledAt });
    return room;
  }

  /** Shortcut: create an instant meeting and return its id + share link. */
  async startInstant(name = 'Instant meeting'): Promise<{ room: Room; link: string | null }> {
    const room = await this.create({ name });
    return { room, link: this.link(room.id) };
  }

  /** Active meetings you own (instant + scheduled), newest first. */
  async list(): Promise<Room[]> {
    const { rooms } = await this.http.get<{ rooms: Room[] }>('/rooms');
    return rooms;
  }

  /** Works for guests too (used to show the room name before joining). */
  async get(roomId: string): Promise<Room> {
    const { room } = await this.http.get<{ room: Room }>(`/rooms/${encodeURIComponent(roomId)}`);
    return room;
  }

  /** Meetings you joined in the last 30 days (max 50), newest first. */
  async history(): Promise<MeetingHistoryEntry[]> {
    const { meetings } = await this.http.get<{ meetings: MeetingHistoryEntry[] }>('/rooms/history');
    return meetings;
  }

  /** Owner: close the room for good (nobody can join afterwards). */
  async end(roomId: string): Promise<void> {
    await this.http.post(`/rooms/${encodeURIComponent(roomId)}/end`);
  }

  /** Owner: email the join link (and schedule) to these addresses. */
  async invite(roomId: string, emails: string[]): Promise<number> {
    const { sent } = await this.http.post<{ sent: number }>(`/rooms/${encodeURIComponent(roomId)}/invite`, {
      emails,
    });
    return sent;
  }

  /** Shareable web link (needs `webUrl` in the client options). */
  link(roomId: string): string | null {
    return this.webUrl ? `${this.webUrl}/room/${encodeURIComponent(roomId)}` : null;
  }

  /**
   * Extract a room id from a pasted link or deep link:
   * `https://host/room/<id>`, `teleconf://room/<id>`, or a bare id.
   */
  parseLink(input: string): string | null {
    const s = input.trim();
    const m = s.match(/\/room\/([^/?#\s]+)/) || s.match(/^[a-z][\w+.-]*:\/\/room\/([^/?#\s]+)/i);
    if (m) return decodeURIComponent(m[1]);
    return /^[0-9a-f-]{36}$/i.test(s) ? s : null;
  }
}
