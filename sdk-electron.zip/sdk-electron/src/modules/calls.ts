import { Emitter } from '../emitter';
import { TeleconfError } from '../errors';
import type { MeetingContext } from '../meeting';
import type { Realtime } from '../realtime';
import type { CallInvite } from '../types';
import { VoiceCall, type CallOptions } from '../voice-call';

export interface CallsEvents {
  /** Someone is calling you — show an incoming-call UI. */
  incoming: (invite: CallInvite) => void;
  /** The caller gave up before you answered — close the incoming UI. */
  cancelled: (e: { conversationId: string }) => void;
  /** Someone declined a call you started. */
  declined: (e: { conversationId: string; byUserId: string; byUsername: string }) => void;
  /** The call in this conversation is over (last person left). */
  ended: (e: { conversationId: string }) => void;
}

/**
 * Voice calls inside chat conversations (1-on-1 or group). Only one call can
 * be active per client at a time. `client.calls`.
 */
export class CallsModule extends Emitter<CallsEvents> {
  /** The call you are in, if any. */
  active: VoiceCall | null = null;
  /** Incoming invites not yet answered, by conversationId. */
  readonly ringing = new Map<string, CallInvite>();

  constructor(private readonly ctx: MeetingContext, private readonly rt: Realtime) {
    super();
    rt.listen('call:invite', (invite: CallInvite) => {
      if (this.active?.conversationId === invite.conversationId) return;
      this.ringing.set(invite.conversationId, invite);
      this.emit('incoming', invite);
    });
    rt.listen('call:cancelled', (e: { conversationId: string }) => {
      this.ringing.delete(e.conversationId);
      this.emit('cancelled', e);
    });
    rt.listen('call:declined', (e: { conversationId: string; byUserId: string; byUsername: string }) => {
      this.emit('declined', e);
      const call = this.active;
      // 1-on-1 with nobody connected yet: a decline means it's over.
      if (call?.conversationId === e.conversationId && call.participants.size === 0) {
        void call.hangup('declined');
      }
    });
    rt.listen('call:ended', (e: { conversationId: string }) => {
      this.ringing.delete(e.conversationId);
      this.emit('ended', e);
      if (this.active?.conversationId === e.conversationId) this.active.remoteEnded('ended');
    });
  }

  /** Call everyone in a conversation. Resolves once your mic is live (state `ringing`). */
  async start(conversationId: string, opts: CallOptions = {}): Promise<VoiceCall> {
    this.assertIdle();
    const res = await this.rt.request<{ ok: boolean; existing?: boolean }>('call:start', { conversationId });
    // A call already running in this conversation: we simply join it.
    return this.open(conversationId, !res.existing, opts);
  }

  /** Answer an incoming call (pass the invite or its conversationId). */
  async accept(invite: CallInvite | string, opts: CallOptions = {}): Promise<VoiceCall> {
    this.assertIdle();
    const conversationId = typeof invite === 'string' ? invite : invite.conversationId;
    this.ringing.delete(conversationId);
    return this.open(conversationId, false, opts);
  }

  /** Decline an incoming call. */
  decline(invite: CallInvite | string): void {
    const conversationId = typeof invite === 'string' ? invite : invite.conversationId;
    this.ringing.delete(conversationId);
    this.rt.send('call:decline', { conversationId });
  }

  private async open(conversationId: string, isCaller: boolean, opts: CallOptions) {
    const call = new VoiceCall(this.ctx, conversationId, isCaller, opts);
    this.active = call;
    call.once('ended', () => {
      if (this.active === call) this.active = null;
    });
    try {
      await call.connect();
    } catch (err) {
      if (this.active === call) this.active = null;
      throw err;
    }
    return call;
  }

  private assertIdle() {
    if (this.active) throw new TeleconfError('Already in a call — hang up first', 'conflict');
  }
}
