import type { MeetingsModule } from './meetings';
import type { Room } from '../types';

export interface ScheduledMeeting extends Room {
  scheduledAt: string;
  start: Date;
  end: Date;
}

export interface ScheduleInput {
  name: string;
  description?: string;
  start: Date | string;
  /** 5–480, default 60. */
  durationMinutes?: number;
  /** Email invitations right away. */
  inviteEmails?: string[];
}

/**
 * Calendar view over your scheduled meetings (meetings you own that have a
 * `scheduledAt`). `client.calendar`.
 */
export class CalendarModule {
  constructor(private readonly meetings: MeetingsModule) {}

  /** Scheduled meetings overlapping [from, to), sorted by start. Both bounds optional. */
  async list(range: { from?: Date; to?: Date } = {}): Promise<ScheduledMeeting[]> {
    const rooms = await this.meetings.list();
    const from = range.from?.getTime() ?? -Infinity;
    const to = range.to?.getTime() ?? Infinity;
    return rooms
      .filter((r): r is Room & { scheduledAt: string } => !!r.scheduledAt)
      .map((r) => {
        const start = new Date(r.scheduledAt);
        const end = new Date(start.getTime() + (r.durationMinutes || 60) * 60_000);
        return { ...r, start, end };
      })
      .filter((m) => m.end.getTime() > from && m.start.getTime() < to)
      .sort((a, b) => a.start.getTime() - b.start.getTime());
  }

  /** Meetings for one calendar month (0-based month, local time). */
  month(year: number, month: number): Promise<ScheduledMeeting[]> {
    return this.list({ from: new Date(year, month, 1), to: new Date(year, month + 1, 1) });
  }

  /** The week (Sunday-start, local time) containing `day`. */
  week(day: Date = new Date()): Promise<ScheduledMeeting[]> {
    const start = new Date(day.getFullYear(), day.getMonth(), day.getDate() - day.getDay());
    return this.list({ from: start, to: new Date(start.getFullYear(), start.getMonth(), start.getDate() + 7) });
  }

  /** Not yet ended, soonest first. */
  async upcoming(limit = 10): Promise<ScheduledMeeting[]> {
    const all = await this.list({ from: new Date() });
    return all.slice(0, limit);
  }

  /** Create a scheduled meeting (and optionally send email invitations). */
  async schedule(input: ScheduleInput): Promise<ScheduledMeeting> {
    const room = await this.meetings.create({
      name: input.name,
      description: input.description,
      scheduledAt: input.start,
      durationMinutes: input.durationMinutes,
    });
    if (input.inviteEmails?.length) await this.meetings.invite(room.id, input.inviteEmails);
    const start = new Date(room.scheduledAt!);
    return {
      ...room,
      scheduledAt: room.scheduledAt!,
      start,
      end: new Date(start.getTime() + room.durationMinutes * 60_000),
    };
  }

  /** Group by local day, key `YYYY-MM-DD`. */
  groupByDay(meetings: ScheduledMeeting[]): Map<string, ScheduledMeeting[]> {
    const out = new Map<string, ScheduledMeeting[]>();
    for (const m of meetings) {
      const d = m.start;
      const key = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
      const list = out.get(key) ?? [];
      list.push(m);
      out.set(key, list);
    }
    return out;
  }

  /**
   * iCalendar (.ics) text for one or more meetings — save it and the OS opens
   * it in Outlook / Calendar / Google Calendar.
   */
  toICS(meetings: ScheduledMeeting | ScheduledMeeting[]): string {
    const list = Array.isArray(meetings) ? meetings : [meetings];
    const lines = ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//Teleconference//Electron SDK//EN', 'CALSCALE:GREGORIAN'];
    for (const m of list) {
      const link = this.meetings.link(m.id);
      const desc = [m.description, link ? `Join: ${link}` : null].filter(Boolean).join('\n');
      lines.push(
        'BEGIN:VEVENT',
        `UID:${m.id}@teleconference`,
        `DTSTAMP:${icsDate(new Date())}`,
        `DTSTART:${icsDate(m.start)}`,
        `DTEND:${icsDate(m.end)}`,
        `SUMMARY:${icsText(m.name)}`,
        ...(desc ? [`DESCRIPTION:${icsText(desc)}`] : []),
        ...(link ? [`URL:${link}`, `LOCATION:${icsText(link)}`] : []),
        'END:VEVENT'
      );
    }
    lines.push('END:VCALENDAR');
    return lines.join('\r\n');
  }
}

const pad = (n: number) => String(n).padStart(2, '0');

function icsDate(d: Date): string {
  return d.toISOString().replace(/[-:]/g, '').replace(/\.\d{3}/, '');
}

function icsText(s: string): string {
  return s.replace(/\\/g, '\\\\').replace(/\n/g, '\\n').replace(/([,;])/g, '\\$1');
}
