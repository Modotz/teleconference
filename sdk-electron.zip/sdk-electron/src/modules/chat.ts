import { Emitter } from '../emitter';
import type { Http } from '../http';
import type { Realtime } from '../realtime';
import type {
  Attachment,
  ChatMessage,
  ChatPreferences,
  Conversation,
  ConversationMember,
  ConversationSummary,
  MessageReceipt,
  User,
} from '../types';

export interface ChatEvents {
  /**
   * A message in a conversation you `subscribe()`d to — including your own
   * (from any device) and system lines. Use it to render the open thread.
   */
  message: (e: { conversationId: string; message: ChatMessage }) => void;
  /**
   * A message from someone else in ANY of your conversations, subscribed or
   * not. Use it for badges and notifications: stay silent when `muted`,
   * unless `mentioned`.
   */
  notify: (e: { conversationId: string; message: ChatMessage; muted: boolean; mentioned: boolean }) => void;
  messageEdited: (e: { conversationId: string; message: ChatMessage }) => void;
  /** Deleted for everyone — show "This message was deleted". */
  messageDeleted: (e: {
    conversationId: string;
    messageId: string;
    deletedBy: { id: string; username: string };
    byAdmin: boolean;
  }) => void;
  /** You deleted it "for me" (on any of your devices) — remove it. */
  messageHidden: (e: { conversationId: string; messageId: string }) => void;
  /** `emoji: null` = reaction removed. */
  reaction: (e: { conversationId: string; messageId: string; userId: string; username: string; emoji: string | null }) => void;
  typing: (e: { conversationId: string; userId: string; username: string; isTyping: boolean }) => void;
  /** Delivery receipt: `userId`'s device has received messages up to `at`. */
  delivered: (e: { conversationId: string; userId: string; at: string }) => void;
  /** Read receipt: `userId` has read up to `lastReadAt`. */
  read: (e: { conversationId: string; userId: string; lastReadAt: string }) => void;
  pinned: (e: { conversationId: string; messageId: string | null; by: { id: string; username: string } }) => void;
  /** Your settings for a chat changed (on any of your devices). */
  preferences: (e: { conversationId: string } & ChatPreferences) => void;
  starred: (e: { conversationId: string; messageId: string; value: boolean }) => void;
  /** Group name / description / send mode / admins changed. */
  groupUpdated: (conversation: Conversation) => void;
  memberMuted: (e: { conversationId: string; userId: string; until: string | null }) => void;
  /** You were added to a conversation (a new group, or added to one). */
  conversationAdded: (conversation: Conversation) => void;
  /** You were removed from a group. */
  conversationRemoved: (e: { conversationId: string; removedBy: { id: string; username: string } }) => void;
  memberAdded: (e: {
    conversationId: string;
    member: ConversationMember;
    addedBy: { id: string; username: string };
  }) => void;
  memberRemoved: (e: {
    conversationId: string;
    removedUserId: string;
    removedBy: { id: string; username: string };
  }) => void;
}

export interface SendMessageInput {
  content?: string;
  /** Upload this file first, then attach it (max 25 MB). */
  file?: Blob;
  fileName?: string;
  onProgress?: (percent: number) => void;
  /** Or attach something already uploaded with `uploadAttachment()`. */
  attachment?: Attachment;
  /**
   * Your id for this message. Sending again with the same clientId returns the
   * stored message instead of a duplicate — so an offline queue can simply
   * retry. Generated for you if omitted.
   */
  clientId?: string;
  replyToId?: string;
  /** userIds to @mention, or 'all' (group admins only). */
  mentions?: string[];
  /** App-defined message type (e.g. 'voice', 'location', 'card') with its data. */
  type?: string;
  data?: unknown;
}

export interface SearchOptions {
  conversationId?: string;
  senderId?: string;
  hasAttachment?: boolean;
  limit?: number;
}

/** 1-on-1 and group chat. `client.chat`. */
export class ChatModule extends Emitter<ChatEvents> {
  private readonly subscribed = new Set<string>();
  private readonly deliveryTimers = new Map<string, ReturnType<typeof setTimeout>>();
  /** Send delivery receipts automatically when messages arrive. */
  autoDeliveryReceipts = true;

  constructor(
    private readonly http: Http,
    private readonly rt: Realtime,
    private readonly me: () => User | null
  ) {
    super();
    rt.listen('chat:message', (e) => {
      this.emit('message', e);
      if (e.message?.senderId !== this.me()?.id) this.queueDelivered(e.conversationId);
    });
    rt.listen('chat:notify', (e) => {
      this.emit('notify', { muted: false, mentioned: false, ...e });
      this.queueDelivered(e.conversationId);
    });
    rt.listen('chat:messageEdited', (e) => this.emit('messageEdited', e));
    rt.listen('chat:messageDeleted', (e) => this.emit('messageDeleted', e));
    rt.listen('chat:messageHidden', (e) => this.emit('messageHidden', e));
    rt.listen('chat:reaction', (e) => this.emit('reaction', e));
    rt.listen('chat:typing', (e) => this.emit('typing', e));
    rt.listen('chat:delivered', (e) => this.emit('delivered', e));
    rt.listen('chat:read', (e) => this.emit('read', e));
    rt.listen('chat:pinned', (e) => this.emit('pinned', e));
    rt.listen('chat:preferences', (e) => this.emit('preferences', e));
    rt.listen('chat:starred', (e) => this.emit('starred', e));
    rt.listen('chat:groupUpdated', ({ conversation }) => this.emit('groupUpdated', conversation));
    rt.listen('chat:memberMuted', (e) => this.emit('memberMuted', e));
    rt.listen('chat:added', ({ conversation }) => this.emit('conversationAdded', conversation));
    rt.listen('chat:removed', (e) => {
      this.subscribed.delete(e.conversationId);
      this.emit('conversationRemoved', e);
    });
    rt.listen('chat:memberAdded', (e) => this.emit('memberAdded', e));
    rt.listen('chat:memberRemoved', (e) => this.emit('memberRemoved', e));
    // Socket rooms don't survive a reconnect — subscribe again.
    rt.on('reconnected', () => {
      for (const id of this.subscribed) this.rt.request('chat:join', { conversationId: id }).catch(() => {});
    });
  }

  // ------------------------------------------------------------- conversations

  /** All your conversations, most recent activity first, with unread counts and your settings. */
  async listConversations(): Promise<ConversationSummary[]> {
    const { conversations } = await this.http.get<{ conversations: any[] }>('/conversations');
    return conversations.map((c) => ({
      ...c,
      lastMessage: c.lastMessage ?? null,
      unreadCount: c.unreadCount ?? 0,
      hasUnread: (c.unreadCount ?? 0) > 0 || !!c.markedUnread,
    }));
  }

  async getConversation(id: string): Promise<Conversation> {
    const { conversation } = await this.http.get<{ conversation: Conversation }>(`/conversations/${id}`);
    return conversation;
  }

  /** Open (or reuse) the 1-on-1 conversation with a user. */
  async openDirect(userId: string): Promise<Conversation> {
    const { conversation } = await this.http.post<{ conversation: Conversation }>('/conversations', {
      userIds: [userId],
      isGroup: false,
    });
    return conversation;
  }

  /** You become the owner. Every member is told immediately (`conversationAdded`). */
  async createGroup(name: string, userIds: string[], opts: { description?: string } = {}): Promise<Conversation> {
    const { conversation } = await this.http.post<{ conversation: Conversation }>('/conversations', {
      userIds,
      name,
      isGroup: true,
      description: opts.description,
    });
    return conversation;
  }

  // ------------------------------------------------------------- groups

  /** Admins: add a member. */
  async addMember(conversationId: string, userId: string): Promise<Conversation> {
    const { conversation } = await this.http.post<{ conversation: Conversation }>(
      `/conversations/${conversationId}/members`,
      { userId }
    );
    return conversation;
  }

  /** Admins remove members; only the owner removes admins. */
  async removeMember(conversationId: string, userId: string): Promise<Conversation> {
    const { conversation } = await this.http.delete<{ conversation: Conversation }>(
      `/conversations/${conversationId}/members/${userId}`
    );
    return conversation;
  }

  /**
   * Leave a group. If you are the owner, ownership passes to an admin (or the
   * longest-standing member). Not possible in HR-managed groups.
   */
  async leaveGroup(conversationId: string): Promise<void> {
    const id = this.me()?.id;
    if (id) await this.removeMember(conversationId, id);
    this.subscribed.delete(conversationId);
  }

  /** Admins: rename, describe, or switch announcement mode (only admins send). */
  async updateGroup(
    conversationId: string,
    changes: { name?: string; description?: string | null; onlyAdminsCanSend?: boolean }
  ): Promise<Conversation> {
    const { conversation } = await this.http.patch<{ conversation: Conversation }>(
      `/conversations/${conversationId}`,
      changes
    );
    return conversation;
  }

  /** Admins make admins; only the owner removes one. */
  async setAdmin(conversationId: string, userId: string, value: boolean): Promise<Conversation> {
    const { conversation } = await this.http.post<{ conversation: Conversation }>(
      `/conversations/${conversationId}/admins`,
      { userId, value }
    );
    return conversation;
  }

  /** Owner only. You become an admin. */
  async transferOwnership(conversationId: string, userId: string): Promise<Conversation> {
    const { conversation } = await this.http.post<{ conversation: Conversation }>(
      `/conversations/${conversationId}/transfer`,
      { userId }
    );
    return conversation;
  }

  /** Admins: stop a member from sending until `until` (null lifts it). */
  async muteMember(conversationId: string, userId: string, until: Date | string | null): Promise<void> {
    await this.http.post(`/conversations/${conversationId}/mute-member`, {
      userId,
      until: until instanceof Date ? until.toISOString() : until,
    });
  }

  // ------------------------------------------------------------- your chat settings

  /**
   * Pin, mute, archive or mark unread — stored on the server, so phone and
   * desktop agree. `mutedUntil: true` mutes until you unmute.
   */
  async setPreferences(
    conversationId: string,
    prefs: Partial<Omit<ChatPreferences, 'mutedUntil'>> & { mutedUntil?: Date | string | true | null }
  ): Promise<ChatPreferences> {
    const body = { ...prefs, mutedUntil: prefs.mutedUntil instanceof Date ? prefs.mutedUntil.toISOString() : prefs.mutedUntil };
    const { preferences } = await this.http.put<{ preferences: ChatPreferences }>(
      `/conversations/${conversationId}/preferences`,
      body
    );
    return preferences;
  }

  pin(conversationId: string, pinned = true) {
    return this.setPreferences(conversationId, { pinned });
  }
  /** Mute until a time, or indefinitely (`true`); `false`/`null` unmutes. */
  mute(conversationId: string, until: Date | true | false | null = true) {
    return this.setPreferences(conversationId, { mutedUntil: until === false ? null : until });
  }
  archive(conversationId: string, archived = true) {
    return this.setPreferences(conversationId, { archived });
  }
  markUnread(conversationId: string, markedUnread = true) {
    return this.setPreferences(conversationId, { markedUnread });
  }

  // ------------------------------------------------------------- messages

  /**
   * Message history, oldest → newest. Page backwards with
   * `before: messages[0].createdAt`. Limit max 200 (default 50). Messages you
   * deleted "for me" are left out.
   */
  async listMessages(
    conversationId: string,
    opts: { before?: string | Date; limit?: number } = {}
  ): Promise<ChatMessage[]> {
    const before = opts.before instanceof Date ? opts.before.toISOString() : opts.before;
    const { messages } = await this.http.get<{ messages: ChatMessage[] }>(
      `/conversations/${conversationId}/messages`,
      { before, limit: opts.limit }
    );
    return messages;
  }

  /** Receive `message`/`typing`/`read` for this conversation. Returns unsubscribe. */
  async subscribe(conversationId: string): Promise<() => void> {
    await this.rt.request('chat:join', { conversationId });
    this.subscribed.add(conversationId);
    return () => void this.unsubscribe(conversationId);
  }

  async unsubscribe(conversationId: string): Promise<void> {
    this.subscribed.delete(conversationId);
    if (this.rt.connected) await this.rt.request('chat:leave', { conversationId }).catch(() => {});
  }

  /**
   * Send a message (text and/or file, reply, mentions, typed data). Resolves
   * with the stored message. Safe to retry: the same `clientId` never
   * creates a second message.
   */
  async send(conversationId: string, input: SendMessageInput | string): Promise<ChatMessage> {
    const msg = typeof input === 'string' ? { content: input } : input;
    let attachment = msg.attachment;
    if (msg.file) attachment = await this.uploadAttachment(msg.file, msg.fileName, msg.onProgress);
    const { message } = await this.rt.request<{ message: ChatMessage }>('chat:send', {
      conversationId,
      content: msg.content ?? '',
      attachment,
      clientId: msg.clientId ?? newClientId(),
      replyToId: msg.replyToId,
      mentions: msg.mentions,
      type: msg.type,
      data: msg.data,
    });
    return message;
  }

  /** Edit your own text message (within 15 minutes; error code `edit-window` after). */
  async edit(messageId: string, content: string): Promise<ChatMessage> {
    const { message } = await this.http.patch<{ message: ChatMessage }>(`/messages/${messageId}`, { content });
    return message;
  }

  /**
   * `me`: hide it on all your devices. `everyone`: delete for all members —
   * your own messages, or anyone's if you are a group admin.
   */
  async deleteMessage(messageId: string, scope: 'me' | 'everyone' = 'me'): Promise<void> {
    await this.http.delete(`/messages/${messageId}`, { scope });
  }

  /** One reaction per person; `null` removes yours. */
  async react(messageId: string, emoji: string | null): Promise<void> {
    await this.http.post(`/messages/${messageId}/reaction`, { emoji });
  }

  async star(messageId: string, value = true): Promise<void> {
    await this.http.post(`/messages/${messageId}/star`, { value });
  }

  /** Your starred messages, newest first. */
  async starred(): Promise<(ChatMessage & { starredAt: string })[]> {
    const { messages } = await this.http.get<{ messages: (ChatMessage & { starredAt: string })[] }>('/messages/starred');
    return messages;
  }

  /** Forward to up to 5 conversations; copies are labelled `forwarded`. */
  async forward(
    messageId: string,
    conversationIds: string[]
  ): Promise<{ conversationId: string; message?: ChatMessage; error?: string }[]> {
    const { results } = await this.http.post<{ results: any[] }>(`/messages/${messageId}/forward`, { conversationIds });
    return results;
  }

  /** Per member: sent / delivered / read, with times. */
  async receipts(messageId: string): Promise<MessageReceipt[]> {
    const { receipts } = await this.http.get<{ receipts: MessageReceipt[] }>(`/messages/${messageId}/receipts`);
    return receipts;
  }

  /** Report a message and/or a person to admins and HR. */
  async report(input: { messageId?: string; userId?: string; conversationId?: string; reason: string }): Promise<void> {
    await this.http.post('/reports', input);
  }

  /** One pinned message per chat (groups: admins only); `null` unpins. */
  async pinMessage(conversationId: string, messageId: string | null): Promise<void> {
    await this.http.post(`/conversations/${conversationId}/pin`, { messageId });
  }

  /**
   * Search message text on the server, across all chats or one. Only the
   * newest messages are scanned (they are encrypted at rest); `truncated`
   * says older ones were not.
   */
  async search(query: string, opts: SearchOptions = {}): Promise<{ messages: ChatMessage[]; truncated: boolean }> {
    return this.http.get('/messages/search', {
      q: query,
      conversationId: opts.conversationId,
      senderId: opts.senderId,
      hasAttachment: opts.hasAttachment ? 'true' : undefined,
      limit: opts.limit,
    });
  }

  /** Media, files or links shared in a chat, newest first. */
  async listAttachments(
    conversationId: string,
    kind: 'media' | 'file' | 'link',
    opts: { before?: string | Date; limit?: number } = {}
  ): Promise<{ message: ChatMessage; url?: string }[]> {
    const before = opts.before instanceof Date ? opts.before.toISOString() : opts.before;
    const { items } = await this.http.get<{ items: { message: ChatMessage; url?: string }[] }>(
      `/conversations/${conversationId}/attachments`,
      { kind, before, limit: opts.limit }
    );
    return items;
  }

  uploadAttachment(file: Blob, fileName?: string, onProgress?: (percent: number) => void): Promise<Attachment> {
    return this.http.upload(file, fileName, onProgress);
  }

  /** URL for <img>/<audio>/<a href> (token in the query string). */
  attachmentUrl(path: string | null | undefined): string | null {
    return this.http.fileUrl(path);
  }

  /** Fetch an attachment as a Blob (e.g. to save it to disk). */
  downloadAttachment(path: string): Promise<Blob> {
    return this.http.download(path);
  }

  // ------------------------------------------------------------- receipts & typing

  /** Mark everything up to now (or `lastReadAt`) as read; others get a `read` receipt. */
  async markRead(conversationId: string, lastReadAt?: string | Date): Promise<void> {
    const at = lastReadAt instanceof Date ? lastReadAt.toISOString() : lastReadAt;
    await this.rt.request('chat:markRead', { conversationId, lastReadAt: at });
  }

  /** Report that this device has received the conversation's messages (sent automatically by default). */
  async markDelivered(conversationId: string, at?: string | Date): Promise<void> {
    const when = at instanceof Date ? at.toISOString() : at;
    await this.rt.request('chat:delivered', { conversationId, at: when });
  }

  setTyping(conversationId: string, isTyping: boolean): void {
    this.rt.send('chat:typing', { conversationId, isTyping });
  }

  /**
   * Debounced typing signal for an input box: call `keystroke()` on input and
   * `stop()` on send/blur. Sends at most one "typing" per second and clears
   * it after 3 s of silence.
   */
  typingIndicator(conversationId: string): { keystroke(): void; stop(): void } {
    let lastSent = 0;
    let idle: ReturnType<typeof setTimeout> | null = null;
    const stop = () => {
      if (idle) clearTimeout(idle);
      idle = null;
      if (lastSent) this.setTyping(conversationId, false);
      lastSent = 0;
    };
    return {
      keystroke: () => {
        const now = Date.now();
        if (now - lastSent > 1000) {
          this.setTyping(conversationId, true);
          lastSent = now;
        }
        if (idle) clearTimeout(idle);
        idle = setTimeout(stop, 3000);
      },
      stop,
    };
  }

  /** Display title: group name, or the other person's name for 1-on-1. */
  titleOf(c: Conversation): string {
    if (c.isGroup) return c.name || 'Group';
    const other = c.members.find((m) => m.userId !== this.me()?.id);
    return other?.user.fullName || other?.user.username || 'Unknown';
  }

  /** Bundle bursts of incoming messages into one receipt per conversation. */
  private queueDelivered(conversationId: string) {
    if (!this.autoDeliveryReceipts || this.deliveryTimers.has(conversationId)) return;
    this.deliveryTimers.set(
      conversationId,
      setTimeout(() => {
        this.deliveryTimers.delete(conversationId);
        this.markDelivered(conversationId).catch(() => {});
      }, 500)
    );
  }
}

function newClientId(): string {
  return typeof crypto !== 'undefined' && 'randomUUID' in crypto
    ? crypto.randomUUID()
    : `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
}
