import { Emitter } from '../emitter';
import type { Http } from '../http';
import type { Realtime } from '../realtime';
import type {
  Attachment,
  ChatMessage,
  Conversation,
  ConversationMember,
  ConversationSummary,
  User,
} from '../types';

export interface ChatEvents {
  /**
   * A message in a conversation you `subscribe()`d to — including your own
   * (from any device). Use it to render the open thread.
   */
  message: (e: { conversationId: string; message: ChatMessage }) => void;
  /**
   * A message from someone else in ANY of your conversations, subscribed or
   * not. Use it for badges and desktop notifications.
   */
  notify: (e: { conversationId: string; message: ChatMessage }) => void;
  typing: (e: { conversationId: string; userId: string; username: string; isTyping: boolean }) => void;
  /** Read receipt: `userId` has read up to `lastReadAt`. */
  read: (e: { conversationId: string; userId: string; lastReadAt: string }) => void;
  /** You were added to a conversation (e.g. a new group). */
  conversationAdded: (conversation: Conversation) => void;
  /** You were removed from a group. */
  conversationRemoved: (e: { conversationId: string; removedBy: { id: string; username: string } }) => void;
  memberAdded: (e: {
    conversationId: string;
    member: ConversationMember;
    addedBy: { id: string; username: string };
  }) => void;
  memberRemoved: (e: {
    conversationId: string;
    removedUserId: string;
    removedBy: { id: string; username: string };
  }) => void;
}

export interface SendMessageInput {
  content?: string;
  /** Upload this file first, then attach it (max 25 MB). */
  file?: Blob;
  fileName?: string;
  onProgress?: (percent: number) => void;
  /** Or attach something already uploaded with `uploadAttachment()`. */
  attachment?: Attachment;
}

/** 1-on-1 and group chat. `client.chat`. */
export class ChatModule extends Emitter<ChatEvents> {
  private readonly subscribed = new Set<string>();

  constructor(
    private readonly http: Http,
    private readonly rt: Realtime,
    private readonly me: () => User | null
  ) {
    super();
    rt.listen('chat:message', (e) => this.emit('message', e));
    rt.listen('chat:notify', (e) => this.emit('notify', e));
    rt.listen('chat:typing', (e) => this.emit('typing', e));
    rt.listen('chat:read', (e) => this.emit('read', e));
    rt.listen('chat:added', ({ conversation }) => this.emit('conversationAdded', conversation));
    rt.listen('chat:removed', (e) => {
      this.subscribed.delete(e.conversationId);
      this.emit('conversationRemoved', e);
    });
    rt.listen('chat:memberAdded', (e) => this.emit('memberAdded', e));
    rt.listen('chat:memberRemoved', (e) => this.emit('memberRemoved', e));
    // Socket rooms don't survive a reconnect — subscribe again.
    rt.on('reconnected', () => {
      for (const id of this.subscribed) this.rt.request('chat:join', { conversationId: id }).catch(() => {});
    });
  }

  // ------------------------------------------------------------- REST

  /** All your conversations, most recent activity first. */
  async listConversations(): Promise<ConversationSummary[]> {
    const { conversations } = await this.http.get<{ conversations: any[] }>('/conversations');
    const myId = this.me()?.id;
    return conversations.map((c) => {
      const last: ChatMessage | null = c.lastMessage ?? null;
      const hasUnread =
        !!last &&
        last.senderId !== myId &&
        (!c.lastReadAt || new Date(c.lastReadAt).getTime() < new Date(last.createdAt).getTime());
      return { ...c, lastMessage: last, hasUnread };
    });
  }

  async getConversation(id: string): Promise<Conversation> {
    const { conversation } = await this.http.get<{ conversation: Conversation }>(`/conversations/${id}`);
    return conversation;
  }

  /** Open (or reuse) the 1-on-1 conversation with a user. */
  async openDirect(userId: string): Promise<Conversation> {
    const { conversation } = await this.http.post<{ conversation: Conversation }>('/conversations', {
      userIds: [userId],
      isGroup: false,
    });
    return conversation;
  }

  async createGroup(name: string, userIds: string[]): Promise<Conversation> {
    const { conversation } = await this.http.post<{ conversation: Conversation }>('/conversations', {
      userIds,
      name,
      isGroup: true,
    });
    return conversation;
  }

  async addMember(conversationId: string, userId: string): Promise<Conversation> {
    const { conversation } = await this.http.post<{ conversation: Conversation }>(
      `/conversations/${conversationId}/members`,
      { userId }
    );
    return conversation;
  }

  /** Group owner removes someone. */
  async removeMember(conversationId: string, userId: string): Promise<Conversation> {
    const { conversation } = await this.http.delete<{ conversation: Conversation }>(
      `/conversations/${conversationId}/members/${userId}`
    );
    return conversation;
  }

  /** Leave a group (the owner can't while others remain). */
  async leaveGroup(conversationId: string): Promise<void> {
    const id = this.me()?.id;
    if (id) await this.removeMember(conversationId, id);
    this.subscribed.delete(conversationId);
  }

  /**
   * Message history, oldest → newest. Page backwards with
   * `before: messages[0].createdAt`. Limit max 200 (default 50).
   */
  async listMessages(
    conversationId: string,
    opts: { before?: string | Date; limit?: number } = {}
  ): Promise<ChatMessage[]> {
    const before = opts.before instanceof Date ? opts.before.toISOString() : opts.before;
    const { messages } = await this.http.get<{ messages: ChatMessage[] }>(
      `/conversations/${conversationId}/messages`,
      { before, limit: opts.limit }
    );
    return messages;
  }

  // ------------------------------------------------------------- realtime

  /** Receive `message`/`typing`/`read` for this conversation. Returns unsubscribe. */
  async subscribe(conversationId: string): Promise<() => void> {
    await this.rt.request('chat:join', { conversationId });
    this.subscribed.add(conversationId);
    return () => void this.unsubscribe(conversationId);
  }

  async unsubscribe(conversationId: string): Promise<void> {
    this.subscribed.delete(conversationId);
    if (this.rt.connected) await this.rt.request('chat:leave', { conversationId }).catch(() => {});
  }

  /** Send a message (text and/or file). Resolves with the stored message. */
  async send(conversationId: string, input: SendMessageInput | string): Promise<ChatMessage> {
    const msg = typeof input === 'string' ? { content: input } : input;
    let attachment = msg.attachment;
    if (msg.file) attachment = await this.uploadAttachment(msg.file, msg.fileName, msg.onProgress);
    const { message } = await this.rt.request<{ message: ChatMessage }>('chat:send', {
      conversationId,
      content: msg.content ?? '',
      attachment,
    });
    return message;
  }

  uploadAttachment(file: Blob, fileName?: string, onProgress?: (percent: number) => void): Promise<Attachment> {
    return this.http.upload(file, fileName, onProgress);
  }

  /** URL for <img>/<audio>/<a href> (token in the query string). */
  attachmentUrl(path: string | null | undefined): string | null {
    return this.http.fileUrl(path);
  }

  /** Fetch an attachment as a Blob (e.g. to save it to disk). */
  downloadAttachment(path: string): Promise<Blob> {
    return this.http.download(path);
  }

  /** Mark everything up to now (or `lastReadAt`) as read; others get a `read` receipt. */
  async markRead(conversationId: string, lastReadAt?: string | Date): Promise<void> {
    const at = lastReadAt instanceof Date ? lastReadAt.toISOString() : lastReadAt;
    await this.rt.request('chat:markRead', { conversationId, lastReadAt: at });
  }

  setTyping(conversationId: string, isTyping: boolean): void {
    this.rt.send('chat:typing', { conversationId, isTyping });
  }

  /**
   * Debounced typing signal for an input box: call `keystroke()` on input and
   * `stop()` on send/blur. Sends at most one "typing" per second and clears
   * it after 3 s of silence.
   */
  typingIndicator(conversationId: string): { keystroke(): void; stop(): void } {
    let lastSent = 0;
    let idle: ReturnType<typeof setTimeout> | null = null;
    const stop = () => {
      if (idle) clearTimeout(idle);
      idle = null;
      if (lastSent) this.setTyping(conversationId, false);
      lastSent = 0;
    };
    return {
      keystroke: () => {
        const now = Date.now();
        if (now - lastSent > 1000) {
          this.setTyping(conversationId, true);
          lastSent = now;
        }
        if (idle) clearTimeout(idle);
        idle = setTimeout(stop, 3000);
      },
      stop,
    };
  }

  /** Display title: group name, or the other person's username for 1-on-1. */
  titleOf(c: Conversation): string {
    if (c.isGroup) return c.name || 'Group';
    const other = c.members.find((m) => m.userId !== this.me()?.id);
    return other?.user.username || 'Unknown';
  }
}
