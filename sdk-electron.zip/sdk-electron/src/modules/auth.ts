import { Emitter } from '../emitter';
import type { Http } from '../http';
import type { Realtime } from '../realtime';
import type { DeviceSession, Session, User } from '../types';

export interface DeviceInfo {
  deviceType: 'desktop' | 'mobile' | 'web';
  deviceName?: string;
}

/**
 * Sign-in flows. Successful logins become the client's session (persisted via
 * the SessionStore and used for realtime). `client.auth`.
 */
export class AuthModule {
  constructor(
    private readonly http: Http,
    private readonly setSession: (s: Session | null) => Promise<void>,
    private readonly device: DeviceInfo
  ) {}

  /** Email + password. Throws `unverified` / `inactive` when the account can't sign in. */
  async login(email: string, password: string): Promise<User> {
    const { token, user } = await this.http.post<{ token: string; user: User }>('/auth/login', {
      email,
      password,
      ...this.device,
    });
    await this.setSession({ token, user });
    return user;
  }

  /**
   * Google sign-in with an ID token you obtained yourself (Google Identity
   * Services / OAuth). Uses the server's GOOGLE_CLIENT_ID as audience.
   */
  async loginWithGoogle(idToken: string): Promise<User> {
    const { token, user } = await this.http.post<{ token: string; user: User }>('/auth/google', {
      idToken,
      ...this.device,
    });
    await this.setSession({ token, user });
    return user;
  }

  /**
   * Join-by-name session (12 h). Guests can join meetings, but cannot use
   * chat, calls, calendar or activity.
   */
  async loginAsGuest(displayName: string): Promise<User> {
    const { token, user } = await this.http.post<{ token: string; user: User }>('/auth/guest', {
      displayName,
    });
    await this.setSession({ token, user: { ...user, guest: true } });
    return user;
  }

  /** Creates the account and emails a verification link. Does not sign in. */
  async register(input: { email: string; username: string; password: string }): Promise<void> {
    await this.http.post('/auth/register', input);
  }

  /** `token` comes from the verification link (`/verify-email?token=…`). */
  async verifyEmail(token: string): Promise<void> {
    await this.http.post('/auth/verify-email', { token });
  }

  async resendVerification(email: string): Promise<void> {
    await this.http.post('/auth/resend-verification', { email });
  }

  /** Always succeeds (doesn't reveal whether the email exists). */
  async forgotPassword(email: string): Promise<void> {
    await this.http.post('/auth/forgot-password', { email });
  }

  /** `token` comes from the reset link (`/reset-password?token=…`). Min 6 chars. */
  async resetPassword(token: string, password: string): Promise<void> {
    await this.http.post('/auth/reset-password', { token, password });
  }

  /** Fresh profile (with HR fields) from the server (accounts only, not guests). */
  async me(): Promise<User> {
    const { user } = await this.http.get<{ user: User }>('/auth/me');
    return user;
  }

  /**
   * Sign out: the server revokes this device's session (the token stops
   * working immediately), then local state is cleared. Works offline too —
   * the local session is cleared regardless.
   */
  async logout(): Promise<void> {
    await this.http.post('/auth/logout').catch(() => {});
    await this.setSession(null);
  }

  /** Your signed-in devices. */
  async sessions(): Promise<DeviceSession[]> {
    const { sessions } = await this.http.get<{ sessions: DeviceSession[] }>('/auth/sessions');
    return sessions;
  }

  /** Sign one of your devices out. */
  async revokeSession(sessionId: string): Promise<void> {
    await this.http.delete(`/auth/sessions/${encodeURIComponent(sessionId)}`);
  }

  /** Sign out every device except this one. Returns how many were revoked. */
  async revokeOtherSessions(): Promise<number> {
    const { revoked } = await this.http.post<{ revoked: number }>('/auth/sessions/revoke-others');
    return revoked;
  }
}

/** Directory (same organization only) and online status. `client.users`. */
export class UsersModule extends Emitter<{
  /** A contact came online or went offline. */
  presence: (e: { userId: string; online: boolean }) => void;
}> {
  /** Last known online state, from `presence()` and live events. */
  readonly online = new Map<string, boolean>();

  constructor(private readonly http: Http, rt: Realtime) {
    super();
    rt.listen('presence', (e: { userId: string; online: boolean }) => {
      this.online.set(e.userId, e.online);
      this.emit('presence', e);
    });
  }

  /**
   * Search colleagues by name, username, email, NIK, title or division. Only
   * active employees of your organization; system accounts never appear. Max 200.
   */
  async search(query = ''): Promise<User[]> {
    const { users } = await this.http.get<{ users: User[] }>('/users', { q: query });
    return users;
  }

  /** One colleague's profile (HR fields included). */
  async get(userId: string): Promise<User> {
    const { user } = await this.http.get<{ user: User }>(`/users/${encodeURIComponent(userId)}`);
    return user;
  }

  /** Who is online right now (no "last seen", by design). Max 200 ids. */
  async presence(userIds: string[]): Promise<Record<string, boolean>> {
    if (!userIds.length) return {};
    const { presence } = await this.http.get<{ presence: Record<string, boolean> }>('/users/presence', {
      ids: userIds.join(','),
    });
    for (const [id, on] of Object.entries(presence)) this.online.set(id, on);
    return presence;
  }
}

/**
 * HR / IT administration (needs role hr_admin or it_admin). Scaffold until
 * employee data comes from HR directly. `client.admin`.
 */
export class AdminModule {
  constructor(private readonly http: Http) {}

  /** Update HR fields and roles of a colleague. */
  async updateUser(
    userId: string,
    fields: Partial<Pick<User, 'fullName' | 'nik' | 'title' | 'division' | 'company' | 'site' | 'managerId' | 'photoUrl' | 'roles'>>
  ): Promise<User> {
    const { user } = await this.http.patch<{ user: User }>(`/admin/users/${encodeURIComponent(userId)}`, fields);
    return user;
  }

  /** Deactivate (left the company: login blocked, all sessions revoked) or reactivate. */
  async setActive(userId: string, active: boolean): Promise<void> {
    await this.http.post(`/admin/users/${encodeURIComponent(userId)}/active`, { active });
  }

  async sessions(userId: string): Promise<Omit<DeviceSession, 'current' | 'expiresAt'>[]> {
    const { sessions } = await this.http.get<{ sessions: Omit<DeviceSession, 'current' | 'expiresAt'>[] }>(
      `/admin/users/${encodeURIComponent(userId)}/sessions`
    );
    return sessions;
  }

  /** Sign a colleague out of every device. */
  async revokeSessions(userId: string): Promise<number> {
    const { revoked } = await this.http.post<{ revoked: number }>(
      `/admin/users/${encodeURIComponent(userId)}/revoke-sessions`
    );
    return revoked;
  }
}
