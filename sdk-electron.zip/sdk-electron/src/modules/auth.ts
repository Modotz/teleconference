import type { Http } from '../http';
import type { Session, User } from '../types';

/**
 * Sign-in flows. Successful logins become the client's session (persisted via
 * the SessionStore and used for realtime). `client.auth`.
 */
export class AuthModule {
  constructor(
    private readonly http: Http,
    private readonly setSession: (s: Session | null) => Promise<void>
  ) {}

  /** Email + password. Throws code `unverified` if the email isn't verified yet. */
  async login(email: string, password: string): Promise<User> {
    const { token, user } = await this.http.post<{ token: string; user: User }>('/auth/login', {
      email,
      password,
    });
    await this.setSession({ token, user });
    return user;
  }

  /**
   * Google sign-in with an ID token you obtained yourself (Google Identity
   * Services / OAuth). Uses the server's GOOGLE_CLIENT_ID as audience.
   */
  async loginWithGoogle(idToken: string): Promise<User> {
    const { token, user } = await this.http.post<{ token: string; user: User }>('/auth/google', { idToken });
    await this.setSession({ token, user });
    return user;
  }

  /**
   * Join-by-name session (12 h). Guests can join meetings, but cannot use
   * chat, calls, calendar or activity.
   */
  async loginAsGuest(displayName: string): Promise<User> {
    const { token, user } = await this.http.post<{ token: string; user: User }>('/auth/guest', {
      displayName,
    });
    await this.setSession({ token, user: { ...user, guest: true } });
    return user;
  }

  /** Creates the account and emails a verification link. Does not sign in. */
  async register(input: { email: string; username: string; password: string }): Promise<void> {
    await this.http.post('/auth/register', input);
  }

  /** `token` comes from the verification link (`/verify-email?token=…`). */
  async verifyEmail(token: string): Promise<void> {
    await this.http.post('/auth/verify-email', { token });
  }

  async resendVerification(email: string): Promise<void> {
    await this.http.post('/auth/resend-verification', { email });
  }

  /** Always succeeds (doesn't reveal whether the email exists). */
  async forgotPassword(email: string): Promise<void> {
    await this.http.post('/auth/forgot-password', { email });
  }

  /** `token` comes from the reset link (`/reset-password?token=…`). Min 6 chars. */
  async resetPassword(token: string, password: string): Promise<void> {
    await this.http.post('/auth/reset-password', { token, password });
  }

  /** Fresh profile from the server (accounts only, not guests). */
  async me(): Promise<User> {
    const { user } = await this.http.get<{ user: User }>('/auth/me');
    return user;
  }

  /** Forget the session locally (the JWT itself stays valid until it expires). */
  async logout(): Promise<void> {
    await this.setSession(null);
  }
}

export class UsersModule {
  constructor(private readonly http: Http) {}

  /** Contact picker: everyone except you, filtered by username/email. Max 200. */
  async search(query = ''): Promise<User[]> {
    const { users } = await this.http.get<{ users: User[] }>('/users', { q: query });
    return users;
  }
}
