import { Emitter } from '../emitter';
import type { Http } from '../http';
import type { Realtime } from '../realtime';
import type {
  AgendaEvent,
  AgendaEventInput,
  AgendaResponse,
  BookableRoom,
  RoomBooking,
  Site,
} from '../types';

const iso = (d: Date | string | undefined) => (d instanceof Date ? d.toISOString() : d);

export interface AgendaEvents {
  /** You were invited to an event. */
  invited: (event: AgendaEvent) => void;
  /** An event you're in changed; with `timeChanged`, answer again. */
  updated: (e: { event: AgendaEvent; timeChanged: boolean }) => void;
  cancelled: (e: { eventId: string }) => void;
  /** Someone answered an event you organize. */
  response: (e: { eventId: string; userId: string; response: AgendaResponse; note: string | null }) => void;
}

/**
 * Agenda (Tahap 2 scaffold): meetings and activities with attendees and
 * Yes/Maybe/No responses, online/offline/hybrid, optional room booking.
 * Not yet: Outlook sync, server-side reminders, recurrence expansion.
 * `client.agenda`.
 */
export class AgendaModule extends Emitter<AgendaEvents> {
  constructor(private readonly http: Http, rt: Realtime) {
    super();
    rt.listen('agenda:invited', ({ event }) => this.emit('invited', event));
    rt.listen('agenda:updated', (e) => this.emit('updated', e));
    rt.listen('agenda:cancelled', (e) => this.emit('cancelled', e));
    rt.listen('agenda:response', (e) => this.emit('response', e));
  }

  /** Events you organize or are invited to, overlapping [from, to). */
  async list(range: { from?: Date | string; to?: Date | string } = {}): Promise<AgendaEvent[]> {
    const { events } = await this.http.get<{ events: AgendaEvent[] }>('/agenda', {
      from: iso(range.from),
      to: iso(range.to),
    });
    return events;
  }

  /** Someone else's private event comes back as a "Busy" block only. */
  async get(eventId: string): Promise<AgendaEvent> {
    const { event } = await this.http.get<{ event: AgendaEvent }>(`/agenda/${eventId}`);
    return event;
  }

  /**
   * Create. Online/hybrid meetings get a Telepati room (`roomId`) to join.
   * With `bookableRoomId` the room is booked atomically — a clash fails with
   * TeleconfError `conflict` and `details.bookedBy`.
   */
  async create(input: AgendaEventInput): Promise<AgendaEvent> {
    const { event } = await this.http.post<{ event: AgendaEvent }>('/agenda', {
      ...input,
      start: iso(input.start),
      end: iso(input.end),
    });
    return event;
  }

  /** Organizer only. Moving the time resets everyone's answer to pending. */
  async update(eventId: string, changes: Partial<Omit<AgendaEventInput, 'attendees' | 'bookableRoomId' | 'roomId'>>): Promise<AgendaEvent> {
    const { event } = await this.http.patch<{ event: AgendaEvent }>(`/agenda/${eventId}`, {
      ...changes,
      start: iso(changes.start),
      end: iso(changes.end),
    });
    return event;
  }

  /** Organizer only. Also releases the booked room unless `keepRoomBooking`. */
  async cancel(eventId: string, opts: { keepRoomBooking?: boolean } = {}): Promise<void> {
    await this.http.delete(`/agenda/${eventId}`, { keepRoomBooking: opts.keepRoomBooking ? 'true' : undefined });
  }

  async respond(eventId: string, response: Exclude<AgendaResponse, 'pending'>, note?: string): Promise<void> {
    await this.http.post(`/agenda/${eventId}/respond`, { response, note });
  }

  /** Busy blocks of colleagues (no titles or details), for "find a time". */
  async freeBusy(userIds: string[], from: Date | string, to: Date | string): Promise<Record<string, { start: string; end: string }[]>> {
    const { busy } = await this.http.get<{ busy: Record<string, { start: string; end: string }[]> }>('/agenda/free-busy', {
      userIds: userIds.join(','),
      from: iso(from),
      to: iso(to),
    });
    return busy;
  }
}

/** Physical room booking per site (Tahap 2 scaffold). `client.bookings`. */
export class BookingsModule {
  constructor(private readonly http: Http) {}

  async sites(): Promise<Site[]> {
    const { sites } = await this.http.get<{ sites: Site[] }>('/sites');
    return sites;
  }

  async rooms(siteId: string, type?: 'meeting' | 'operational'): Promise<BookableRoom[]> {
    const { rooms } = await this.http.get<{ rooms: BookableRoom[] }>(`/sites/${siteId}/rooms`, { type });
    return rooms;
  }

  /**
   * Bookings at a site on a day (`YYYY-MM-DD`, site time). Others' bookings
   * show only who and when; yours include purpose and notes.
   */
  async availability(
    siteId: string,
    date: string
  ): Promise<(RoomBooking & { bookedBy: { id: string; username: string; fullName?: string | null } | null; mine: boolean })[]> {
    const { bookings } = await this.http.get<{ bookings: any[] }>(`/sites/${siteId}/availability`, { date });
    return bookings;
  }

  /**
   * Book (operational rooms: purpose + note, no attendees). A clash fails
   * with TeleconfError `conflict`; `details.bookedBy` says who has it.
   */
  async book(input: {
    bookableRoomId: string;
    start: Date | string;
    end: Date | string;
    purpose?: string;
    note?: string;
    reminderMinutes?: number;
    eventId?: string;
  }): Promise<RoomBooking> {
    const { booking } = await this.http.post<{ booking: RoomBooking }>('/bookings', {
      ...input,
      start: iso(input.start),
      end: iso(input.end),
    });
    return booking;
  }

  async mine(): Promise<(RoomBooking & { room: BookableRoom & { site: { id: string; name: string } } })[]> {
    const { bookings } = await this.http.get<{ bookings: any[] }>('/bookings/mine');
    return bookings;
  }

  /** `withEvent`: also cancel the agenda item the booking belongs to. */
  async cancel(bookingId: string, opts: { withEvent?: boolean } = {}): Promise<void> {
    await this.http.delete(`/bookings/${bookingId}`, { withEvent: opts.withEvent ? 'true' : undefined });
  }
}
