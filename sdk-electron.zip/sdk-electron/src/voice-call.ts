import type { Socket } from 'socket.io-client';
import { Emitter } from './emitter';
import { TeleconfError } from './errors';
import { openSocket, request, waitConnected } from './realtime';
import { MIC_CODEC_OPTIONS, MIC_ENCODINGS, MediaSession } from './media/session';
import type { MeetingContext } from './meeting';

export type CallEndReason =
  | 'left' // you hung up
  | 'ended' // everyone else left
  | 'declined' // 1-on-1: the other side declined
  | 'no-answer' // nobody picked up within ringTimeoutMs
  | 'error';

export interface CallParticipant {
  peerId: string;
  displayName: string;
  /** Remote audio — play it with an <audio autoplay> element. */
  stream: MediaStream;
}

export interface CallOptions {
  /** Your own mic stream, or a microphone deviceId to open. Default: default mic. */
  media?: MediaStream | { microphoneId?: string };
  /** Start muted? Default false. */
  muted?: boolean;
  /** Caller side: hang up if nobody joins within this time. Default 45 s; 0 = never. */
  ringTimeoutMs?: number;
  /** Hang up when the last other person leaves. Default true. */
  hangupWhenAlone?: boolean;
}

export interface VoiceCallEvents {
  state: (state: 'connecting' | 'ringing' | 'connected' | 'ended') => void;
  participantJoined: (p: CallParticipant) => void;
  participantLeft: (p: CallParticipant) => void;
  /** Remote audio arrived for a participant. */
  track: (p: CallParticipant) => void;
  activeSpeaker: (peerId: string | null) => void;
  ended: (reason: CallEndReason) => void;
  error: (err: Error) => void;
}

/**
 * An audio call inside a conversation. Get one from `client.calls.start()`
 * or `client.calls.accept()`.
 */
export class VoiceCall extends Emitter<VoiceCallEvents> {
  readonly conversationId: string;
  /** True for the side that started the call. */
  readonly isCaller: boolean;
  state: 'connecting' | 'ringing' | 'connected' | 'ended' = 'connecting';
  readonly participants = new Map<string, CallParticipant>();
  localStream: MediaStream | null = null;
  muted = false;
  /** Epoch ms when the first other person connected (for a call timer). */
  connectedAt = 0;

  private socket: Socket | null = null;
  private media: MediaSession | null = null;
  private ownsMedia = true;
  private ringTimer: ReturnType<typeof setTimeout> | null = null;
  private readonly opts: Required<Omit<CallOptions, 'media' | 'muted'>>;

  constructor(
    private readonly ctx: MeetingContext,
    conversationId: string,
    isCaller: boolean,
    private readonly options: CallOptions = {}
  ) {
    super();
    this.conversationId = conversationId;
    this.isCaller = isCaller;
    this.muted = !!options.muted;
    this.opts = {
      ringTimeoutMs: options.ringTimeoutMs ?? 45_000,
      hangupWhenAlone: options.hangupWhenAlone ?? true,
    };
  }

  /** @internal — used by CallsModule. */
  async connect(): Promise<void> {
    const session = this.ctx.getSession();
    if (!session) throw new TeleconfError('Not signed in', 'unauthorized');
    try {
      const m = this.options.media;
      if (m instanceof MediaStream) {
        this.localStream = m;
        this.ownsMedia = false;
      } else {
        this.localStream = await this.ctx.devices.getLocalStream({
          audio: true,
          video: false,
          microphoneId: m?.microphoneId,
        });
      }
      this.localStream.getAudioTracks().forEach((t) => (t.enabled = !this.muted));

      const socket = openSocket(this.ctx.serverUrl, session.token);
      this.socket = socket;
      await waitConnected(socket);

      const res = await request<any>(socket, 'call:accept', { conversationId: this.conversationId });
      this.media = new MediaSession(socket);
      await this.media.load(res.rtpCapabilities);

      socket.on('peerJoined', ({ peerId, username }) => this.addPeer(peerId, username));
      socket.on('peerLeft', ({ peerId }) => this.removePeer(peerId));
      socket.on('newProducer', ({ producerId, peerId, username }) => void this.consume(producerId, peerId, username));
      socket.on('activeSpeaker', ({ peerId }) => this.emit('activeSpeaker', peerId ?? null));
      socket.on('disconnect', (reason) => {
        if (this.state !== 'ended' && reason !== 'io client disconnect') this.finish('error');
      });

      const track = this.localStream.getAudioTracks()[0];
      if (track) {
        const producer = await this.media.produce('mic-call', track, {
          codecOptions: MIC_CODEC_OPTIONS,
          encodings: MIC_ENCODINGS,
        });
        if (this.muted) producer.pause();
      }

      for (const p of res.peers || []) this.addPeer(p.peerId, p.username);
      for (const p of res.existingProducers || []) await this.consume(p.producerId, p.peerId, p.username);

      if (this.participants.size > 0) this.markConnected();
      else {
        this.setState('ringing');
        if (this.isCaller && this.opts.ringTimeoutMs > 0) {
          this.ringTimer = setTimeout(() => {
            if (this.participants.size === 0) void this.hangup('no-answer');
          }, this.opts.ringTimeoutMs);
        }
      }
    } catch (err) {
      await this.hangup('error');
      throw err;
    }
  }

  setMuted(muted: boolean): void {
    this.muted = muted;
    this.localStream?.getAudioTracks().forEach((t) => (t.enabled = !muted));
    const producer = this.media?.producers.get('mic-call');
    if (producer) muted ? producer.pause() : producer.resume();
  }

  toggleMute(): void {
    this.setMuted(!this.muted);
  }

  async switchMicrophone(deviceId: string): Promise<void> {
    const s = await this.ctx.devices.getLocalStream({ audio: true, video: false, microphoneId: deviceId });
    const track = s.getAudioTracks()[0];
    track.enabled = !this.muted;
    await this.media?.producers.get('mic-call')?.replaceTrack({ track });
    const old = this.localStream?.getAudioTracks()[0];
    if (old) {
      this.localStream!.removeTrack(old);
      if (this.ownsMedia) old.stop();
    }
    this.localStream?.addTrack(track);
  }

  /** Hang up. Safe to call more than once. */
  async hangup(reason: CallEndReason = 'left'): Promise<void> {
    if (this.state === 'ended') return;
    if (this.socket?.connected) {
      // call:leave (not just a disconnect) is what frees the server-side call;
      // when we were the last one in it also closes everyone's ringing toast.
      await request(this.socket, 'call:leave', { conversationId: this.conversationId }, 5000).catch(() => {});
    }
    this.finish(reason);
  }

  /** @internal — CallsModule routes server-side call events here. */
  remoteEnded(reason: CallEndReason): void {
    this.finish(reason);
  }

  private addPeer(peerId: string, username: string) {
    if (this.participants.has(peerId)) return;
    const p: CallParticipant = { peerId, displayName: username, stream: new MediaStream() };
    this.participants.set(peerId, p);
    this.emit('participantJoined', p);
    this.markConnected();
  }

  private removePeer(peerId: string) {
    const p = this.participants.get(peerId);
    if (!p) return;
    for (const c of Array.from(this.media?.consumed.values() ?? [])) {
      if (c.peerId === peerId) this.media?.dropProducer(c.producerId);
    }
    this.participants.delete(peerId);
    this.emit('participantLeft', p);
    if (this.opts.hangupWhenAlone && this.participants.size === 0 && this.connectedAt) {
      void this.hangup('ended');
    }
  }

  private async consume(producerId: string, peerId: string, username: string) {
    try {
      const entry = await this.media?.consume(producerId, peerId);
      if (!entry) return;
      this.addPeer(peerId, username);
      const p = this.participants.get(peerId)!;
      p.stream.getAudioTracks().forEach((t) => p.stream.removeTrack(t));
      p.stream.addTrack(entry.consumer.track);
      this.emit('track', p);
    } catch (err) {
      this.emit('error', err as Error);
    }
  }

  private markConnected() {
    if (this.state === 'connected' || this.state === 'ended') return;
    if (this.ringTimer) clearTimeout(this.ringTimer);
    this.connectedAt = Date.now();
    this.setState('connected');
  }

  private finish(reason: CallEndReason) {
    if (this.state === 'ended') return;
    if (this.ringTimer) clearTimeout(this.ringTimer);
    this.media?.close();
    this.media = null;
    if (this.socket) {
      this.socket.removeAllListeners();
      this.socket.disconnect();
      this.socket = null;
    }
    if (this.ownsMedia) this.localStream?.getTracks().forEach((t) => t.stop());
    this.setState('ended');
    this.emit('ended', reason);
  }

  private setState(s: VoiceCall['state']) {
    if (this.state === s) return;
    this.state = s;
    this.emit('state', s);
  }
}
