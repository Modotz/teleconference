import type { Socket } from 'socket.io-client';
import { Emitter } from './emitter';
import { TeleconfError } from './errors';
import { openSocket, request, waitConnected } from './realtime';
import { MIC_CODEC_OPTIONS, MIC_ENCODINGS, MediaSession } from './media/session';
import type { MeetingContext } from './meeting';

export type CallEndReason =
  | 'left' // you hung up
  | 'ended' // everyone else left
  | 'declined' // 1-on-1: the other side declined
  | 'no-answer' // nobody picked up within ringTimeoutMs
  | 'error'; // could not connect, or the network stayed down

export interface CallParticipant {
  peerId: string;
  displayName: string;
  /** Remote audio — play it with an <audio autoplay> element. */
  stream: MediaStream;
  muted: boolean;
  handRaised: boolean;
}

export interface CallOptions {
  /** Your own mic stream, or a microphone deviceId to open. Default: default mic. */
  media?: MediaStream | { microphoneId?: string };
  /** Start muted? Default false. */
  muted?: boolean;
  /** Caller side: hang up if nobody joins within this time. Default 45 s; 0 = never. */
  ringTimeoutMs?: number;
  /** Hang up when the last other person leaves. Default true. */
  hangupWhenAlone?: boolean;
  /** Rejoin automatically after a network drop. Default true. */
  autoReconnect?: boolean;
  /** Give up reconnecting after this long. Default 30 s. */
  reconnectTimeoutMs?: number;
}

export interface VoiceCallEvents {
  state: (state: VoiceCall['state']) => void;
  participantJoined: (p: CallParticipant) => void;
  /**
   * `left` = they hung up. `disconnected` = their network dropped; they may
   * come back (they reappear via participantJoined).
   */
  participantLeft: (p: CallParticipant, reason: 'left' | 'disconnected') => void;
  /** Mute state, hand, or name of a participant changed. */
  participantUpdated: (p: CallParticipant) => void;
  /** Remote audio arrived for a participant. */
  track: (p: CallParticipant) => void;
  activeSpeaker: (peerId: string | null) => void;
  reaction: (e: { peerId: string; displayName: string; emoji: string }) => void;
  /** Your network dropped — trying to get back in. */
  reconnecting: () => void;
  reconnected: () => void;
  /** The microphone could not be opened; you are in the call listen-only. */
  micUnavailable: (error: Error) => void;
  ended: (reason: CallEndReason) => void;
  error: (err: Error) => void;
}

/**
 * An audio call inside a conversation. Get one from `client.calls.start()`
 * or `client.calls.accept()`.
 */
export class VoiceCall extends Emitter<VoiceCallEvents> {
  readonly conversationId: string;
  /** True for the side that started the call. */
  readonly isCaller: boolean;
  state: 'connecting' | 'ringing' | 'connected' | 'reconnecting' | 'ended' = 'connecting';
  endReason: CallEndReason | null = null;
  readonly participants = new Map<string, CallParticipant>();
  localStream: MediaStream | null = null;
  muted = false;
  handRaised = false;
  /** Set when the microphone failed to open — the call continues listen-only. */
  micUnavailable: Error | null = null;
  /** Epoch ms when the first other person connected (for a call timer). */
  connectedAt = 0;

  private socket: Socket | null = null;
  private media: MediaSession | null = null;
  private mediaReady = false;
  private pending: Array<{ producerId: string; peerId: string; username: string }> = [];
  private ownsMedia = true;
  private ringTimer: ReturnType<typeof setTimeout> | null = null;
  private reconnectTimer: ReturnType<typeof setTimeout> | null = null;
  private aloneTimer: ReturnType<typeof setTimeout> | null = null;
  private readonly opts: Required<Omit<CallOptions, 'media' | 'muted'>>;

  constructor(
    private readonly ctx: MeetingContext,
    conversationId: string,
    isCaller: boolean,
    private readonly options: CallOptions = {}
  ) {
    super();
    this.conversationId = conversationId;
    this.isCaller = isCaller;
    this.muted = !!options.muted;
    this.opts = {
      ringTimeoutMs: options.ringTimeoutMs ?? 45_000,
      hangupWhenAlone: options.hangupWhenAlone ?? true,
      autoReconnect: options.autoReconnect ?? true,
      reconnectTimeoutMs: options.reconnectTimeoutMs ?? 30_000,
    };
  }

  /** @internal — used by CallsModule. Rejects with `call-ended` if the call ended meanwhile. */
  async connect(): Promise<void> {
    const session = this.ctx.getSession();
    if (!session) throw new TeleconfError('Not signed in', 'unauthorized');
    try {
      await this.openMic();
      this.checkAlive();

      const socket = openSocket(this.ctx.serverUrl, session.token);
      this.socket = socket;
      // Listen before the first await: someone answering very fast must not
      // be missed (finding A2). Producers wait in `pending` until media is up.
      this.bindEvents(socket);
      await waitConnected(socket);
      this.checkAlive();
      await this.handshake();
    } catch (err) {
      if (this.state === 'ended') {
        throw new TeleconfError(`Call ended (${this.endReason})`, 'call-ended');
      }
      await this.hangup('error');
      throw err;
    }
  }

  setMuted(muted: boolean): void {
    this.muted = muted;
    this.localStream?.getAudioTracks().forEach((t) => (t.enabled = !muted));
    const producer = this.media?.producers.get('mic-call');
    if (producer) muted ? producer.pause() : producer.resume();
    this.socket?.emit('setMicState', { enabled: !muted });
  }

  toggleMute(): void {
    this.setMuted(!this.muted);
  }

  async switchMicrophone(deviceId: string): Promise<void> {
    const s = await this.ctx.devices.getLocalStream({ audio: true, video: false, microphoneId: deviceId });
    await this.setOutgoingAudioTrack(s.getAudioTracks()[0], true);
  }

  /**
   * Send a different audio track (e.g. a noise-suppressed one). With
   * `replaceLocal`, it also replaces the track in `localStream`.
   */
  async setOutgoingAudioTrack(track: MediaStreamTrack, replaceLocal = false): Promise<void> {
    track.enabled = !this.muted;
    const producer = this.media?.producers.get('mic-call');
    if (producer) await producer.replaceTrack({ track });
    else if (this.mediaReady) await this.produceMic(track);
    if (replaceLocal) {
      this.localStream ??= new MediaStream();
      const old = this.localStream.getAudioTracks()[0];
      if (old) {
        this.localStream.removeTrack(old);
        if (this.ownsMedia) old.stop();
      }
      this.localStream.addTrack(track);
    }
    this.micUnavailable = null;
  }

  sendReaction(emoji: string): void {
    this.socket?.emit('reaction', { emoji });
  }

  async raiseHand(raised = true): Promise<void> {
    if (!this.socket) return;
    await request(this.socket, 'raiseHand', { raised });
    this.handRaised = raised;
  }

  /** Hang up. Safe to call more than once. */
  async hangup(reason: CallEndReason = 'left'): Promise<void> {
    if (this.state === 'ended') return;
    if (this.socket?.connected) {
      // call:leave (not just a disconnect) is what frees the server-side call;
      // when we were the last one in it also closes everyone's ringing toast.
      await request(this.socket, 'call:leave', { conversationId: this.conversationId }, 5000).catch(() => {});
    }
    this.finish(reason);
  }

  /** @internal — CallsModule routes server-side call events here. */
  remoteEnded(reason: CallEndReason): void {
    this.finish(reason);
  }

  // ------------------------------------------------------------- internals

  private async openMic() {
    const m = this.options.media;
    if (m instanceof MediaStream) {
      this.localStream = m;
      this.ownsMedia = false;
    } else {
      try {
        this.localStream = await this.ctx.devices.getLocalStream({
          audio: true,
          video: false,
          microphoneId: m?.microphoneId,
        });
      } catch (err) {
        // Mic busy / blocked: still join and listen (finding A9).
        this.localStream = new MediaStream();
        this.micUnavailable = err as Error;
        this.emit('micUnavailable', err as Error);
      }
    }
    // Ended while the mic was opening (e.g. declined): release it (finding A6).
    if (this.state === 'ended') this.releaseMedia();
    this.localStream?.getAudioTracks().forEach((t) => (t.enabled = !this.muted));
  }

  private checkAlive() {
    if (this.state === 'ended') throw new TeleconfError(`Call ended (${this.endReason})`, 'call-ended');
  }

  /** call:accept → media → publish → consume. Also used to rejoin after a drop. */
  private async handshake() {
    const socket = this.socket!;
    const res = await request<any>(socket, 'call:accept', { conversationId: this.conversationId });
    this.checkAlive();
    this.media = new MediaSession(socket);
    await this.media.load(res.rtpCapabilities);
    this.checkAlive();

    const track = this.localStream?.getAudioTracks()[0];
    if (track) await this.produceMic(track);
    socket.emit('setMicState', { enabled: !!track && !this.muted });

    for (const p of res.peers || []) this.addPeer(p.peerId, p.username);
    this.mediaReady = true;
    const queued = [...(res.existingProducers || []), ...this.pending];
    this.pending = [];
    for (const p of queued) await this.consume(p.producerId, p.peerId, p.username);

    if (this.participants.size > 0) this.markConnected();
    else if (this.state !== 'connected') {
      this.setState('ringing');
      if (this.isCaller && this.opts.ringTimeoutMs > 0 && !this.ringTimer) {
        this.ringTimer = setTimeout(() => {
          if (this.participants.size === 0) void this.hangup('no-answer');
        }, this.opts.ringTimeoutMs);
      }
    }
  }

  private async produceMic(track: MediaStreamTrack) {
    const producer = await this.media!.produce('mic-call', track, {
      codecOptions: MIC_CODEC_OPTIONS,
      encodings: MIC_ENCODINGS,
    });
    if (this.muted) producer.pause();
  }

  private bindEvents(socket: Socket) {
    socket.on('peerJoined', ({ peerId, username }) => this.addPeer(peerId, username));
    socket.on('peerLeft', ({ peerId, reason }) => this.removePeer(peerId, reason === 'disconnected' ? 'disconnected' : 'left'));
    socket.on('newProducer', ({ producerId, peerId, username }) => {
      if (!this.mediaReady) this.pending.push({ producerId, peerId, username });
      else void this.consume(producerId, peerId, username);
    });
    socket.on('activeSpeaker', ({ peerId }) => this.emit('activeSpeaker', peerId ?? null));
    socket.on('micState', ({ peerId, enabled }) => this.patch(peerId, { muted: !enabled }));
    socket.on('handState', ({ peerId, raised }) => this.patch(peerId, { handRaised: !!raised }));
    socket.on('nameChanged', ({ peerId, name }) => this.patch(peerId, { displayName: name }));
    socket.on('reaction', ({ peerId, username, emoji }) => this.emit('reaction', { peerId, displayName: username, emoji }));
    socket.on('session:revoked', () => this.finish('error'));

    socket.on('disconnect', (reason) => {
      if (this.state === 'ended' || reason === 'io client disconnect') return;
      if (!this.opts.autoReconnect || reason === 'io server disconnect' || !this.mediaReady) {
        this.finish('error');
        return;
      }
      // Network drop (finding A5): keep the call, rebuild on reconnect.
      this.mediaReady = false;
      this.setState('reconnecting');
      this.emit('reconnecting');
      this.reconnectTimer = setTimeout(() => this.finish('error'), this.opts.reconnectTimeoutMs);
    });
    socket.on('connect', () => {
      if (this.state !== 'reconnecting') return;
      void this.rejoin();
    });
  }

  private async rejoin() {
    this.media?.close();
    this.media = null;
    // The server dropped us from the call; rebuild the roster from scratch.
    for (const p of Array.from(this.participants.values())) {
      this.participants.delete(p.peerId);
      this.emit('participantLeft', p, 'disconnected');
    }
    try {
      await this.handshake();
      if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
      if (this.participants.size > 0) this.setState('connected');
      this.emit('reconnected');
    } catch (err) {
      // The call ended while we were away ("No active call") or rejoin failed.
      const gone = err instanceof TeleconfError && err.code === 'not-found';
      this.finish(gone ? 'ended' : 'error');
    }
  }

  private addPeer(peerId: string, username: string) {
    if (this.participants.has(peerId)) return;
    const p: CallParticipant = { peerId, displayName: username, stream: new MediaStream(), muted: false, handRaised: false };
    this.participants.set(peerId, p);
    if (this.aloneTimer) clearTimeout(this.aloneTimer);
    this.aloneTimer = null;
    this.emit('participantJoined', p);
    this.markConnected();
  }

  private removePeer(peerId: string, reason: 'left' | 'disconnected') {
    const p = this.participants.get(peerId);
    if (!p) return;
    for (const c of Array.from(this.media?.consumed.values() ?? [])) {
      if (c.peerId === peerId) this.media?.dropProducer(c.producerId);
    }
    this.participants.delete(peerId);
    this.emit('participantLeft', p, reason);
    if (this.opts.hangupWhenAlone && this.participants.size === 0 && this.connectedAt) {
      // A dropped peer gets the same grace period we give ourselves.
      if (reason === 'left') void this.hangup('ended');
      else {
        this.aloneTimer = setTimeout(() => {
          if (this.participants.size === 0) void this.hangup('ended');
        }, this.opts.reconnectTimeoutMs);
      }
    }
  }

  private patch(peerId: string, changes: Partial<CallParticipant>) {
    const p = this.participants.get(peerId);
    if (!p) return;
    Object.assign(p, changes);
    this.emit('participantUpdated', p);
  }

  private async consume(producerId: string, peerId: string, username: string) {
    try {
      const entry = await this.media?.consume(producerId, peerId);
      if (!entry) return;
      this.addPeer(peerId, username);
      const p = this.participants.get(peerId)!;
      p.stream.getAudioTracks().forEach((t) => p.stream.removeTrack(t));
      p.stream.addTrack(entry.consumer.track);
      this.emit('track', p);
    } catch (err) {
      this.emit('error', err as Error);
    }
  }

  private markConnected() {
    if (this.state === 'connected' || this.state === 'ended' || this.state === 'reconnecting') return;
    if (this.ringTimer) clearTimeout(this.ringTimer);
    this.ringTimer = null;
    if (!this.connectedAt) this.connectedAt = Date.now();
    this.setState('connected');
  }

  private releaseMedia() {
    if (this.ownsMedia) this.localStream?.getTracks().forEach((t) => t.stop());
  }

  private finish(reason: CallEndReason) {
    if (this.state === 'ended') return;
    this.endReason = reason;
    for (const t of [this.ringTimer, this.reconnectTimer, this.aloneTimer]) if (t) clearTimeout(t);
    this.media?.close();
    this.media = null;
    this.mediaReady = false;
    if (this.socket) {
      this.socket.removeAllListeners();
      this.socket.disconnect();
      this.socket = null;
    }
    this.releaseMedia();
    this.setState('ended');
    this.emit('ended', reason);
  }

  private setState(s: VoiceCall['state']) {
    if (this.state === s) return;
    this.state = s;
    this.emit('state', s);
  }
}
