import { getBridge, type ScreenSource } from '../bridge';
import { TeleconfError } from '../errors';

export interface DeviceList {
  microphones: MediaDeviceInfo[];
  cameras: MediaDeviceInfo[];
  speakers: MediaDeviceInfo[];
}

export interface LocalMediaOptions {
  /** true, false, or constraints. Default true (echo cancellation + noise suppression on). */
  audio?: boolean | MediaTrackConstraints;
  /** true, false, or constraints. Default true (720p). */
  video?: boolean | MediaTrackConstraints;
  /** Shortcuts for a specific device. */
  microphoneId?: string;
  cameraId?: string;
}

const DEFAULT_AUDIO: MediaTrackConstraints = {
  echoCancellation: true,
  noiseSuppression: true,
  autoGainControl: true,
};
const DEFAULT_VIDEO: MediaTrackConstraints = {
  width: { ideal: 1280 },
  height: { ideal: 720 },
  frameRate: { ideal: 30 },
};

/** Camera / microphone / speaker / screen helpers. Available as `client.media`. */
export class MediaDevicesHelper {
  /** Lists devices. Labels are empty until mic/camera permission was granted once. */
  async list(): Promise<DeviceList> {
    const all = await navigator.mediaDevices.enumerateDevices();
    return {
      microphones: all.filter((d) => d.kind === 'audioinput'),
      cameras: all.filter((d) => d.kind === 'videoinput'),
      speakers: all.filter((d) => d.kind === 'audiooutput'),
    };
  }

  /** Fires when a device is plugged in or removed. Returns unsubscribe. */
  onChange(cb: () => void): () => void {
    navigator.mediaDevices.addEventListener('devicechange', cb);
    return () => navigator.mediaDevices.removeEventListener('devicechange', cb);
  }

  /**
   * Opens camera and/or microphone. If the camera is busy or missing it
   * falls back to audio-only instead of failing outright.
   */
  async getLocalStream(opts: LocalMediaOptions = {}): Promise<MediaStream> {
    const audio = buildConstraint(opts.audio ?? true, DEFAULT_AUDIO, opts.microphoneId);
    const video = buildConstraint(opts.video ?? true, DEFAULT_VIDEO, opts.cameraId);
    if (!audio && !video) return new MediaStream();
    try {
      return await navigator.mediaDevices.getUserMedia({ audio, video });
    } catch (err) {
      if (video && audio) {
        // Camera in use by another app / no camera: still let them talk.
        return navigator.mediaDevices.getUserMedia({ audio, video: false });
      }
      throw err;
    }
  }

  /** Route an <audio>/<video> element to a speaker (`deviceId` from `list().speakers`). */
  async setSpeaker(element: HTMLMediaElement, deviceId: string): Promise<void> {
    const el = element as HTMLMediaElement & { setSinkId?: (id: string) => Promise<void> };
    if (!el.setSinkId) throw new TeleconfError('setSinkId is not supported', 'unsupported');
    await el.setSinkId(deviceId);
  }

  /**
   * Screens/windows that can be shared, with thumbnails — for building your
   * own picker. Needs the preload bridge (desktopCapturer lives in main).
   */
  async getScreenSources(
    opts?: Parameters<NonNullable<ReturnType<typeof getBridge>>['screen']['getSources']>[0]
  ): Promise<ScreenSource[]> {
    const bridge = getBridge();
    if (!bridge) {
      throw new TeleconfError('getScreenSources() needs the preload bridge', 'unsupported');
    }
    return bridge.screen.getSources(opts);
  }

  /**
   * Capture a screen or window. With `sourceId` (from getScreenSources) that
   * exact source is captured; without it, the main-process handler decides
   * (system picker / your `pickSource` / primary screen).
   */
  async getDisplayStream(opts: { sourceId?: string; audio?: boolean; frameRate?: number } = {}): Promise<MediaStream> {
    const frameRate = opts.frameRate ?? 15;
    const bridge = getBridge();
    if (opts.sourceId && bridge) await bridge.screen.select(opts.sourceId);

    if (opts.sourceId && !bridge) {
      // No bridge: Chromium's legacy desktop-capture constraints still work in Electron.
      return navigator.mediaDevices.getUserMedia({
        audio: false,
        video: {
          mandatory: {
            chromeMediaSource: 'desktop',
            chromeMediaSourceId: opts.sourceId,
            maxFrameRate: frameRate,
          },
        },
      } as unknown as MediaStreamConstraints);
    }
    return navigator.mediaDevices.getDisplayMedia({
      video: { frameRate: { ideal: frameRate, max: 30 } },
      audio: opts.audio ?? true,
    });
  }
}

function buildConstraint(
  value: boolean | MediaTrackConstraints,
  defaults: MediaTrackConstraints,
  deviceId?: string
): false | MediaTrackConstraints {
  if (value === false) return false;
  const base = value === true ? { ...defaults } : { ...defaults, ...value };
  if (deviceId) base.deviceId = { exact: deviceId };
  return base;
}
