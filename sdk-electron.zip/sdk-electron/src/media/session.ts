import { Device } from 'mediasoup-client';
import type {
  Consumer,
  Producer,
  ProducerCodecOptions,
  RtpCapabilities,
  RtpEncodingParameters,
  Transport,
} from 'mediasoup-client/types';
import type { Socket } from 'socket.io-client';
import { request } from '../realtime';

/**
 * Producer `appData.source` values. They must match the web client exactly —
 * that is how web and desktop participants tell a camera from a screen share.
 */
export type MediaSource = 'camera' | 'mic' | 'screen-video' | 'screen-audio' | 'mic-call';

/**
 * Microphone tuned for weak networks: Opus in-band FEC rebuilds lost packets
 * (no "robotic voice"), DTX sends almost nothing in silence, mono, and top
 * network priority so voice wins over video when bandwidth runs short.
 */
export const MIC_CODEC_OPTIONS: ProducerCodecOptions = {
  opusFec: true,
  opusDtx: true,
  opusStereo: false,
};
export const MIC_ENCODINGS: RtpEncodingParameters[] = [
  { priority: 'high', networkPriority: 'high' },
];

/** Camera simulcast — the SFU forwards each viewer the layer their link can carry. */
export const CAMERA_SIMULCAST: RtpEncodingParameters[] = [
  { rid: 'r0', scaleResolutionDownBy: 4, maxBitrate: 150_000 },
  { rid: 'r1', scaleResolutionDownBy: 2, maxBitrate: 500_000 },
  { rid: 'r2', scaleResolutionDownBy: 1, maxBitrate: 1_200_000 },
];

export interface ConsumedTrack {
  consumer: Consumer;
  producerId: string;
  peerId: string;
  source: MediaSource;
}

/**
 * One mediasoup device + send/recv transport pair bound to a socket that has
 * already joined a room (meeting or call). Shared by Meeting and VoiceCall.
 */
export class MediaSession {
  device: Device | null = null;
  sendTransport: Transport | null = null;
  recvTransport: Transport | null = null;
  readonly producers = new Map<MediaSource, Producer>();
  /** keyed by producerId (the remote producer) */
  readonly consumed = new Map<string, ConsumedTrack>();

  constructor(private readonly socket: Socket) {}

  async load(routerRtpCapabilities: RtpCapabilities): Promise<void> {
    this.device = await Device.factory();
    await this.device.load({ routerRtpCapabilities });
    await this.createSendTransport();
    await this.createRecvTransport();
  }

  private async createSendTransport() {
    const { params } = await request<any>(this.socket, 'createTransport', { direction: 'send' });
    const transport = this.device!.createSendTransport(params);
    transport.on('connect', ({ dtlsParameters }, cb, errback) => {
      request(this.socket, 'connectTransport', { transportId: transport.id, dtlsParameters })
        .then(() => cb())
        .catch(errback);
    });
    transport.on('produce', ({ kind, rtpParameters, appData }, cb, errback) => {
      request<{ id: string }>(this.socket, 'produce', {
        transportId: transport.id,
        kind,
        rtpParameters,
        appData,
      })
        .then(({ id }) => cb({ id }))
        .catch(errback);
    });
    this.sendTransport = transport;
  }

  private async createRecvTransport() {
    const { params } = await request<any>(this.socket, 'createTransport', { direction: 'recv' });
    const transport = this.device!.createRecvTransport(params);
    transport.on('connect', ({ dtlsParameters }, cb, errback) => {
      request(this.socket, 'connectTransport', { transportId: transport.id, dtlsParameters })
        .then(() => cb())
        .catch(errback);
    });
    this.recvTransport = transport;
  }

  async produce(
    source: MediaSource,
    track: MediaStreamTrack,
    opts: { encodings?: RtpEncodingParameters[]; codecOptions?: ProducerCodecOptions } = {}
  ): Promise<Producer> {
    if (!this.sendTransport) throw new Error('Media session not loaded');
    this.closeProducer(source);
    const producer = await this.sendTransport.produce({
      track,
      encodings: opts.encodings,
      codecOptions: opts.codecOptions,
      // The app owns local tracks (they outlive producers on mute, device
      // switch, reconnect) — never let mediasoup stop them.
      stopTracks: false,
      appData: { source },
    });
    this.producers.set(source, producer);
    return producer;
  }

  /** Close a local producer and tell the room. */
  closeProducer(source: MediaSource): void {
    const producer = this.producers.get(source);
    if (!producer) return;
    producer.close();
    this.producers.delete(source);
    this.socket.emit('closeProducer', { producerId: producer.id });
  }

  async consume(producerId: string, peerId: string): Promise<ConsumedTrack | null> {
    if (!this.device || !this.recvTransport) return null;
    const data = await request<any>(this.socket, 'consume', {
      transportId: this.recvTransport.id,
      producerId,
      rtpCapabilities: this.device.recvRtpCapabilities,
    });
    const consumer = await this.recvTransport.consume({
      id: data.id,
      producerId: data.producerId,
      kind: data.kind,
      rtpParameters: data.rtpParameters,
    });
    await request(this.socket, 'resumeConsumer', { consumerId: consumer.id });
    const entry: ConsumedTrack = {
      consumer,
      producerId,
      peerId,
      source: (data.appData?.source as MediaSource) || (data.kind === 'audio' ? 'mic' : 'camera'),
    };
    this.consumed.set(producerId, entry);
    return entry;
  }

  /** Remote producer went away — returns what was consumed for it, if anything. */
  dropProducer(producerId: string): ConsumedTrack | undefined {
    const entry = this.consumed.get(producerId);
    if (!entry) return undefined;
    entry.consumer.close();
    this.consumed.delete(producerId);
    return entry;
  }

  /** Server-side consumer closed (`consumerClosed` event). */
  dropConsumer(consumerId: string): ConsumedTrack | undefined {
    for (const entry of this.consumed.values()) {
      if (entry.consumer.id === consumerId) return this.dropProducer(entry.producerId);
    }
    return undefined;
  }

  /** Round-trip time and loss on our uplink, for a coarse quality signal. */
  async uplinkStats(): Promise<{ rtt: number; loss: number } | null> {
    if (!this.sendTransport) return null;
    const stats = await this.sendTransport.getStats();
    let rtt = 0;
    let loss = 0;
    stats.forEach((r: any) => {
      if (r.type === 'candidate-pair' && r.nominated && r.currentRoundTripTime != null) {
        rtt = r.currentRoundTripTime;
      }
      if (r.type === 'remote-inbound-rtp' && r.fractionLost != null) {
        loss = Math.max(loss, r.fractionLost);
      }
    });
    return { rtt, loss };
  }

  close(): void {
    this.producers.forEach((p) => p.close());
    this.producers.clear();
    this.consumed.forEach((c) => c.consumer.close());
    this.consumed.clear();
    this.sendTransport?.close();
    this.recvTransport?.close();
    this.sendTransport = null;
    this.recvTransport = null;
    this.device = null;
  }
}
