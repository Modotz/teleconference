/**
 * Local recording with optional passphrase encryption.
 *
 * Same container as the web app ("TCREC1"), so an encrypted desktop recording
 * opens on the web's /recording/decrypt page and vice versa:
 *
 *   magic "TCREC1\0\0" | iterations u32 | salt 16B | { len u32 | iv 12B | AES-GCM ct }*
 *
 * Each chunk's index is its additional authenticated data, so chunks cannot be
 * reordered or dropped without decryption failing. No passphrase recovery.
 */

const MAGIC = new Uint8Array([0x54, 0x43, 0x52, 0x45, 0x43, 0x31, 0x00, 0x00]);
const SALT_LEN = 16;
const IV_LEN = 12;
const HEADER_LEN = MAGIC.length + 4 + SALT_LEN;
const PBKDF2_ITERATIONS = 250_000;

export const ENCRYPTED_EXTENSION = '.webm.enc';
export const MIN_PASSPHRASE_LENGTH = 8;

function aad(index: number): Uint8Array {
  const buf = new ArrayBuffer(8);
  new DataView(buf).setBigUint64(0, BigInt(index));
  return new Uint8Array(buf);
}

async function deriveKey(passphrase: string, salt: Uint8Array, iterations: number) {
  const material = await crypto.subtle.importKey(
    'raw',
    new TextEncoder().encode(passphrase),
    'PBKDF2',
    false,
    ['deriveKey']
  );
  return crypto.subtle.deriveKey(
    { name: 'PBKDF2', salt: salt as BufferSource, iterations, hash: 'SHA-256' },
    material,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt']
  );
}

export interface RecorderOptions {
  /** Encrypt every chunk (min 8 chars). Output becomes `.webm.enc`. */
  passphrase?: string;
  /** Called with each finished chunk — e.g. append to a file via IPC for long meetings. */
  onChunk?: (chunk: ArrayBuffer) => void;
  /** Chunk interval in ms. Default 1000. */
  timeslice?: number;
}

/**
 * Records any MediaStream (e.g. `meeting.localStream`, a screen share, or a
 * canvas composite you build). Records only what this client has — not a
 * server-side mix of everyone.
 */
export class MeetingRecorder {
  private recorder: MediaRecorder | null = null;
  private parts: ArrayBuffer[] = [];
  private chain: Promise<void> = Promise.resolve();
  private key: CryptoKey | null = null;
  private index = 0;
  private startedAt = 0;
  readonly encrypted: boolean;

  constructor(private readonly stream: MediaStream, private readonly opts: RecorderOptions = {}) {
    if (opts.passphrase !== undefined && opts.passphrase.length < MIN_PASSPHRASE_LENGTH) {
      throw new Error(`Passphrase must be at least ${MIN_PASSPHRASE_LENGTH} characters`);
    }
    this.encrypted = !!opts.passphrase;
  }

  get recording(): boolean {
    return !!this.recorder && this.recorder.state !== 'inactive';
  }

  /** Seconds since start. */
  get elapsed(): number {
    return this.startedAt ? Math.floor((Date.now() - this.startedAt) / 1000) : 0;
  }

  /** Suggested file name extension. */
  get extension(): string {
    return this.encrypted ? ENCRYPTED_EXTENSION : '.webm';
  }

  async start(): Promise<void> {
    if (this.recorder) return;
    if (this.opts.passphrase) {
      // PBKDF2 is deliberately slow — derive before capture starts.
      const salt = crypto.getRandomValues(new Uint8Array(SALT_LEN));
      this.key = await deriveKey(this.opts.passphrase, salt, PBKDF2_ITERATIONS);
      const header = new ArrayBuffer(HEADER_LEN);
      new Uint8Array(header).set(MAGIC, 0);
      new DataView(header).setUint32(MAGIC.length, PBKDF2_ITERATIONS);
      new Uint8Array(header).set(salt, MAGIC.length + 4);
      this.push(header);
    }

    const mimeType = ['video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm'].find(
      (t) => MediaRecorder.isTypeSupported(t)
    );
    const recorder = new MediaRecorder(this.stream, mimeType ? { mimeType } : undefined);
    recorder.ondataavailable = (e) => {
      if (!e.data.size) return;
      // Encryption is async; chain so chunks keep their order.
      this.chain = this.chain.then(async () => {
        const plain = await e.data.arrayBuffer();
        this.push(this.key ? await this.seal(plain) : plain);
      });
    };
    recorder.start(this.opts.timeslice ?? 1000);
    this.recorder = recorder;
    this.startedAt = Date.now();
  }

  /** Stops and resolves with the whole recording. */
  async stop(): Promise<Blob> {
    const recorder = this.recorder;
    if (!recorder) return new Blob(this.parts, { type: this.mime() });
    await new Promise<void>((resolve) => {
      recorder.onstop = () => resolve();
      recorder.stop();
    });
    await this.chain;
    this.recorder = null;
    this.startedAt = 0;
    return new Blob(this.parts, { type: this.mime() });
  }

  private mime() {
    return this.encrypted ? 'application/octet-stream' : 'video/webm';
  }

  private push(buf: ArrayBuffer) {
    if (this.opts.onChunk) this.opts.onChunk(buf);
    this.parts.push(buf);
  }

  private async seal(plain: ArrayBuffer): Promise<ArrayBuffer> {
    const iv = crypto.getRandomValues(new Uint8Array(IV_LEN));
    const ct = new Uint8Array(
      await crypto.subtle.encrypt(
        { name: 'AES-GCM', iv: iv as BufferSource, additionalData: aad(this.index) as BufferSource },
        this.key!,
        plain
      )
    );
    this.index += 1;
    const out = new ArrayBuffer(4 + IV_LEN + ct.length);
    new DataView(out).setUint32(0, IV_LEN + ct.length);
    new Uint8Array(out).set(iv, 4);
    new Uint8Array(out).set(ct, 4 + IV_LEN);
    return out;
  }
}

/** Decrypt a `.webm.enc` (from desktop or web) back into a playable Blob. */
export async function decryptRecording(
  file: Blob,
  passphrase: string,
  onProgress?: (fraction: number) => void
): Promise<Blob> {
  if (file.size < HEADER_LEN) throw new Error('File is too small to be a recording.');
  const header = new Uint8Array(await file.slice(0, HEADER_LEN).arrayBuffer());
  if (!MAGIC.every((b, i) => header[i] === b)) {
    throw new Error('Not an encrypted recording (bad file header).');
  }
  const iterations = new DataView(header.buffer).getUint32(MAGIC.length);
  const key = await deriveKey(passphrase, header.slice(MAGIC.length + 4, HEADER_LEN), iterations);

  const parts: ArrayBuffer[] = [];
  let offset = HEADER_LEN;
  let index = 0;
  while (offset < file.size) {
    if (offset + 4 > file.size) throw new Error('Recording is truncated.');
    const len = new DataView(await file.slice(offset, offset + 4).arrayBuffer()).getUint32(0);
    offset += 4;
    if (len <= IV_LEN || offset + len > file.size) throw new Error('Recording is truncated or corrupt.');
    const block = new Uint8Array(await file.slice(offset, offset + len).arrayBuffer());
    offset += len;
    try {
      parts.push(
        await crypto.subtle.decrypt(
          {
            name: 'AES-GCM',
            iv: block.subarray(0, IV_LEN) as BufferSource,
            additionalData: aad(index) as BufferSource,
          },
          key,
          block.subarray(IV_LEN)
        )
      );
    } catch {
      throw new Error(
        index === 0
          ? 'Wrong passphrase, or the file has been modified.'
          : `Recording is damaged (chunk ${index + 1} failed to decrypt).`
      );
    }
    index += 1;
    onProgress?.(offset / file.size);
  }
  if (!parts.length) throw new Error('Recording is empty.');
  return new Blob(parts, { type: 'video/webm' });
}
