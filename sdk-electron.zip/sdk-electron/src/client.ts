import { getBridge } from './bridge';
import { Emitter } from './emitter';
import { TeleconfError } from './errors';
import { Http } from './http';
import { Realtime, type ConnectionState } from './realtime';
import { MediaDevicesHelper } from './media/devices';
import type { MeetingContext } from './meeting';
import { electronSessionStore, memorySessionStore, type SessionStore } from './session-store';
import { AdminModule, AuthModule, UsersModule, type DeviceInfo } from './modules/auth';
import { AgendaModule, BookingsModule } from './modules/agenda';
import { ChatModule } from './modules/chat';
import { CallsModule } from './modules/calls';
import { MeetingsModule } from './modules/meetings';
import { CalendarModule } from './modules/calendar';
import { ActivityModule } from './modules/activity';
import type { Session, User } from './types';

export interface TeleconfClientOptions {
  /** Backend base URL, e.g. `https://api.example.com` (no `/api`). */
  serverUrl: string;
  /** Web app URL, used to build shareable meeting links. e.g. `https://meet.example.com`. */
  webUrl?: string;
  /**
   * Where to persist the session. Default: `electronSessionStore()` when the
   * preload bridge is present (OS-encrypted), otherwise in-memory.
   */
  sessionStore?: SessionStore;
  /**
   * Reported at login so users (and admins) can tell sessions apart.
   * Default `{ deviceType: 'desktop' }`.
   */
  device?: DeviceInfo;
}

export interface TeleconfClientEvents {
  /** Signed in, switched account, or signed out (null). */
  session: (session: Session | null) => void;
  /** The token expired or was rejected — show the login screen. */
  sessionExpired: () => void;
  /**
   * This device was signed out remotely (logout elsewhere, revoked by the
   * user or an admin, account deactivated). Local data should be wiped.
   * `sessionExpired` fires too.
   */
  sessionRevoked: () => void;
  /** Realtime connection state (chat, call invites). */
  connection: (state: ConnectionState) => void;
}

/**
 * Entry point. One instance per app window.
 *
 *   const client = new TeleconfClient({ serverUrl: 'https://api.example.com' });
 *   await client.init();               // restores a saved session, if any
 *   if (!client.user) await client.auth.login(email, password);
 */
export class TeleconfClient extends Emitter<TeleconfClientEvents> {
  readonly serverUrl: string;
  readonly webUrl?: string;

  readonly auth: AuthModule;
  readonly users: UsersModule;
  readonly chat: ChatModule;
  readonly calls: CallsModule;
  readonly meetings: MeetingsModule;
  readonly calendar: CalendarModule;
  readonly activity: ActivityModule;
  /** Agenda (Tahap 2 scaffold). */
  readonly agenda: AgendaModule;
  /** Room booking (Tahap 2 scaffold). */
  readonly bookings: BookingsModule;
  /** HR / IT admin actions (needs hr_admin or it_admin role). */
  readonly admin: AdminModule;
  /** Devices, screen sources, speaker routing. */
  readonly media = new MediaDevicesHelper();

  private session: Session | null = null;
  private readonly store: SessionStore;
  private readonly http: Http;
  private readonly rt: Realtime;

  constructor(options: TeleconfClientOptions) {
    super();
    if (!options.serverUrl) throw new TeleconfError('serverUrl is required', 'bad-request');
    this.serverUrl = options.serverUrl.replace(/\/+$/, '');
    this.webUrl = options.webUrl?.replace(/\/+$/, '');
    this.store = options.sessionStore ?? (getBridge() ? electronSessionStore() : memorySessionStore());

    this.http = new Http({
      serverUrl: this.serverUrl,
      getToken: () => this.session?.token ?? null,
      onUnauthorized: (revoked) => void this.expire(revoked),
    });
    this.rt = new Realtime(this.serverUrl);
    this.rt.on('state', (s) => this.emit('connection', s));
    this.rt.on('authError', () => void this.expire());
    this.rt.listen('session:revoked', () => void this.expire(true));

    const ctx: MeetingContext = {
      serverUrl: this.serverUrl,
      http: this.http,
      devices: this.media,
      getSession: () => this.session,
    };
    const me = () => this.session?.user ?? null;

    this.auth = new AuthModule(this.http, (s) => this.setSession(s), options.device ?? { deviceType: 'desktop' });
    this.users = new UsersModule(this.http, this.rt);
    this.admin = new AdminModule(this.http);
    this.agenda = new AgendaModule(this.http, this.rt);
    this.bookings = new BookingsModule(this.http);
    this.chat = new ChatModule(this.http, this.rt, me);
    this.calls = new CallsModule(ctx, this.rt);
    this.meetings = new MeetingsModule(this.http, ctx, this.webUrl);
    this.calendar = new CalendarModule(this.meetings);
    this.activity = new ActivityModule(this.meetings, this.chat, this.calls, me);
  }

  /**
   * Restore the saved session and connect. Resolves with the user, or null
   * if nobody is signed in (or the saved token has expired).
   */
  async init(): Promise<User | null> {
    const saved = await this.store.get();
    if (!saved?.token) return null;
    if (isExpired(saved.token)) {
      await this.store.set(null);
      return null;
    }
    this.session = saved;
    if (!saved.user.guest) {
      try {
        // Refresh the profile and confirm the token is still accepted.
        const user = await this.auth.me();
        this.session = { token: saved.token, user };
      } catch (err) {
        // Offline is fine (we'll reconnect); a rejected token is not.
        if (err instanceof TeleconfError && err.code === 'unauthorized') return null;
      }
    }
    await this.setSession(this.session);
    return this.session?.user ?? null;
  }

  get user(): User | null {
    return this.session?.user ?? null;
  }

  get token(): string | null {
    return this.session?.token ?? null;
  }

  get isGuest(): boolean {
    return !!this.session?.user.guest;
  }

  get connectionState(): ConnectionState {
    return this.rt.state;
  }

  /** Resolves when the realtime connection is up (chat send, calls need it). */
  waitUntilConnected(timeoutMs?: number): Promise<void> {
    return this.rt.waitConnected(timeoutMs);
  }

  /** Disconnect everything. Call when the window closes. */
  async destroy(): Promise<void> {
    await this.calls.active?.hangup();
    this.rt.disconnect();
    this.removeAllListeners();
  }

  private async setSession(session: Session | null) {
    const sameToken = session?.token === this.session?.token && this.rt.state !== 'disconnected';
    this.session = session;
    await this.store.set(session);
    // Guests have no chat/calls — no realtime channel for them.
    if (session && !session.user.guest) {
      if (!sameToken) this.rt.connect(session.token);
    } else {
      this.rt.disconnect();
    }
    this.emit('session', session);
  }

  private async expire(revoked = false) {
    if (!this.session) return;
    await this.calls.active?.hangup('error');
    await this.setSession(null);
    if (revoked) this.emit('sessionRevoked');
    this.emit('sessionExpired');
  }
}

/** Reads the JWT `exp` claim (no signature check — the server does that). */
function isExpired(token: string): boolean {
  try {
    const part = token.split('.')[1];
    const json = JSON.parse(atob(part.replace(/-/g, '+').replace(/_/g, '/')));
    return typeof json.exp === 'number' && json.exp * 1000 <= Date.now();
  } catch {
    return false;
  }
}
