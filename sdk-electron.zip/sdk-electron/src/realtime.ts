import { io, type Socket } from 'socket.io-client';
import { Emitter } from './emitter';
import { TeleconfError, socketError } from './errors';

export type ConnectionState = 'disconnected' | 'connecting' | 'connected' | 'reconnecting';

const DEFAULT_TIMEOUT = 15_000;
/** Handshake rejections that will never succeed by retrying. */
const AUTH_ERRORS = new Set(['Invalid token', 'No token', 'Session revoked']);

export function openSocket(serverUrl: string, token: string): Socket {
  return io(serverUrl, {
    auth: { token },
    // Electron is Chromium: websockets always work, and skipping long-polling
    // also sidesteps CORS for the realtime channel.
    transports: ['websocket'],
    reconnection: true,
    reconnectionDelay: 1000,
    reconnectionDelayMax: 5000,
  });
}

export function waitConnected(socket: Socket, timeoutMs = DEFAULT_TIMEOUT): Promise<void> {
  if (socket.connected) return Promise.resolve();
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      cleanup();
      reject(new TeleconfError('Realtime connection timed out', 'timeout'));
    }, timeoutMs);
    const onConnect = () => {
      cleanup();
      resolve();
    };
    const onError = (err: Error) => {
      // Middleware rejections never retry; transport errors do, so keep waiting.
      if (AUTH_ERRORS.has(err.message)) {
        cleanup();
        reject(new TeleconfError('Session expired', 'unauthorized', 401));
      }
    };
    const cleanup = () => {
      clearTimeout(timer);
      socket.off('connect', onConnect);
      socket.off('connect_error', onError);
    };
    socket.on('connect', onConnect);
    socket.on('connect_error', onError);
  });
}

/** Emit with an acknowledgement; rejects on `{ error }` replies and timeouts. */
export function request<T = any>(
  socket: Socket,
  event: string,
  data?: unknown,
  timeoutMs = DEFAULT_TIMEOUT
): Promise<T> {
  return new Promise((resolve, reject) => {
    socket.timeout(timeoutMs).emit(event, data, (err: Error | null, response: any) => {
      if (err) return reject(new TeleconfError(`No response to "${event}"`, 'timeout'));
      if (response?.error) return reject(socketError(String(response.error), response.code));
      resolve(response as T);
    });
  });
}

/**
 * The account's long-lived realtime connection: chat events, call invites,
 * read receipts. Meetings and calls open their own sockets (the server binds
 * one media room per socket), so this one is never torn down by them.
 */
export class Realtime extends Emitter<{
  state: (state: ConnectionState) => void;
  /** Came back after a drop — re-subscribe anything server-side. */
  reconnected: () => void;
  /** The server rejected the token. */
  authError: () => void;
}> {
  private socket: Socket | null = null;
  private everConnected = false;
  private handlers = new Map<string, Set<(...args: any[]) => void>>();
  state: ConnectionState = 'disconnected';

  constructor(private readonly serverUrl: string) {
    super();
  }

  connect(token: string): void {
    this.disconnect();
    const socket = openSocket(this.serverUrl, token);
    this.socket = socket;
    this.everConnected = false;
    this.setState('connecting');

    for (const [event, set] of this.handlers) {
      for (const fn of set) socket.on(event, fn);
    }
    socket.on('connect', () => {
      const again = this.everConnected;
      this.everConnected = true;
      this.setState('connected');
      if (again) this.emit('reconnected');
    });
    socket.on('disconnect', (reason) => {
      this.setState(reason === 'io client disconnect' ? 'disconnected' : 'reconnecting');
    });
    socket.on('connect_error', (err) => {
      if (AUTH_ERRORS.has(err.message)) {
        this.setState('disconnected');
        this.emit('authError');
      } else if (this.state !== 'connecting') {
        this.setState('reconnecting');
      }
    });
  }

  disconnect(): void {
    if (!this.socket) return;
    this.socket.removeAllListeners();
    this.socket.disconnect();
    this.socket = null;
    this.setState('disconnected');
  }

  get connected(): boolean {
    return !!this.socket?.connected;
  }

  waitConnected(timeoutMs?: number): Promise<void> {
    if (!this.socket) return Promise.reject(new TeleconfError('Not signed in', 'not-connected'));
    return waitConnected(this.socket, timeoutMs);
  }

  /** Listen to a raw server event; survives reconnects and re-logins. */
  listen(event: string, fn: (...args: any[]) => void): () => void {
    let set = this.handlers.get(event);
    if (!set) {
      set = new Set();
      this.handlers.set(event, set);
    }
    set.add(fn);
    this.socket?.on(event, fn);
    return () => {
      set!.delete(fn);
      this.socket?.off(event, fn);
    };
  }

  async request<T = any>(event: string, data?: unknown, timeoutMs?: number): Promise<T> {
    if (!this.socket) throw new TeleconfError('Not signed in', 'not-connected');
    await this.waitConnected();
    return request<T>(this.socket, event, data, timeoutMs);
  }

  /** Fire-and-forget emit (for server events without an acknowledgement). */
  send(event: string, data?: unknown): void {
    this.socket?.emit(event, data);
  }

  private setState(state: ConnectionState) {
    if (this.state === state) return;
    this.state = state;
    this.emit('state', state);
  }
}
