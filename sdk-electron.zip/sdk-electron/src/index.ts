/**
 * @teleconf/electron-sdk — renderer entry.
 *
 * Main-process helpers:  `@teleconf/electron-sdk/main`
 * Preload bridge:        `@teleconf/electron-sdk/preload`
 */
export { TeleconfClient } from './client';
export type { TeleconfClientOptions, TeleconfClientEvents } from './client';

export { Meeting } from './meeting';
export type {
  MeetingState,
  LeaveReason,
  Participant,
  LocalParticipant,
  JoinOptions,
  MeetingInfo,
  MeetingEvents,
  WaitingPeer,
} from './meeting';

export { VoiceCall } from './voice-call';
export type { CallOptions, CallParticipant, CallEndReason, VoiceCallEvents } from './voice-call';

export type { AuthModule, UsersModule, AdminModule, DeviceInfo } from './modules/auth';
export type { AgendaModule, AgendaEvents, BookingsModule } from './modules/agenda';
export type { ChatModule, ChatEvents, SendMessageInput, SearchOptions } from './modules/chat';
export type { CallsModule, CallsEvents } from './modules/calls';
export type { MeetingsModule } from './modules/meetings';
export type { CalendarModule, ScheduledMeeting, ScheduleInput } from './modules/calendar';
export type { ActivityModule, ActivityItem, ActivityKind, ActivityFilter } from './modules/activity';

export { MediaDevicesHelper } from './media/devices';
export type { DeviceList, LocalMediaOptions } from './media/devices';
export type { MediaSource } from './media/session';
export {
  MeetingRecorder,
  decryptRecording,
  ENCRYPTED_EXTENSION,
  MIN_PASSPHRASE_LENGTH,
} from './media/recorder';
export type { RecorderOptions } from './media/recorder';

export {
  memorySessionStore,
  localStorageSessionStore,
  electronSessionStore,
} from './session-store';
export type { SessionStore } from './session-store';

export { getBridge } from './bridge';
export type { TeleconfBridge, ScreenSource } from './bridge';

export { TeleconfError } from './errors';
export type { TeleconfErrorCode } from './errors';
export type { ConnectionState } from './realtime';
export { Emitter } from './emitter';
export * from './types';
