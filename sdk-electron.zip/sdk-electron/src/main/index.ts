/**
 * @teleconf/electron-sdk/main — call once from the Electron main process.
 *
 *   import { setupTeleconfMain } from '@teleconf/electron-sdk/main';
 *   app.whenReady().then(() => {
 *     setupTeleconfMain({ deepLink: { scheme: 'teleconf' } });
 *     createWindow();
 *   });
 */
import {
  app,
  BrowserWindow,
  desktopCapturer,
  ipcMain,
  safeStorage,
  session as electronSession,
  systemPreferences,
  type DesktopCapturerSource,
  type Session as ElectronSession,
} from 'electron';
import fs from 'fs';
import path from 'path';
import { CHANNELS } from '../preload/channels';

export interface TeleconfMainOptions {
  /** Session to configure. Default `session.defaultSession`. */
  session?: ElectronSession;

  /**
   * Auto-grant camera/mic/screen/notification permission to your own pages.
   * `true` (default) trusts `file://` pages and `allowedOrigins`.
   * `false` leaves permission handling to you.
   */
  permissions?: boolean;
  /** Extra origins to trust, e.g. your dev server `http://localhost:5173`. */
  allowedOrigins?: string[];

  /** Screen sharing (getDisplayMedia). `false` to skip. */
  screenShare?:
    | false
    | {
        /**
         * Choose a source when the renderer did not preselect one. Return
         * null to cancel. Default: the primary screen.
         */
        pickSource?: (sources: DesktopCapturerSource[]) => Promise<DesktopCapturerSource | null> | DesktopCapturerSource | null;
        /** Use the OS picker where Electron supports it (macOS 15+). Default false. */
        useSystemPicker?: boolean;
        /** Share system audio (Windows only, "loopback"). Default true. */
        systemAudio?: boolean;
      };

  /** Persist the login session encrypted with the OS keychain. Default true. */
  secureSession?: boolean | { fileName?: string };

  /**
   * Open the app from links like `teleconf://room/<id>`. URLs are forwarded
   * to the renderer (`bridge.onDeepLink`). Requires a single-instance app.
   */
  deepLink?: { scheme: string; onLink?: (url: string) => void };
}

const MEDIA_PERMISSIONS = new Set([
  'media',
  'display-capture',
  'notifications',
  'fullscreen',
  'clipboard-sanitized-write',
  'speaker-selection',
]);

/** Install the IPC handlers and session hooks the SDK relies on. Returns a disposer. */
export function setupTeleconfMain(options: TeleconfMainOptions = {}): () => void {
  const ses = options.session ?? electronSession.defaultSession;
  const disposers: Array<() => void> = [];

  if (options.permissions !== false) {
    const trusted = (url: string | undefined) => {
      if (!url) return false;
      if (url.startsWith('file://')) return true;
      try {
        const origin = new URL(url).origin;
        return (options.allowedOrigins ?? []).includes(origin);
      } catch {
        return false;
      }
    };
    ses.setPermissionRequestHandler((wc, permission, callback, details) => {
      callback(MEDIA_PERMISSIONS.has(permission) && trusted(details.requestingUrl || wc.getURL()));
    });
    ses.setPermissionCheckHandler((wc, permission, requestingOrigin) => {
      return MEDIA_PERMISSIONS.has(permission) && trusted(requestingOrigin || wc?.getURL());
    });
    disposers.push(() => {
      ses.setPermissionRequestHandler(null);
      ses.setPermissionCheckHandler(null);
    });
  }

  if (options.screenShare !== false) {
    const cfg = options.screenShare ?? {};
    let preselected: string | null = null;

    ipcMain.handle(CHANNELS.screenSources, async (_e, opts?: { types?: Array<'screen' | 'window'>; thumbnailSize?: { width: number; height: number } }) => {
      const sources = await desktopCapturer.getSources({
        types: opts?.types ?? ['screen', 'window'],
        thumbnailSize: opts?.thumbnailSize ?? { width: 320, height: 180 },
        fetchWindowIcons: true,
      });
      return sources.map((s) => ({
        id: s.id,
        name: s.name,
        thumbnail: s.thumbnail.toDataURL(),
        appIcon: s.appIcon && !s.appIcon.isEmpty() ? s.appIcon.toDataURL() : null,
        kind: s.id.startsWith('screen:') ? 'screen' : 'window',
      }));
    });
    ipcMain.handle(CHANNELS.screenSelect, (_e, id: string) => {
      preselected = typeof id === 'string' ? id : null;
    });

    ses.setDisplayMediaRequestHandler(
      async (request, callback) => {
        try {
          const sources = await desktopCapturer.getSources({ types: ['screen', 'window'] });
          let chosen: DesktopCapturerSource | null | undefined = preselected
            ? sources.find((s) => s.id === preselected)
            : undefined;
          preselected = null;
          if (!chosen) {
            chosen = cfg.pickSource
              ? await cfg.pickSource(sources)
              : sources.find((s) => s.id.startsWith('screen:')) ?? sources[0] ?? null;
          }
          if (!chosen) return callback({});
          const audio =
            request.audioRequested && process.platform === 'win32' && cfg.systemAudio !== false
              ? ('loopback' as const)
              : undefined;
          callback(audio ? { video: chosen, audio } : { video: chosen });
        } catch (err) {
          console.error('[teleconf] display media request failed', err);
          callback({});
        }
      },
      { useSystemPicker: !!cfg.useSystemPicker }
    );
    disposers.push(() => {
      ipcMain.removeHandler(CHANNELS.screenSources);
      ipcMain.removeHandler(CHANNELS.screenSelect);
      ses.setDisplayMediaRequestHandler(null);
    });
  }

  if (options.secureSession !== false) {
    const fileName =
      (typeof options.secureSession === 'object' && options.secureSession.fileName) || 'teleconf-session.bin';
    const file = () => path.join(app.getPath('userData'), fileName);
    let memory: unknown = null; // fallback when the OS keychain is unavailable

    ipcMain.handle(CHANNELS.sessionGet, async () => {
      if (!safeStorage.isEncryptionAvailable()) return memory;
      try {
        const buf = await fs.promises.readFile(file());
        return JSON.parse(safeStorage.decryptString(buf));
      } catch {
        return null;
      }
    });
    ipcMain.handle(CHANNELS.sessionSet, async (_e, session: unknown) => {
      if (!safeStorage.isEncryptionAvailable()) {
        // Never write the token in plain text — keep it for this run only.
        console.warn('[teleconf] safeStorage unavailable; session will not persist across restarts');
        memory = session ?? null;
        return;
      }
      if (session == null) {
        await fs.promises.rm(file(), { force: true });
        return;
      }
      await fs.promises.writeFile(file(), safeStorage.encryptString(JSON.stringify(session)));
    });
    disposers.push(() => {
      ipcMain.removeHandler(CHANNELS.sessionGet);
      ipcMain.removeHandler(CHANNELS.sessionSet);
    });
  }

  if (options.deepLink) disposers.push(setupDeepLinks(options.deepLink));

  return () => disposers.forEach((d) => d());
}

/**
 * macOS asks for camera/microphone at the OS level (once per app). Call before
 * the first meeting; resolves to what the user allowed. Other platforms: all true.
 * Screen recording permission cannot be requested — macOS prompts on first share.
 */
export async function ensureMediaAccess(): Promise<{ camera: boolean; microphone: boolean }> {
  if (process.platform !== 'darwin') return { camera: true, microphone: true };
  const ask = async (type: 'camera' | 'microphone') =>
    systemPreferences.getMediaAccessStatus(type) === 'granted' || systemPreferences.askForMediaAccess(type);
  return { microphone: await ask('microphone'), camera: await ask('camera') };
}

/**
 * Registers `scheme://` with the OS and forwards incoming URLs to every
 * window. A URL that launched the app is buffered until a window loads.
 */
function setupDeepLinks({ scheme, onLink }: { scheme: string; onLink?: (url: string) => void }): () => void {
  const prefix = `${scheme}://`;
  let pending: string | null = null;

  if (process.defaultApp && process.argv.length >= 2) {
    // `electron .` during development: register with the script path.
    app.setAsDefaultProtocolClient(scheme, process.execPath, [path.resolve(process.argv[1])]);
  } else {
    app.setAsDefaultProtocolClient(scheme);
  }

  const deliver = (url: string) => {
    onLink?.(url);
    const windows = BrowserWindow.getAllWindows();
    if (!windows.length) {
      pending = url;
      return;
    }
    for (const w of windows) {
      if (w.isMinimized()) w.restore();
      w.focus();
      w.webContents.send(CHANNELS.deepLink, url);
    }
  };

  const fromArgv = (argv: string[]) => argv.find((a) => a.startsWith(prefix));
  const launchUrl = fromArgv(process.argv);
  if (launchUrl) pending = launchUrl;

  // Windows / Linux: a second launch carries the URL in argv.
  const onSecondInstance = (_e: unknown, argv: string[]) => {
    const url = fromArgv(argv);
    if (url) deliver(url);
  };
  // macOS
  const onOpenUrl = (e: { preventDefault(): void }, url: string) => {
    e.preventDefault();
    deliver(url);
  };
  // Renderer asks for a URL that arrived before it was listening.
  ipcMain.handle(CHANNELS.deepLinkPending, () => {
    const url = pending;
    pending = null;
    return url;
  });

  app.on('second-instance', onSecondInstance);
  app.on('open-url', onOpenUrl);
  return () => {
    app.off('second-instance', onSecondInstance);
    app.off('open-url', onOpenUrl);
    ipcMain.removeHandler(CHANNELS.deepLinkPending);
  };
}
