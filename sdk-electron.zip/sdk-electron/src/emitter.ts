/**
 * Minimal typed event emitter (browser-safe — no Node `events`).
 *
 *   class Foo extends Emitter<{ ready: () => void; data: (n: number) => void }> {}
 *   const off = foo.on('data', (n) => …);  // returns an unsubscribe function
 */
// Mapped (not an index signature) so plain `interface XEvents {…}` qualify.
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export type EventMap<E> = { [K in keyof E]: (...args: any[]) => void };

export class Emitter<E extends EventMap<E>> {
  private listeners = new Map<keyof E, Set<E[keyof E]>>();

  on<K extends keyof E>(event: K, fn: E[K]): () => void {
    let set = this.listeners.get(event);
    if (!set) {
      set = new Set();
      this.listeners.set(event, set);
    }
    set.add(fn);
    return () => this.off(event, fn);
  }

  once<K extends keyof E>(event: K, fn: E[K]): () => void {
    const wrapped = ((...args: Parameters<E[K]>) => {
      this.off(event, wrapped);
      fn(...args);
    }) as E[K];
    return this.on(event, wrapped);
  }

  off<K extends keyof E>(event: K, fn: E[K]): void {
    this.listeners.get(event)?.delete(fn);
  }

  removeAllListeners(event?: keyof E): void {
    if (event) this.listeners.delete(event);
    else this.listeners.clear();
  }

  protected emit<K extends keyof E>(event: K, ...args: Parameters<E[K]>): void {
    const set = this.listeners.get(event);
    if (!set) return;
    // Copy: a listener may unsubscribe itself while we iterate.
    for (const fn of Array.from(set)) {
      try {
        fn(...args);
      } catch (err) {
        // One faulty listener must not break the SDK's own state handling.
        console.error(`[teleconf] listener for "${String(event)}" threw`, err);
      }
    }
  }
}
