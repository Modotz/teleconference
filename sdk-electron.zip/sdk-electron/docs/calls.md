# Voice call

Telepon audio di dalam percakapan chat, bisa 1-on-1 maupun grup. Interoperabel dengan tombol telepon di web. Semua method ada di `client.calls`, dan hanya boleh ada satu panggilan aktif per klien.

## Menelepon

```ts
try {
  const call = await client.calls.start(conversationId);
  // state: 'ringing' (mic sudah aktif, menunggu yang diangkat)
  wireCall(call);
} catch (e) {
  if (e.code === 'call-ended') toast('Panggilan ditolak');   // ditolak saat masih disiapkan
  else throw e;
}

function wireCall(call: VoiceCall) {
  call.on('state', (s) => setStatus(s));        // ringing → connected ⇄ reconnecting → ended
  call.on('track', (p) => playAudio(p.peerId, p.stream));
  call.on('participantLeft', (p, why) => why === 'disconnected' ? showWeakSignal(p) : removeAudio(p.peerId));
  call.on('participantUpdated', (p) => setTile(p.peerId, { muted: p.muted, hand: p.handRaised }));
  call.on('reaction', ({ displayName, emoji }) => floatEmoji(emoji, displayName));
  call.on('micUnavailable', (err) => toast('Mikrofon tidak bisa dibuka; Anda hanya mendengar'));
  call.on('ended', (reason) => closeCallWindow(reason));
}
```

Kalau di percakapan itu sudah ada panggilan yang berjalan, `start()` otomatis bergabung ke panggilan tersebut. Panggilan yang tidak punya peserta tersambung dianggap sudah selesai, sehingga `start()` membunyikan dering baru.

## Panggilan masuk

```ts
client.calls.on('incoming', (invite) => {
  // invite: { conversationId, fromUserId, fromUsername, conversation: { name, isGroup, members } }
  showIncomingCall(invite, {
    onAccept: async () => wireCall(await client.calls.accept(invite)),
    onDecline: () => client.calls.decline(invite),
  });
});

// Penelepon membatalkan / panggilan selesai sebelum diangkat → tutup UI dering
client.calls.on('cancelled', ({ conversationId }) => closeIncoming(conversationId));
client.calls.on('ended', ({ conversationId }) => closeIncoming(conversationId));
```

## Memutar audio

```ts
function playAudio(peerId: string, stream: MediaStream) {
  const el = document.createElement('audio');
  el.autoplay = true;
  el.srcObject = stream;
  el.dataset.peer = peerId;
  document.body.appendChild(el);
  // speaker pilihan: await client.media.setSpeaker(el, speakerDeviceId);
}
```

## Kontrol

```ts
call.toggleMute();                      // atau setMuted(true); peserta lain melihat status mute
await call.switchMicrophone(deviceId);
await call.setOutgoingAudioTrack(track); // mis. jalur mic dengan peredam bising
call.sendReaction('👍');
await call.raiseHand(true);
await call.hangup();
call.participants;   // Map<peerId, { peerId, displayName, stream, muted, handRaised }>
call.connectedAt;    // epoch ms, untuk timer durasi
```

## Jaringan putus

Kalau koneksi Anda putus, panggilan **tidak** langsung berakhir:
1. `state` menjadi `reconnecting` dan event `reconnecting` dipancarkan.
2. Begitu jaringan kembali, SDK bergabung lagi dan memancarkan `reconnected`.
3. Kalau tidak tersambung dalam `reconnectTimeoutMs` (default 30 detik), panggilan berakhir dengan reason `error`.

Di sisi lawan bicara, Anda muncul sebagai `participantLeft(p, 'disconnected')` lalu `participantJoined`. Tampilkan "sinyal lemah", jangan "keluar". Kalau lawan terputus dan Anda tinggal sendiri, panggilan menunggu dengan masa tenggang yang sama sebelum ditutup otomatis.

## Opsi

```ts
await client.calls.start(conversationId, {
  media: { microphoneId },      // atau MediaStream milik Anda
  muted: false,
  ringTimeoutMs: 45_000,        // penelepon: tutup otomatis jika tak ada yang mengangkat (0 = tidak pernah)
  hangupWhenAlone: true,        // tutup otomatis jika semua orang lain sudah keluar
  autoReconnect: true,
  reconnectTimeoutMs: 30_000,
});
```

## Alasan berakhir (`ended`)

| Reason | Artinya |
|---|---|
| `left` | Anda menutup telepon |
| `ended` | Semua orang lain sudah keluar |
| `declined` | 1-on-1: lawan bicara menolak |
| `no-answer` | Tidak ada yang mengangkat dalam `ringTimeoutMs` |
| `error` | Gagal menyambung, jaringan tidak kembali, atau sesi dicabut |

Juga tersedia `call.endReason` setelah berakhir.

## Mikrofon gagal dibuka

Kalau mikrofon dipakai aplikasi lain atau diblokir Windows, panggilan tetap tersambung dalam mode hanya-mendengar. `call.micUnavailable` berisi error aslinya, dan event `micUnavailable` dipancarkan. Setelah mikrofon tersedia, panggil `setOutgoingAudioTrack(track, true)` untuk mulai bicara.

## Belum tersedia (Tahap 3)

Video di `VoiceCall`, tambah orang di luar percakapan, bagikan layar, kontrol host, riwayat panggilan di server, dan dering yang berhenti di perangkat lain (PG-1, PG-2, PG-6–PG-10). Untuk video call, pakai ruang rapat (`client.meetings`).

## Kualitas audio

Mic dikirim dengan Opus FEC (paket yang hilang dibangun ulang), DTX, dan prioritas jaringan tinggi, sama dengan versi web.
