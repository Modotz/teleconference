# Voice call

Telepon audio di dalam percakapan chat, bisa 1-on-1 maupun grup. Interoperabel dengan tombol telepon di web. Semua method ada di `client.calls`, dan hanya boleh ada satu panggilan aktif per klien.

## Menelepon

```ts
const call = await client.calls.start(conversationId);
// state: 'ringing' (mic sudah aktif, menunggu yang diangkat)

call.on('state', (s) => setStatus(s));          // ringing → connected → ended
call.on('track', (p) => playAudio(p.peerId, p.stream));
call.on('participantLeft', (p) => removeAudio(p.peerId));
call.on('ended', (reason) => closeCallWindow(reason));
```

Kalau di percakapan itu sudah ada panggilan yang berjalan, `start()` otomatis bergabung ke panggilan tersebut.

## Panggilan masuk

```ts
client.calls.on('incoming', (invite) => {
  // invite: { conversationId, fromUserId, fromUsername, conversation: { name, isGroup, members } }
  showIncomingCall(invite, {
    onAccept: async () => {
      const call = await client.calls.accept(invite);
      wireCall(call);
    },
    onDecline: () => client.calls.decline(invite),
  });
});

// Penelepon membatalkan / panggilan selesai sebelum diangkat → tutup UI dering
client.calls.on('cancelled', ({ conversationId }) => closeIncoming(conversationId));
client.calls.on('ended', ({ conversationId }) => closeIncoming(conversationId));
```

Agar panggilan masuk tetap terlihat saat jendela tidak aktif, munculkan `new Notification(...)` atau minta main process memanggil `win.show()` dan `win.flashFrame(true)`.

## Memutar audio

```ts
function playAudio(peerId: string, stream: MediaStream) {
  const el = document.createElement('audio');
  el.autoplay = true;
  el.srcObject = stream;
  el.dataset.peer = peerId;
  document.body.appendChild(el);
  // speaker pilihan: await client.media.setSpeaker(el, speakerDeviceId);
}
```

## Kontrol

```ts
call.toggleMute();               // atau call.setMuted(true)
await call.switchMicrophone(deviceId);
await call.hangup();
call.participants;               // Map<peerId, { peerId, displayName, stream }>
call.connectedAt;                // epoch ms, untuk timer durasi
```

## Opsi

```ts
await client.calls.start(conversationId, {
  media: { microphoneId },      // atau MediaStream milik Anda
  muted: false,
  ringTimeoutMs: 45_000,        // penelepon: tutup otomatis jika tak ada yang mengangkat (0 = tidak pernah)
  hangupWhenAlone: true,        // tutup otomatis jika semua orang lain sudah keluar
});
```

## Alasan berakhir (`ended`)

| Reason | Artinya |
|---|---|
| `left` | Anda menutup telepon |
| `ended` | Semua orang lain sudah keluar |
| `declined` | 1-on-1: lawan bicara menolak |
| `no-answer` | Tidak ada yang mengangkat dalam `ringTimeoutMs` |
| `error` | Koneksi putus atau gagal menyambung |

## Kualitas audio

Mic dikirim dengan Opus FEC (paket yang hilang dibangun ulang, sehingga tidak muncul "suara robot" di sinyal lemah), DTX, dan prioritas jaringan tinggi. Pengaturan ini sama persis dengan versi web.
