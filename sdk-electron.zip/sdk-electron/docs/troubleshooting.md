# Troubleshooting

| Gejala | Penyebab & solusi |
|---|---|
| Login gagal dengan `TeleconfError` kode **`network`**, padahal server hidup | **CORS.** Tambahkan origin aplikasi ke `CLIENT_ORIGIN` di backend (`null` untuk `loadFile`, `http://localhost:5173` untuk dev server), lalu restart backend. Lihat [electron-setup.md §4](electron-setup.md#4-cors-wajib). |
| Upload file gagal, tapi chat teks berhasil | Sama: CORS (upload memakai REST). Cek juga `client_max_body_size 30m` di Nginx. |
| Kamera/mic: `NotAllowedError` | Main process belum memanggil `setupTeleconfMain()`, atau halaman dimuat dari origin yang tidak ada di `allowedOrigins`. Di macOS: panggil `ensureMediaAccess()` dan cek System Settings → Privacy. |
| `getScreenSources()` error `unsupported` | Preload bridge belum terpasang. Lihat [electron-setup.md §2](electron-setup.md#2-preload). |
| `startScreenShare()`: `NotSupportedError` / tidak terjadi apa-apa | `screenShare: false` di main, atau handler display media ditimpa kode lain. Di macOS: beri izin Screen Recording, lalu restart aplikasi. |
| Bisa join meeting tapi **tidak ada video/suara** dari peserta lain | Masalah server: `MEDIASOUP_ANNOUNCED_IP` bukan IP publik VPS, atau UDP 40000–40100 tertutup di firewall/security group. Lihat `DEPLOY.md`. |
| Suara peserta lain tidak terdengar | Elemen `<video>`/`<audio>` peserta ter-`muted`, atau autoplay diblokir. Putar `p.audioTrack` lewat `<audio autoplay>` tersendiri. |
| Tidak menerima pesan realtime di thread | Lupa `await client.chat.subscribe(conversationId)`. Event `notify` tetap datang tanpa subscribe. |
| `chat.send()` gagal dengan `not-connected` / `timeout` | Koneksi realtime belum siap. `await client.waitUntilConnected()` dulu, dan cek event `connection`. |
| Login otomatis tidak bekerja di Linux | `safeStorage` butuh keyring (gnome-keyring/kwallet). Tanpa keyring, sesi hanya disimpan di memori (disengaja). |
| Telepon masuk tidak muncul | Hanya akun (bukan tamu) yang terhubung realtime. Pastikan `client.connectionState === 'connected'`. |
| `join()` gagal dengan `pin` | Minta PIN ke user, lalu `client.meetings.room(id).join({ pin })`. Objek `Meeting` yang gagal tidak bisa di-join ulang. |
| Masuk lobby terus padahal sudah pernah diizinkan | Status "sudah diizinkan" tersimpan di memori server per room dan hilang saat backend di-restart atau meeting diakhiri. |
| Setelah breakout, UI tidak bereaksi | `moveTo()` mengembalikan objek `Meeting` **baru**. Pasang ulang semua listener ke objek itu. |
| `npm run build` gagal "heap out of memory" | Sisa memori (commit) sistem kurang. Tutup aplikasi lain atau restart, lalu build ulang. |

## Debugging

- Buka DevTools renderer: `win.webContents.openDevTools()`.
- Buka `chrome://webrtc-internals` di sebuah jendela Electron (`win.loadURL('chrome://webrtc-internals')`) untuk melihat statistik WebRTC: bitrate, packet loss, dan codec.
- `meeting.on('error', console.error)`: error tidak fatal, misalnya gagal menerima satu track.
- Di server: `pm2 logs teleconf-api`.
