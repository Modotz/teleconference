# Meeting

## 1. Mengelola meeting (REST)

```ts
// Meeting instan
const { room, link } = await client.meetings.startInstant('Daily standup');

// Meeting terjadwal (lihat juga client.calendar.schedule)
const room = await client.meetings.create({
  name: 'Sprint review',
  description: 'Demo fitur Q4',
  scheduledAt: new Date('2026-11-10T09:00:00+07:00'),
  durationMinutes: 60,          // 5–480
});

await client.meetings.list();             // meeting aktif milik Anda
await client.meetings.get(roomId);        // detail (bisa dipanggil tamu)
await client.meetings.history();          // meeting yang Anda ikuti, 30 hari terakhir
await client.meetings.invite(roomId, ['a@x.com', 'b@y.com']); // kirim undangan email
await client.meetings.end(roomId);        // tutup room permanen (owner)

client.meetings.link(roomId);             // https://meet.example.com/room/<id> (perlu webUrl)
client.meetings.parseLink(pasted);        // link web / teleconf://room/<id> / id → roomId | null
```

## 2. Bergabung ke meeting

```ts
const meeting = client.meetings.room(roomId);

// Pasang listener SEBELUM join supaya tidak ada event yang terlewat.
meeting.on('lobby', () => showWaitingScreen());
meeting.on('participantJoined', (p) => addTile(p));
meeting.on('participantUpdated', (p) => updateTile(p));
meeting.on('participantLeft', (p) => removeTile(p.peerId));
meeting.on('left', (reason) => goHome(reason));

try {
  await meeting.join({ displayName: 'Budi' });
} catch (e) {
  switch (e.code) {
    case 'pin':        return askPin();            // lalu join ulang dengan { pin }
    case 'locked':     return alert('Meeting dikunci host');
    case 'denied':     return alert('Host menolak permintaan Anda');
    case 'not-found':  return alert('Meeting tidak ada atau sudah berakhir');
    default: throw e;
  }
}
```

`join()` baru selesai ketika Anda sudah benar-benar masuk. Kalau room memakai lobby, Anda menunggu (event `lobby`) sampai host mengizinkan masuk. Host langsung masuk tanpa lobby. Peserta yang sudah pernah diizinkan juga langsung masuk saat rejoin.

Satu objek `Meeting` hanya bisa di-`join()` sekali. Untuk masuk lagi, buat objek baru dengan `client.meetings.room(id)`.

### Opsi `join()`

| Opsi | Default | Keterangan |
|---|---|---|
| `displayName` | username akun | Nama yang terlihat oleh peserta lain |
| `pin` | — | PIN meeting, kalau host memasangnya |
| `media` | kamera + mic | `MediaStream` milik Anda, `{ audio, video, microphoneId, cameraId }`, atau `false` (hanya menerima) |
| `micEnabled` | `true` | Masuk dalam keadaan mic mati: `false` |
| `cameraEnabled` | `true` | Masuk dalam keadaan kamera mati: `false` |
| `stopMediaOnLeave` | otomatis | Matikan track lokal saat keluar. Bernilai `true` kalau SDK yang membuka perangkat. |
| `autoReconnect` | `true` | Bergabung ulang otomatis setelah jaringan putus |
| `obeyModerator` | `true` | Langsung patuhi permintaan host untuk mute atau mematikan kamera |
| `simulcast` | `true` | Kamera dikirim dalam 3 lapis kualitas (penonton dengan sinyal lemah mendapat versi kecil) |
| `reportQuality` | `true` | Ukur kualitas uplink dan bagikan ke peserta lain |

Kalau kamera sedang dipakai aplikasi lain, SDK otomatis masuk dengan audio saja.

### Layar pra-join (preview)

```ts
const preview = await client.media.getLocalStream({ cameraId, microphoneId });
videoEl.srcObject = preview;
// …user memilih perangkat, mematikan mic, dsb…
await meeting.join({ media: preview, micEnabled: false, stopMediaOnLeave: true });
```

## 3. Menampilkan video

Setiap `Participant` punya **`stream`** (kamera + mic) dan **`screenStream`** (share layar). Objek `stream` tidak pernah berganti; track ditambahkan dan dilepas di dalamnya. Jadi cukup pasang `srcObject` sekali:

```ts
function addTile(p: Participant) {
  const video = document.createElement('video');
  video.autoplay = true;
  video.playsInline = true;
  video.srcObject = p.stream;        // audio + video peserta
  tiles.set(p.peerId, video);
  grid.appendChild(video);
}

function updateTile(p: Participant) {
  const tile = tiles.get(p.peerId)!;
  tile.classList.toggle('cam-off', !p.cameraEnabled || !p.videoTrack);
  setBadge(p.peerId, { muted: !p.micEnabled, hand: p.handRaised, host: p.isHost, quality: p.quality });
  setName(p.peerId, p.displayName);
  if (p.screenStream) showScreen(p.peerId, p.screenStream); else hideScreen(p.peerId);
}

// Video sendiri: muted supaya tidak ada echo
selfVideo.muted = true;
selfVideo.srcObject = meeting.localStream;
meeting.on('localTrackChanged', () => (selfVideo.srcObject = meeting.localStream));
```

Elemen `<video>` milik peserta lain memutar audionya juga, jadi elemen itu **jangan** di-`muted`. Kalau tile peserta disembunyikan (karena paginasi grid), putar audionya lewat `<audio>` terpisah dari `p.audioTrack`, supaya suara tetap terdengar.

Speaker aktif:

```ts
meeting.on('activeSpeaker', (peerId) => highlight(peerId)); // bisa meeting.self.peerId, atau null saat semua diam
```

## 4. Kontrol media sendiri

```ts
await meeting.toggleMic();                  // atau setMicEnabled(bool)
await meeting.toggleCamera();               // kamera dilepas saat mati (lampu kamera padam)
await meeting.switchMicrophone(deviceId);
await meeting.switchCamera(deviceId);
await meeting.setOutgoingVideoTrack(track); // misalnya track dari canvas virtual background

meeting.self; // { peerId, userId, displayName, isHost, isCoHost, micEnabled, cameraEnabled, handRaised, quality }
meeting.on('selfUpdated', (self) => renderControls(self));
```

Ganti perangkat secara otomatis saat dicolok atau dicabut:

```ts
client.media.onChange(async () => setDeviceOptions(await client.media.list()));
```

Arahkan audio ke speaker tertentu: `await client.media.setSpeaker(videoEl, speakerId)`.

## 5. Share layar

```ts
const sources = await client.media.getScreenSources({ types: ['screen', 'window'] });
// tampilkan picker → user memilih
const stream = await meeting.startScreenShare({ sourceId: picked.id, audio: true });
await meeting.stopScreenShare();
```

Share otomatis berhenti kalau jendela yang dibagikan ditutup. Konfigurasi di sisi main process dijelaskan di [Setup Electron §5](electron-setup.md#5-screen-share).

## 6. Fitur dalam meeting

```ts
// Chat meeting (riwayat tersedia di meeting.messages)
await meeting.sendChat('Halo semua');
await meeting.sendChat('', { file, onProgress });
meeting.on('chatMessage', (m) => appendChat(m));

// Reaksi & angkat tangan
meeting.sendReaction('👍');
meeting.on('reaction', ({ displayName, emoji }) => floatEmoji(emoji, displayName));
await meeting.raiseHand(true);
meeting.on('handRaised', ({ peerId, raised }) => …);

// Ganti nama (berlaku di lobby maupun di dalam meeting)
await meeting.setDisplayName('Budi (Design)');

// Caption: hasil speech-to-text Anda sendiri, disiarkan ke semua peserta
meeting.sendCaption(text, isFinal);
meeting.on('caption', ({ displayName, text, isFinal }) => showCaption(displayName, text, isFinal));

// Durasi meeting
setInterval(() => setTimer(meeting.elapsedSeconds), 1000);
```

### Polling & Q&A

```ts
await meeting.createPoll('Rilis Jumat?', ['Ya', 'Tidak', 'Tunda']); // host/co-host
meeting.votePoll(poll.id, 0);
await meeting.closePoll(poll.id);
meeting.on('pollAdded', render); meeting.on('pollUpdated', render);   // meeting.polls

meeting.askQuestion('Kapan deadline-nya?');
meeting.upvoteQuestion(q.id);                 // toggle
await meeting.toggleAnswered(q.id);           // host/co-host
meeting.on('questionAdded', render); meeting.on('questionUpdated', render); // meeting.questions
```

### Whiteboard

Koordinat dinormalisasi ke rentang 0..1 (dibagi lebar dan tinggi canvas), jadi tampilannya sama di semua ukuran layar dan di web.

```ts
// Saat menggambar: kirim segmen dengan id stroke yang sama
meeting.drawWhiteboard({ id: strokeId, color: '#ff0000', size: 4, erase: false, points: [{ x: 0.21, y: 0.4 }] });
meeting.clearWhiteboard();

meeting.on('whiteboardSegment', (s) => drawSegment(s));
meeting.on('whiteboardCleared', () => clearCanvas());
meeting.whiteboard; // semua stroke (untuk menggambar ulang setelah join)
```

## 7. Moderasi (host & co-host)

```ts
meeting.isModerator;                         // host atau co-host

// Lobby
meeting.on('waitingListChanged', (list) => renderLobby(list)); // [{ peerId, username }]
await meeting.admit(peerId);
await meeting.admitAll();
await meeting.deny(peerId);

// Peserta
await meeting.setParticipantMic(peerId, false);    // minta mute
await meeting.setParticipantCamera(peerId, false);
await meeting.muteAll();
await meeting.kick(peerId);

// Khusus host
await meeting.setCoHost(peerId, true);
await meeting.transferHost(peerId);
await meeting.setLocked(true);               // tidak ada yang bisa masuk lagi
const pin = await meeting.setPin('4321');    // '' = hapus PIN (kembali ke mode lobby)
await meeting.endForAll();                   // akhiri meeting untuk semua peserta
```

Tindakan yang tidak diizinkan ditolak dengan `TeleconfError` kode `forbidden`.

Di sisi peserta, permintaan moderator langsung dipatuhi (kecuali `obeyModerator: false`) dan muncul sebagai event:

```ts
meeting.on('moderatorRequest', ({ kind, enabled }) => toast(`Host ${enabled ? 'menyalakan' : 'mematikan'} ${kind} Anda`));
```

## 8. Breakout room

```ts
// Host
await meeting.openBreakouts(3);               // peserta dibagi rata (round-robin)
await meeting.broadcastToBreakouts('5 menit lagi!');
await meeting.closeBreakouts();

// Semua peserta
meeting.on('breakoutOpened', async ({ myRoom }) => {
  if (myRoom) meeting = await meeting.moveTo(myRoom.boId);  // pindah sambil mempertahankan kamera/mic
});
meeting.on('breakoutClosed', async ({ returnTo }) => {
  if (meeting.info.isBreakout) meeting = await meeting.moveTo(returnTo);
});
meeting.on('breakoutMessage', (text) => toast(text));
```

`moveTo()` mengembalikan objek **`Meeting` baru**. Objek lama memancarkan `left('moved')`. Pasang ulang listener Anda ke objek baru (cara termudah: bungkus pemasangan listener dalam satu fungsi `wire(meeting)`).

## 9. Keluar & alasan berakhir

```ts
await meeting.leave();
meeting.on('left', (reason) => …);
```

| Reason | Artinya |
|---|---|
| `left` | Anda keluar sendiri |
| `ended` | Host mengakhiri meeting |
| `kicked` | Anda dikeluarkan oleh moderator |
| `moved` | `moveTo()`, misalnya pindah ke breakout room |
| `error` | Koneksi putus permanen atau gagal bergabung ulang |

## 10. Jaringan putus

Kalau koneksi terputus, SDK otomatis menyambung ulang dan membangun ulang meeting (media dan daftar peserta):

```ts
meeting.on('disconnected', () => showBanner('Koneksi terputus, menyambung ulang…'));
meeting.on('reconnected', () => hideBanner());
```

Saat menyambung ulang, semua peserta lama dipancarkan sebagai `participantLeft`, lalu dikirim lagi sebagai `participantJoined`. UI yang mengikuti event akan tetap konsisten.

## 11. Rekaman lokal

```ts
import { MeetingRecorder, MIN_PASSPHRASE_LENGTH } from '@teleconf/electron-sdk';

const rec = new MeetingRecorder(streamYangDirekam, { passphrase: 'minimal-8-karakter' });
await rec.start();
// …
const blob = await rec.stop();
saveFile(`rapat${rec.extension}`, blob);   // .webm atau .webm.enc
```

- Yang direkam hanya stream yang Anda berikan, misalnya `meeting.localStream`, `screenStream`, atau komposisi canvas buatan Anda. SDK tidak merekam mix semua peserta dari sisi server.
- File terenkripsi bisa dibuka lewat halaman web `/recording/decrypt` atau `decryptRecording(file, passphrase)`. Passphrase yang hilang tidak bisa dipulihkan.
- Untuk meeting panjang, pakai `onChunk` untuk menulis langsung ke disk lewat IPC, supaya rekaman tidak menumpuk di RAM.
