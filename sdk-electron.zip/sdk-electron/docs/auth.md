# Autentikasi & sesi

## Alur saat aplikasi dibuka

```ts
const client = new TeleconfClient({ serverUrl });

const user = await client.init();
if (user) showHome();
else showLogin();

// Token kedaluwarsa/dicabut di tengah jalan → kembali ke login.
client.on('sessionExpired', () => showLogin('Sesi berakhir, silakan login lagi'));
```

`init()` melakukan langkah-langkah berikut:
1. Membaca sesi tersimpan.
2. Membuang sesi itu kalau JWT-nya sudah kedaluwarsa.
3. Memastikan token masih diterima server (`/auth/me`).
4. Membuka koneksi realtime.

Kalau sedang offline, sesi tetap dipakai dan koneksi akan tersambung sendiri ketika jaringan kembali.

## Login

```ts
// Email + password
try {
  await client.auth.login(email, password);
} catch (e) {
  if (e instanceof TeleconfError && e.code === 'unverified') showResendVerification(email);
  else if (e.code === 'inactive') showError('Akun Anda sudah dinonaktifkan');
  else if (e.code === 'unauthorized') showError('Email atau password salah');
  else throw e;
}

// Google: idToken didapat dari Google Identity Services / OAuth
await client.auth.loginWithGoogle(idToken);

// Tamu: hanya bisa ikut meeting (tanpa chat/telepon/calendar/activity)
await client.auth.loginAsGuest('Budi Santoso');
client.isGuest; // true
```

Setelah login berhasil, sesi otomatis disimpan, koneksi realtime dibuka, dan event `session` dipancarkan.

> **Google di Electron:** Google Identity Services menolak origin `file://`. Cara yang umum adalah membuka OAuth di browser sistem (PKCE + redirect ke loopback `http://127.0.0.1:<port>` atau ke deep link), lalu menukar code tersebut menjadi `id_token`. Client ID-nya harus sama dengan `GOOGLE_CLIENT_ID` di backend.

## Registrasi & pemulihan akun

```ts
await client.auth.register({ email, username, password }); // mengirim email verifikasi, tidak langsung login
await client.auth.resendVerification(email);
await client.auth.verifyEmail(tokenDariLink);               // dari link /verify-email?token=…

await client.auth.forgotPassword(email);                     // selalu sukses (tidak membocorkan email terdaftar)
await client.auth.resetPassword(tokenDariLink, newPassword); // minimal 6 karakter
```

Link di email mengarah ke **web app** (`APP_URL` di backend). Kalau ingin link itu membuka aplikasi desktop, arahkan ke deep link, atau minta user menempelkan token-nya.

## Logout dan sesi per perangkat

```ts
await client.auth.logout(); // server mencabut sesi ini (token langsung tidak berlaku), lalu data lokal dihapus
```

Setiap login membuat satu **sesi** di server, dicatat bersama jenis perangkatnya. SDK melapor sebagai `desktop`; ganti dengan opsi `device` di `new TeleconfClient({ device: { deviceType: 'desktop', deviceName: 'Laptop Andi' } })`.

```ts
const sessions = await client.auth.sessions();   // [{ id, deviceType, deviceName, lastSeenAt, current }]
await client.auth.revokeSession(sessions[1].id); // keluarkan satu perangkat
await client.auth.revokeOtherSessions();         // keluarkan semua perangkat lain
```

Sesi yang dicabut langsung berhenti bekerja, untuk REST maupun socket. Perangkat yang dicabut menerima event:

```ts
client.on('sessionRevoked', async () => {
  await wipeLocalData();          // NF-08: hapus cache, draf, dan unduhan di laptop
  showLogin('Anda dikeluarkan dari perangkat ini');
});
```

Pencabutan terjadi kalau user logout di perangkat itu, mencabutnya dari perangkat lain, admin mencabutnya, atau akunnya dinonaktifkan.

> Token yang terbit **sebelum** fitur sesi ada di server (tanpa `sid`) tetap diterima sampai kedaluwarsa, supaya tidak ada yang tiba-tiba ter-logout saat deploy. Paling lama 7 hari setelah deploy, semua token sudah bisa dicabut.

## Profil, direktori, dan status online

```ts
const me = await client.auth.me();       // profil lengkap + roles
const people = await client.users.search('budi');   // nama, username, email, NIK, jabatan, divisi; maks 200
const budi = await client.users.get(userId);         // { fullName, nik, title, division, company, site, managerId, photoUrl, roles }
```

Direktori **hanya berisi karyawan aktif dari organisasi yang sama**. Akun sistem dan akun di luar organisasi tidak pernah muncul. Data profil berasal dari impor HR (lihat `DEPLOY.md` di repo server). Sebelum diimpor, field-nya bernilai `null`.

**Status online** (tanpa "terakhir dilihat"):

```ts
const online = await client.users.presence([u1, u2]);   // { [userId]: boolean }
client.users.on('presence', ({ userId, online }) => setDot(userId, online)); // untuk orang yang satu percakapan dengan Anda
```

## Administrasi (HR / IT)

Untuk akun dengan peran `hr_admin` atau `it_admin`, terbatas pada organisasi sendiri:

```ts
await client.admin.updateUser(userId, { title: 'Manager', roles: ['manager'] });
await client.admin.setActive(userId, false);   // karyawan keluar: login diblokir, semua sesi dicabut
await client.admin.sessions(userId);
await client.admin.revokeSessions(userId);
```

Ini kerangka sementara sampai data karyawan tersambung langsung ke sistem HR.

## Penyimpanan sesi

| Store | Kapan dipakai |
|---|---|
| `electronSessionStore()` | **Default kalau bridge ada.** Terenkripsi dengan keychain OS di main process. |
| `memorySessionStore()` | Default kalau tidak ada bridge. Login ulang setiap kali aplikasi dibuka. |
| `localStorageSessionStore(key?)` | Praktis untuk development, tapi token tersimpan tanpa enkripsi. |
| Buatan sendiri | Implementasikan `{ get(), set(session) }` (boleh async). |

```ts
new TeleconfClient({ serverUrl, sessionStore: localStorageSessionStore() });
```

## Event klien

| Event | Payload | Kapan |
|---|---|---|
| `session` | `Session \| null` | Login, ganti akun, logout |
| `sessionExpired` | — | Server menolak token (REST 401 atau socket) |
| `sessionRevoked` | — | Perangkat ini dikeluarkan dari jarak jauh. `sessionExpired` juga ikut dipancarkan. |
| `connection` | `'connecting' \| 'connected' \| 'reconnecting' \| 'disconnected'` | Status koneksi realtime (chat, telepon masuk) |

Tips: tampilkan banner "Menyambungkan ulang…" saat `connection === 'reconnecting'`.
