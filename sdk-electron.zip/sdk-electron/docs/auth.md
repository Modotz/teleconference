# Autentikasi & sesi

## Alur saat aplikasi dibuka

```ts
const client = new TeleconfClient({ serverUrl });

const user = await client.init();
if (user) showHome();
else showLogin();

// Token kedaluwarsa/dicabut di tengah jalan → kembali ke login.
client.on('sessionExpired', () => showLogin('Sesi berakhir, silakan login lagi'));
```

`init()` melakukan langkah-langkah berikut:
1. Membaca sesi tersimpan.
2. Membuang sesi itu kalau JWT-nya sudah kedaluwarsa.
3. Memastikan token masih diterima server (`/auth/me`).
4. Membuka koneksi realtime.

Kalau sedang offline, sesi tetap dipakai dan koneksi akan tersambung sendiri ketika jaringan kembali.

## Login

```ts
// Email + password
try {
  await client.auth.login(email, password);
} catch (e) {
  if (e instanceof TeleconfError && e.code === 'unverified') showResendVerification(email);
  else if (e.code === 'unauthorized') showError('Email atau password salah');
  else throw e;
}

// Google: idToken didapat dari Google Identity Services / OAuth
await client.auth.loginWithGoogle(idToken);

// Tamu: hanya bisa ikut meeting (tanpa chat/telepon/calendar/activity)
await client.auth.loginAsGuest('Budi Santoso');
client.isGuest; // true
```

Setelah login berhasil, sesi otomatis disimpan, koneksi realtime dibuka, dan event `session` dipancarkan.

> **Google di Electron:** Google Identity Services menolak origin `file://`. Cara yang umum adalah membuka OAuth di browser sistem (PKCE + redirect ke loopback `http://127.0.0.1:<port>` atau ke deep link), lalu menukar code tersebut menjadi `id_token`. Client ID-nya harus sama dengan `GOOGLE_CLIENT_ID` di backend.

## Registrasi & pemulihan akun

```ts
await client.auth.register({ email, username, password }); // mengirim email verifikasi, tidak langsung login
await client.auth.resendVerification(email);
await client.auth.verifyEmail(tokenDariLink);               // dari link /verify-email?token=…

await client.auth.forgotPassword(email);                     // selalu sukses (tidak membocorkan email terdaftar)
await client.auth.resetPassword(tokenDariLink, newPassword); // minimal 6 karakter
```

Link di email mengarah ke **web app** (`APP_URL` di backend). Kalau ingin link itu membuka aplikasi desktop, arahkan ke deep link, atau minta user menempelkan token-nya.

## Logout

```ts
await client.auth.logout(); // hapus sesi lokal + putus realtime
```

JWT tetap berlaku sampai kedaluwarsa (default 7 hari, `JWT_EXPIRES_IN`), karena server tidak punya daftar pencabutan token.

## Profil & kontak

```ts
const me = await client.auth.me();          // { id, email, username, createdAt }
client.user;                                 // user dari sesi (tanpa request)
const people = await client.users.search('budi'); // cari username/email, maks 200
```

## Penyimpanan sesi

| Store | Kapan dipakai |
|---|---|
| `electronSessionStore()` | **Default kalau bridge ada.** Terenkripsi dengan keychain OS di main process. |
| `memorySessionStore()` | Default kalau tidak ada bridge. Login ulang setiap kali aplikasi dibuka. |
| `localStorageSessionStore(key?)` | Praktis untuk development, tapi token tersimpan tanpa enkripsi. |
| Buatan sendiri | Implementasikan `{ get(), set(session) }` (boleh async). |

```ts
new TeleconfClient({ serverUrl, sessionStore: localStorageSessionStore() });
```

## Event klien

| Event | Payload | Kapan |
|---|---|---|
| `session` | `Session \| null` | Login, ganti akun, logout |
| `sessionExpired` | — | Server menolak token (REST 401 atau socket) |
| `connection` | `'connecting' \| 'connected' \| 'reconnecting' \| 'disconnected'` | Status koneksi realtime (chat, telepon masuk) |

Tips: tampilkan banner "Menyambungkan ulang…" saat `connection === 'reconnecting'`.
