# Setup Electron

Aplikasi Electron punya tiga bagian. SDK menyediakan satu entry point untuk masing-masing:

```
┌──────────────── Main process ─────────────────┐
│ setupTeleconfMain()                            │  izin media, screen share,
│   @teleconf/electron-sdk/main                  │  sesi terenkripsi, deep link
└───────────────▲───────────────────────────────┘
                │ IPC (channel teleconf:*)
┌───────────────┴──────── Preload ──────────────┐
│ exposeTeleconfBridge()                         │  window.teleconfBridge
│   @teleconf/electron-sdk/preload               │  (API sempit, aman)
└───────────────▲───────────────────────────────┘
                │ contextBridge
┌───────────────┴──────── Renderer ─────────────┐
│ new TeleconfClient(...)                        │  semua fitur: chat, call,
│   @teleconf/electron-sdk                       │  meeting, calendar, activity
└────────────────────────────────────────────────┘
```

Semua komunikasi dengan server (REST, Socket.IO, WebRTC) berjalan di **renderer**, karena WebRTC hanya tersedia di sana. Main process hanya mengurus hal-hal yang memang hanya bisa dilakukan di main.

---

## 1. Main process

```ts
import { app, BrowserWindow } from 'electron';
import path from 'node:path';
import { setupTeleconfMain, ensureMediaAccess } from '@teleconf/electron-sdk/main';

// Wajib kalau memakai deep link: hanya boleh ada satu instance aplikasi.
if (!app.requestSingleInstanceLock()) app.quit();

app.whenReady().then(async () => {
  setupTeleconfMain({
    allowedOrigins: ['http://localhost:5173'], // dev server (Vite), kalau ada
    deepLink: { scheme: 'teleconf' },          // teleconf://room/<id>
  });
  await ensureMediaAccess();
  createWindow();
});
```

### Opsi `setupTeleconfMain(options)`

| Opsi | Default | Keterangan |
|---|---|---|
| `session` | `session.defaultSession` | Session Electron yang dikonfigurasi |
| `permissions` | `true` | Otomatis izinkan `media`, `display-capture`, `notifications`, `fullscreen`, `clipboard-sanitized-write`, `speaker-selection` untuk halaman `file://` dan `allowedOrigins`. Isi `false` kalau Anda mengatur izin sendiri. |
| `allowedOrigins` | `[]` | Origin tambahan yang dipercaya, mis. dev server |
| `screenShare` | aktif | `false` untuk mematikan. Atau `{ pickSource, useSystemPicker, systemAudio }`, lihat [§5](#5-screen-share) |
| `secureSession` | `true` | Simpan sesi login terenkripsi dengan keychain OS (`safeStorage`) di folder `userData`. `{ fileName }` untuk mengganti nama file. |
| `deepLink` | — | `{ scheme, onLink? }`, lihat [§6](#6-deep-link) |

Nilai kembaliannya adalah fungsi `dispose()` untuk melepas semua handler.

### `ensureMediaAccess()`

macOS meminta izin kamera dan mic di level OS. Panggil fungsi ini sekali sebelum meeting pertama. Hasilnya `{ camera, microphone }` (boolean). Di Windows dan Linux selalu bernilai `true`.

## 2. Preload

```ts
// preload.ts (di-bundle oleh Vite/webpack/electron-forge)
import { exposeTeleconfBridge } from '@teleconf/electron-sdk/preload';
exposeTeleconfBridge();
```

Preload dengan `sandbox: true` (default sejak Electron 20) **tidak bisa `require` paket npm**. Ada dua pilihan:

- Preload Anda di-bundle (template Electron Forge + Vite sudah melakukannya): pakai kode di atas.
- Preload tidak di-bundle: pakai file siap pakai yang hanya bergantung pada `electron`:

  ```ts
  webPreferences: {
    preload: require.resolve('@teleconf/electron-sdk/preload-script'),
    contextIsolation: true,
    sandbox: true,
  }
  ```

Bridge memasang `window.teleconfBridge` (tipe `TeleconfBridge`). Yang diekspos hanya fungsi-fungsi sempit, **bukan** `ipcRenderer` itu sendiri.

Butuh bridge milik Anda sendiri juga? Panggil `exposeTeleconfBridge()` lalu `contextBridge.exposeInMainWorld('myApi', …)` seperti biasa. Namanya tidak bentrok.

## 3. Renderer

```ts
import { TeleconfClient } from '@teleconf/electron-sdk';

export const client = new TeleconfClient({
  serverUrl: import.meta.env.VITE_TELECONF_API,   // https://api.example.com
  webUrl: import.meta.env.VITE_TELECONF_WEB,      // https://meet.example.com
});

const user = await client.init(); // null = belum login
```

Buat **satu** `TeleconfClient` per jendela, lalu panggil `client.destroy()` saat jendela ditutup.

Kalau bridge terdeteksi, sesi otomatis disimpan terenkripsi. Kalau tidak ada bridge, sesi hanya disimpan di memori. Lihat [Autentikasi](auth.md#penyimpanan-sesi).

## 4. CORS (wajib)

Backend hanya menerima request REST dari origin yang terdaftar di **`CLIENT_ORIGIN`** (`backend/.env`, dipisah koma). Setiap cara memuat halaman di Electron menghasilkan origin yang berbeda:

| Cara memuat halaman | Origin yang dikirim | Tambahkan ke `CLIENT_ORIGIN` |
|---|---|---|
| `win.loadFile('index.html')` | `null` | `null` |
| Dev server `win.loadURL('http://localhost:5173')` | `http://localhost:5173` | `http://localhost:5173` |
| Protocol kustom `app://teleconf/` | `app://teleconf` | `app://teleconf` |

Contoh:

```ini
CLIENT_ORIGIN=https://meet.example.com,null,http://localhost:5173
```

Lalu restart backend (`pm2 restart teleconf-api`).

Socket.IO (chat, meeting) memakai WebSocket murni, jadi tidak terkena CORS. Kalau login gagal dengan error `network` padahal server hidup, hampir pasti penyebabnya CORS.

> **Soal keamanan origin `null`:** API Teleconference memakai token Bearer, bukan cookie, sehingga CORS di sini tidak melindungi data user. Halaman lain tetap tidak bisa membaca token milik aplikasi Anda. Kalau tim lebih memilih origin yang eksplisit, muat aplikasi lewat protocol kustom yang didaftarkan dengan `protocol.registerSchemesAsPrivileged([{ scheme: 'app', privileges: { standard: true, secure: true, supportFetchAPI: true } }])`, lalu daftarkan `app://teleconf`.

## 5. Screen share

Di Electron, `getDisplayMedia()` hanya berfungsi kalau main process memasang handler. `setupTeleconfMain()` sudah memasangnya. Ada tiga cara memilih layar yang dibagikan:

**A. Picker buatan Anda sendiri (disarankan untuk UX yang bagus)**

```ts
const sources = await client.media.getScreenSources();   // [{ id, name, thumbnail, appIcon, kind }]
// tampilkan grid thumbnail, user memilih satu…
await meeting.startScreenShare({ sourceId: chosen.id });
```

**B. Diputuskan di main process**

```ts
setupTeleconfMain({
  screenShare: {
    pickSource: async (sources) => sources.find((s) => s.name === 'Entire Screen') ?? null,
  },
});
```

Kalau tidak diatur, yang dibagikan adalah layar utama.

**C. Picker bawaan OS** (macOS 15+): `screenShare: { useSystemPicker: true }`.

Audio sistem (`loopback`) hanya didukung di Windows dan aktif secara default. Matikan dengan `systemAudio: false`.

macOS juga meminta izin **Screen Recording** saat pertama kali berbagi layar (System Settings → Privacy & Security). Izin ini tidak bisa diminta lewat kode.

## 6. Deep link

```ts
// main
if (!app.requestSingleInstanceLock()) app.quit();
setupTeleconfMain({ deepLink: { scheme: 'teleconf' } });

// renderer
window.teleconfBridge?.onDeepLink(async (url) => {
  const roomId = client.meetings.parseLink(url);    // teleconf://room/<id>
  if (roomId) openMeeting(roomId);
});
```

Link yang membuka aplikasi dari keadaan tertutup disimpan dulu, lalu dikirim begitu renderer memanggil `onDeepLink`. `parseLink()` juga menerima link web (`https://meet.example.com/room/<id>`) dan room id mentah, jadi bisa dipakai untuk kolom "tempel link meeting".

Saat packaging, daftarkan scheme di konfigurasi builder:
- **electron-builder:** `protocols: [{ name: 'Teleconference', schemes: ['teleconf'] }]`
- **Forge:** `packagerConfig.protocols`, plus `mimeType` di maker deb/rpm

## 7. Packaging

**macOS**: `Info.plist` / `extendInfo`:

```xml
<key>NSCameraUsageDescription</key><string>Untuk video saat meeting</string>
<key>NSMicrophoneUsageDescription</key><string>Untuk suara saat meeting dan telepon</string>
```

Kalau memakai hardened runtime, tambahkan entitlement `com.apple.security.device.camera` dan `com.apple.security.device.audio-input`.

**Windows**: tidak ada pengaturan khusus. Izin kamera dan mic Windows (Settings → Privacy) harus aktif untuk aplikasi desktop.

**Linux**: `safeStorage` membutuhkan keyring (gnome-keyring/kwallet). Kalau keyring tidak ada, sesi tidak disimpan ke disk dan user harus login ulang setiap kali aplikasi dibuka. Ini disengaja, supaya token tidak pernah ditulis dalam teks polos.

## 8. Checklist keamanan

- `contextIsolation: true`, `sandbox: true`, `nodeIntegration: false` (default Electron modern).
- Jangan ekspos `ipcRenderer` mentah ke renderer. Bridge SDK sudah memakai API yang sempit.
- Sesi disimpan terenkripsi di main process, bukan di `localStorage`.
- `setupTeleconfMain` hanya memberi izin media ke halaman `file://` dan `allowedOrigins`. Halaman eksternal yang mungkin terbuka di jendela lain tidak mendapat izin itu.
- URL lampiran (`chat.attachmentUrl()`) berisi token di query string. Jangan dicatat ke log dan jangan dibagikan.
