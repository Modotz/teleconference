# Agenda dan Booking Ruangan (kerangka Tahap 2)

> **Status: kerangka.** Model data dan API-nya sudah jalan dan teruji. Yang **belum** ada:
> sinkron ke Outlook, pengingat yang dikirim server, penjabaran agenda berulang
> (`recurrence` disimpan apa adanya), usulan waktu baru, dan data ruangan dari
> sistem fasilitas. Site dan ruangan untuk sementara diisi admin lewat impor CSV
> (`backend/scripts/import-rooms.js`).

`client.calendar` yang lama (rapat Telepati buatan sendiri) tetap ada. `client.agenda` berisi **semua agenda yang Anda ikuti**, termasuk undangan dari orang lain.

## Agenda

```ts
const events = await client.agenda.list({ from: weekStart, to: weekEnd });  // milik sendiri + undangan

const ev = await client.agenda.create({
  title: 'Sprint review',
  kind: 'meeting',                 // atau 'activity'
  mode: 'hybrid',                  // 'online' | 'offline' | 'hybrid'
  start: new Date('2026-11-20T09:00:00+07:00'),
  end: new Date('2026-11-20T10:00:00+07:00'),
  attendees: [{ userId: budi.id }, { userId: citra.id, optional: true }, { email: 'tamu@vendor.com' }],
  bookableRoomId: room.id,         // opsional: booking ruangan sekaligus
  reminderMinutes: 15,
  isPrivate: false, showAs: 'busy', color: '#2563eb',
});
ev.roomId;  // rapat online/hybrid otomatis mendapat ruang Telepati → client.meetings.room(ev.roomId).join()
```

Kalau ruangannya sudah dibooking orang lain pada jam itu, seluruh pembuatan agenda dibatalkan dengan:

```ts
catch (e) {
  if (e.code === 'conflict') alert(`Ruangan sudah dibooking ${e.details.bookedBy.fullName ?? e.details.bookedBy.username}`);
}
```

### Jawaban peserta

```ts
await client.agenda.respond(ev.id, 'yes', 'Saya hadir');     // 'yes' | 'maybe' | 'no'
client.agenda.on('response', ({ eventId, userId, response, note }) => …);   // ke pembuat
```

### Mengubah dan membatalkan (khusus pembuat)

```ts
await client.agenda.update(ev.id, { start: newStart, end: newEnd });
// Waktu berubah → semua jawaban kembali 'pending', booking ruangan ikut pindah
// (bentrok di jam baru → conflict, dan tidak ada yang berubah).
await client.agenda.cancel(ev.id);                       // ruangan ikut dilepas
await client.agenda.cancel(ev.id, { keepRoomBooking: true });
```

### Event realtime

| Event | Kapan |
|---|---|
| `invited` | Anda diundang (`AgendaEvent`) |
| `updated` | Agenda Anda berubah; kalau `timeChanged`, minta peserta menjawab ulang |
| `cancelled` | `{ eventId }` |
| `response` | Peserta menjawab agenda yang Anda buat |

### Cari waktu (free/busy)

```ts
const busy = await client.agenda.freeBusy([budi.id, citra.id], dayStart, dayEnd);
// { [userId]: [{ start, end }] }: hanya blok sibuk, tanpa judul atau isi agenda
```

Agenda pribadi milik orang lain yang dibuka lewat `agenda.get()` hanya tampil sebagai blok "Busy".

## Booking ruangan

```ts
const sites = await client.bookings.sites();
const rooms = await client.bookings.rooms(sites[0].id, 'meeting');   // atau 'operational'
// room: { name, type, capacity, facilities, hasCamera, openFrom, openTo }

const day = await client.bookings.availability(sites[0].id, '2026-11-20');
// [{ bookableRoomId, start, end, bookedBy, mine }]. Booking orang lain hanya menampilkan nama dan jam.

// Ruangan operasional: keperluan + catatan, tanpa peserta
const b = await client.bookings.book({
  bookableRoomId: room.id, start, end, purpose: 'Inspeksi alat', note: 'Bawa kunci gudang',
});

await client.bookings.mine();
await client.bookings.cancel(b.id);                       // atau { withEvent: true } untuk ikut membatalkan agendanya
```

Pemeriksaan bentrok dilakukan **di server secara atomik**: dua orang yang menekan "Booking" bersamaan tidak akan mendapat jam yang sama. Yang kalah menerima error `conflict` dengan `details.bookedBy`.

Tanggal di `availability` memakai zona waktu site (WIB, GMT+7).
