# Chat

Percakapan 1-on-1 dan grup, realtime, dengan lampiran file. Semua method ada di `client.chat`.

## Daftar percakapan (sidebar)

```ts
const list = await client.chat.listConversations();
for (const c of list) {
  renderRow({
    id: c.id,
    title: client.chat.titleOf(c),         // nama grup, atau nama lawan bicara untuk 1-on-1
    preview: c.lastMessage?.content ?? '',
    time: c.lastMessage?.createdAt ?? c.updatedAt,
    unread: c.hasUnread,                    // pesan terakhir dari orang lain & belum dibaca
  });
}
```

Daftar ini sudah diurutkan dari aktivitas terbaru. Server tidak menghitung jumlah pesan yang belum dibaca, hanya status sudah/belum dibaca (`hasUnread`).

## Membuka percakapan

```ts
const conv = await client.chat.openDirect(userId);       // pakai ulang 1-on-1 yang sudah ada
const group = await client.chat.createGroup('Tim Desain', [userId1, userId2]);
```

## Menampilkan thread

```ts
async function openThread(conversationId: string) {
  const messages = await client.chat.listMessages(conversationId);  // lama → baru, 50 terakhir
  render(messages);

  const unsubscribe = await client.chat.subscribe(conversationId);  // mulai menerima event realtime
  await client.chat.markRead(conversationId);

  return unsubscribe; // panggil saat thread ditutup
}

// Muat pesan lebih lama (scroll ke atas)
const older = await client.chat.listMessages(conversationId, { before: messages[0].createdAt, limit: 50 });
```

Langganan (`subscribe`) otomatis dipasang ulang setelah koneksi terputus dan tersambung kembali.

## Event

```ts
// Pesan untuk thread yang sedang dibuka (termasuk pesan Anda sendiri dari perangkat lain)
client.chat.on('message', ({ conversationId, message }) => {
  if (conversationId === openId) appendMessage(message);
});

// Pesan dari orang lain di percakapan MANA PUN: untuk badge & notifikasi desktop
client.chat.on('notify', ({ conversationId, message }) => {
  if (conversationId === openId && document.hasFocus()) return;
  new Notification(message.sender?.username ?? 'Pesan baru', { body: message.content || '📎 Lampiran' });
  bumpUnread(conversationId);
});
```

`message` dan `notify` bisa tiba bersamaan untuk pesan yang sama. Gunakan `message` untuk menampilkan isi thread dan `notify` untuk badge atau notifikasi. Untuk deduplikasi, pakai `message.id`.

| Event | Payload |
|---|---|
| `message` | `{ conversationId, message }`, hanya untuk percakapan yang di-subscribe |
| `notify` | `{ conversationId, message }`, pesan orang lain di semua percakapan |
| `typing` | `{ conversationId, userId, username, isTyping }` |
| `read` | `{ conversationId, userId, lastReadAt }`, read receipt |
| `conversationAdded` | `Conversation`: Anda ditambahkan ke grup |
| `conversationRemoved` | `{ conversationId, removedBy }`: Anda dikeluarkan dari grup |
| `memberAdded` | `{ conversationId, member, addedBy }` |
| `memberRemoved` | `{ conversationId, removedUserId, removedBy }` |

## Mengirim

```ts
await client.chat.send(conversationId, 'Halo!');

// Dengan file (maks 25 MB). File di-upload dulu, lalu dikirim sebagai lampiran.
await client.chat.send(conversationId, {
  content: 'Ini laporannya',
  file: fileDariInput,              // File atau Blob
  onProgress: (p) => setProgress(p), // 0–100
});
```

`send()` mengembalikan pesan yang tersimpan di server (dengan `id` dan `createdAt`), jadi bisa langsung dipakai untuk mengganti pesan optimistik di UI.

## Lampiran

```ts
const url = client.chat.attachmentUrl(message.attachmentUrl);  // untuk <img src> / <audio src> / <a href>
const blob = await client.chat.downloadAttachment(message.attachmentUrl!); // misalnya untuk "Simpan sebagai…"
```

File dienkripsi di server dan hanya bisa diakses oleh anggota percakapan. URL dari `attachmentUrl()` berisi token, jadi jangan dicatat ke log.

Lampiran juga bisa di-upload terlebih dahulu, misalnya untuk menampilkan preview sebelum dikirim:

```ts
const att = await client.chat.uploadAttachment(file, file.name, setProgress);
await client.chat.send(conversationId, { content: '', attachment: att });
```

## Indikator mengetik

```ts
const typing = client.chat.typingIndicator(conversationId);
input.addEventListener('input', () => typing.keystroke());   // dibatasi otomatis (1×/detik)
form.addEventListener('submit', () => typing.stop());        // berhenti otomatis setelah 3 detik diam

client.chat.on('typing', (t) => t.conversationId === openId && showTyping(t.username, t.isTyping));
```

## Read receipt

```ts
await client.chat.markRead(conversationId);  // semua pesan sampai sekarang dianggap dibaca
client.chat.on('read', ({ userId, lastReadAt }) => markSeenUpTo(userId, lastReadAt));
```

## Grup

```ts
await client.chat.addMember(groupId, userId);
await client.chat.removeMember(groupId, userId); // hanya owner grup
await client.chat.leaveGroup(groupId);            // owner tidak bisa keluar selama masih ada anggota lain
```

Chat tidak tersedia untuk sesi tamu (error `forbidden`).
