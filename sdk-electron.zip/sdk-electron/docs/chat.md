# Chat

Percakapan 1-on-1 dan grup, realtime, dengan lampiran, balasan, reaksi, edit/hapus, dan peran admin. Semua method ada di `client.chat`. Chat tidak tersedia untuk sesi tamu (error `forbidden`).

## Daftar percakapan

```ts
const list = await client.chat.listConversations();
for (const c of list) {
  renderRow({
    title: client.chat.titleOf(c),       // nama grup, atau nama lengkap lawan bicara
    preview: c.lastMessage?.content ?? '',
    time: c.lastMessage?.createdAt ?? c.updatedAt,
    unread: c.unreadCount,               // jumlah pesan belum dibaca
    bold: c.hasUnread,                   // unreadCount > 0 atau ditandai belum dibaca
    pinned: c.pinned, archived: c.archived,
    muted: !!c.mutedUntil && new Date(c.mutedUntil) > new Date(),
    official: c.official, announcement: c.type === 'announcement',
  });
}
```

Server mengurutkan dari aktivitas terbaru. Urutan khusus PRD (pengumuman belum dibaca, disematkan, PASTI Asisten, lalu terbaru) disusun di aplikasi dari field di atas.

### Pengaturan per pengguna (sama di HP dan desktop)

```ts
await client.chat.pin(id);                 // pin(id, false) untuk melepas
await client.chat.mute(id, true);          // bisukan sampai dibuka; atau mute(id, new Date(...)); mute(id, false)
await client.chat.archive(id);             // kanal pengumuman tidak bisa diarsipkan
await client.chat.markUnread(id);          // otomatis hilang saat markRead
client.chat.on('preferences', (p) => updateRow(p.conversationId, p)); // dari perangkat Anda yang lain
```

## Thread

```ts
const messages = await client.chat.listMessages(id);            // lama → baru, 50 terakhir
const older = await client.chat.listMessages(id, { before: messages[0].createdAt });
const unsubscribe = await client.chat.subscribe(id);            // event realtime untuk thread ini
await client.chat.markRead(id);
```

Pesan yang Anda hapus "untuk saya" tidak ikut dikirim. `listMessages` sudah mengecualikannya.

### Bentuk pesan (`ChatMessage`)

| Field | Isi |
|---|---|
| `type` | `'text'`, `'system'` (mis. "Andi added Rina"; jenis di `data.event`), `'deleted'` (dihapus untuk semua: isi dan lampiran kosong), atau jenis buatan aplikasi |
| `content`, `attachment*` | Isi teks dan lampiran |
| `data` | Data terstruktur untuk jenis buatan aplikasi (maks. 16 KB) |
| `replyTo` | Kutipan pesan asal: `{ id, senderName, content (200 karakter), type }` |
| `forwarded` | Label "Diteruskan" |
| `mentions` | userId yang disebut, atau `'all'` |
| `reactions` | `[{ userId, emoji }]`, satu per orang |
| `editedAt` | Label "Diedit" |
| `clientId` | Id pesan dari aplikasi pengirim |

`data.event` pada pesan sistem bernilai `member_added`, `member_removed`, `member_left`, `renamed`, atau `send_permission`. Teks `content` berbahasa Inggris, jadi terjemahkan dari `data.event`.

## Mengirim

```ts
await client.chat.send(id, 'Halo!');

await client.chat.send(id, {
  content: 'Ini laporannya',
  file, onProgress: setProgress,       // maks. 25 MB
  replyToId: original.id,              // balas dengan kutipan
  mentions: [userId],                  // atau ['all'] (khusus admin di grup)
  clientId: localId,                   // opsional, dibuat otomatis
});

// Jenis pesan buatan aplikasi (pesan suara, lokasi, kartu…)
await client.chat.send(id, { type: 'location', data: { lat: -6.2, lng: 106.8, label: 'Kantor' } });
```

**Antrean offline (APP-07):** `send()` dengan `clientId` yang sama tidak pernah menghasilkan pesan dobel. Server mengembalikan pesan yang sudah tersimpan. Jadi aplikasi cukup menyimpan `clientId` di antrean dan mengirim ulang sampai berhasil.

Server menolak dengan kode:
- `admins-only`: mode pengumuman, dan Anda bukan admin.
- `muted`: Anda dibisukan admin grup.
- `read-only`: kanal sistem.

## Tindakan pada pesan

```ts
await client.chat.edit(msgId, 'teks baru');           // milik sendiri, ≤ 15 menit (lalu: 'edit-window')
await client.chat.deleteMessage(msgId, 'me');         // sembunyikan di semua perangkat Anda
await client.chat.deleteMessage(msgId, 'everyone');   // milik sendiri, atau milik siapa pun bila Anda admin grup
await client.chat.react(msgId, '👍');                  // react(msgId, null) untuk menghapus
await client.chat.star(msgId);                        // star(msgId, false); daftar: client.chat.starred()
await client.chat.forward(msgId, [convA, convB]);     // maks. 5, berlabel forwarded
await client.chat.pinMessage(convId, msgId);          // satu per chat; grup: admin. null = lepas
await client.chat.report({ messageId, reason: 'Spam' });  // atau { userId, reason }
const receipts = await client.chat.receipts(msgId);   // [{ user, status: 'sent'|'delivered'|'read', deliveredAt, readAt }]
```

Pesan yang dihapus untuk semua tetap disimpan terenkripsi di jejak audit server, tetapi isinya tidak pernah dikirim lagi ke aplikasi.

## Status terkirim, diterima, dan dibaca

- **Terkirim**: `send()` berhasil.
- **Diterima**: SDK otomatis mengirim tanda diterima saat pesan tiba (`client.chat.autoDeliveryReceipts = false` untuk mematikan). Pengirim mendapat event `delivered`.
- **Dibaca**: `markRead()` di penerima, lalu pengirim mendapat event `read`.

```ts
client.chat.on('delivered', ({ conversationId, userId, at }) => …);
client.chat.on('read', ({ conversationId, userId, lastReadAt }) => …);
```

Untuk centang biru di grup ("semua sudah membaca"), cocokkan `lastReadAt` tiap anggota dengan `createdAt` pesan, atau panggil `receipts()`.

## Pencarian dan media

```ts
const { messages, truncated } = await client.chat.search('laporan', { conversationId, senderId, hasAttachment: true });
const media = await client.chat.listAttachments(id, 'media');  // foto/video
const files = await client.chat.listAttachments(id, 'file');   // dokumen
const links = await client.chat.listAttachments(id, 'link');   // [{ url, message }]
```

Isi pesan dienkripsi di server, jadi pencarian memindai 5.000 pesan terbaru. `truncated: true` berarti ada pesan yang lebih lama dan belum ikut dipindai.

## Event

| Event | Payload | Kapan |
|---|---|---|
| `message` | `{ conversationId, message }` | Pesan baru di thread yang di-subscribe (termasuk milik sendiri dan pesan sistem) |
| `notify` | `{ conversationId, message, muted, mentioned }` | Pesan orang lain di **semua** percakapan, untuk badge dan notifikasi |
| `messageEdited` | `{ conversationId, message }` | |
| `messageDeleted` | `{ conversationId, messageId, deletedBy, byAdmin }` | Dihapus untuk semua |
| `messageHidden` | `{ conversationId, messageId }` | Anda menghapus "untuk saya" di perangkat lain |
| `reaction` | `{ conversationId, messageId, userId, username, emoji \| null }` | |
| `delivered` / `read` | lihat di atas | |
| `typing` | `{ conversationId, userId, username, isTyping }` | |
| `pinned` | `{ conversationId, messageId \| null, by }` | |
| `preferences` | `{ conversationId, pinned, mutedUntil, archived, markedUnread }` | |
| `starred` | `{ conversationId, messageId, value }` | |
| `groupUpdated` | `Conversation` | Nama, deskripsi, mode kirim, atau admin berubah |
| `memberMuted` | `{ conversationId, userId, until }` | |
| `conversationAdded` | `Conversation` | Anda dimasukkan ke grup (termasuk saat grup dibuat) |
| `conversationRemoved` | `{ conversationId, removedBy }` | |
| `memberAdded` / `memberRemoved` | `{ conversationId, member / removedUserId, addedBy / removedBy }` | `addedBy`/`removedBy` berupa objek `{ id, username }` |

**Notifikasi desktop:**

```ts
client.chat.on('notify', ({ conversationId, message, muted, mentioned }) => {
  if (muted && !mentioned) return;               // dibisukan: diam, kecuali disebut namanya
  if (conversationId === openId && document.hasFocus()) return;
  new Notification(message.sender?.fullName ?? message.sender?.username ?? 'Pesan baru', {
    body: message.content || '📎 Lampiran',
  });
});
```

`message` dan `notify` bisa tiba untuk pesan yang sama. Gunakan `message.id` untuk deduplikasi.

## Grup dan peran

Peran anggota (`member.role`) adalah `owner`, `admin`, atau `member`. Pembuat grup menjadi `owner`.

| Tindakan | Siapa |
|---|---|
| `addMember`, `muteMember`, `updateGroup`, `pinMessage` | owner / admin |
| `removeMember` (anggota biasa) | owner / admin |
| `removeMember` (admin) | owner |
| `setAdmin(…, true)` | owner / admin |
| `setAdmin(…, false)` | owner |
| `transferOwnership` | owner (lalu menjadi admin) |
| `deleteMessage(…, 'everyone')` untuk pesan orang lain | owner / admin |
| `leaveGroup` | semua orang, kecuali di grup resmi HR. Bila pemiliknya keluar, kepemilikan pindah ke admin (atau anggota terlama) |

```ts
const g = await client.chat.createGroup('Tim Desain', [u1, u2], { description: 'Proyek Q4' });
await client.chat.setAdmin(g.id, u1, true);
await client.chat.updateGroup(g.id, { onlyAdminsCanSend: true });   // mode pengumuman
await client.chat.muteMember(g.id, u2, new Date(Date.now() + 3600_000)); // null = lepas
await client.chat.transferOwnership(g.id, u1);
```

Grup resmi (`official: true`, dikelola HR) dan kanal pengumuman (`type: 'announcement'`) sudah punya kolom di server, dan aturannya sudah berlaku: anggota tidak bisa keluar atau diubah, dan hanya admin yang bisa mengirim. Yang belum ada adalah sumber datanya dari HR. Untuk sementara, kolom itu diisi langsung di database.

## Lampiran

```ts
const url = client.chat.attachmentUrl(message.attachmentUrl);          // <img src> / <audio src>
const blob = await client.chat.downloadAttachment(message.attachmentUrl!);
const att = await client.chat.uploadAttachment(file, file.name, setProgress); // upload dulu, kirim nanti
```

URL dari `attachmentUrl()` berisi token, jadi jangan dicatat ke log.

## Indikator mengetik

```ts
const typing = client.chat.typingIndicator(id);
input.addEventListener('input', () => typing.keystroke());
form.addEventListener('submit', () => typing.stop());
```
