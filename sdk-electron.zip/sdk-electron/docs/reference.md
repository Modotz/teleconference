# Referensi API (v0.2.0)

Semua tipe tersedia dari `@teleconf/electron-sdk` (TypeScript `.d.ts` ikut di paket). Semua method yang mengembalikan `Promise` gagal dengan `TeleconfError`.

Semua kelas yang memancarkan event memakai pola yang sama:

```ts
const off = obj.on('event', handler);  // mengembalikan fungsi unsubscribe
obj.once('event', handler);
obj.off('event', handler);
```

## `TeleconfClient`

```ts
new TeleconfClient({ serverUrl, webUrl?, sessionStore?, device? })
```

| Anggota | Keterangan |
|---|---|
| `init(): Promise<User \| null>` | Pulihkan sesi tersimpan dan sambungkan |
| `user`, `token`, `isGuest` | Sesi saat ini |
| `connectionState` | `'disconnected' \| 'connecting' \| 'connected' \| 'reconnecting'` |
| `waitUntilConnected(ms?)` | Tunggu sampai koneksi realtime siap |
| `destroy()` | Tutup panggilan dan koneksi |
| `auth`, `users`, `admin`, `chat`, `calls`, `meetings`, `calendar`, `agenda`, `bookings`, `activity`, `media` | Modul-modul SDK |
| Event `session`, `sessionExpired`, `sessionRevoked`, `connection` | Lihat [auth.md](auth.md#event-klien) |

## `client.auth`

| Method | |
|---|---|
| `login(email, password)` | → `User`. Gagal: `unauthorized`, `unverified`, `inactive` |
| `loginWithGoogle(idToken)` | → `User` |
| `loginAsGuest(displayName)` | → `User` (guest, berlaku 12 jam) |
| `register(...)`, `verifyEmail(token)`, `resendVerification(email)` | |
| `forgotPassword(email)`, `resetPassword(token, password)` | |
| `me()` | Profil lengkap (dengan field HR dan `roles`) |
| `logout()` | Cabut sesi di server, lalu hapus data lokal |
| `sessions()` | → `DeviceSession[]` |
| `revokeSession(id)`, `revokeOtherSessions()` | |

## `client.users` / `client.admin`

| Method | |
|---|---|
| `users.search(q?)` | Organisasi sendiri saja; cari nama, username, email, NIK, jabatan, divisi |
| `users.get(id)` | Profil satu orang |
| `users.presence(ids)` | → `{ [id]: boolean }`; event `presence { userId, online }`; cache di `users.online` |
| `admin.updateUser(id, fields)` | hr_admin / it_admin |
| `admin.setActive(id, bool)` | Nonaktif = login diblokir dan semua sesi dicabut |
| `admin.sessions(id)`, `admin.revokeSessions(id)` | |

## `client.chat`

| Method | |
|---|---|
| `listConversations()` | → `ConversationSummary[]` (`unreadCount`, `hasUnread`, `pinned`, `mutedUntil`, `archived`, `markedUnread`, `myRole`) |
| `getConversation(id)`, `openDirect(userId)`, `createGroup(name, userIds, { description? })` | |
| `listMessages(id, { before?, limit? })` | → `ChatMessage[]` lama→baru |
| `subscribe(id)` → `unsubscribe()` | |
| `send(id, text \| SendMessageInput)` | `{ content, file, attachment, clientId, replyToId, mentions, type, data }` |
| `edit(msgId, text)` | ≤ 15 menit, milik sendiri |
| `deleteMessage(msgId, 'me' \| 'everyone')` | |
| `react(msgId, emoji \| null)` | |
| `star(msgId, bool)`, `starred()` | |
| `forward(msgId, convIds)` | Maks. 5 |
| `receipts(msgId)` | → `MessageReceipt[]` |
| `report({ messageId?, userId?, conversationId?, reason })` | |
| `pinMessage(convId, msgId \| null)` | |
| `search(q, { conversationId?, senderId?, hasAttachment?, limit? })` | → `{ messages, truncated }` |
| `listAttachments(id, 'media' \| 'file' \| 'link', { before?, limit? })` | |
| `setPreferences(id, prefs)`, `pin`, `mute`, `archive`, `markUnread` | |
| `addMember`, `removeMember`, `leaveGroup`, `updateGroup`, `setAdmin`, `transferOwnership`, `muteMember` | Lihat tabel peran di [chat.md](chat.md#grup-dan-peran) |
| `markRead(id, at?)`, `markDelivered(id, at?)` | `markDelivered` otomatis kecuali `autoDeliveryReceipts = false` |
| `setTyping`, `typingIndicator(id)` | |
| `uploadAttachment`, `attachmentUrl`, `downloadAttachment`, `titleOf` | |

Event: `message`, `notify`, `messageEdited`, `messageDeleted`, `messageHidden`, `reaction`, `typing`, `delivered`, `read`, `pinned`, `preferences`, `starred`, `groupUpdated`, `memberMuted`, `conversationAdded`, `conversationRemoved`, `memberAdded`, `memberRemoved`. Detail ada di [chat.md](chat.md#event).

## `client.calls` / `VoiceCall`

| | |
|---|---|
| `calls.start(conversationId, opts?)` | → `VoiceCall`. Gagal `call-ended` bila ditolak saat masih disiapkan |
| `calls.accept(invite \| conversationId, opts?)` | → `VoiceCall` |
| `calls.decline(invite \| conversationId)` | |
| `calls.active`, `calls.ringing` | |
| Event modul | `incoming`, `cancelled`, `declined`, `ended` |
| `call.state` | `'connecting' \| 'ringing' \| 'connected' \| 'reconnecting' \| 'ended'` |
| `call.participants` | `{ peerId, displayName, stream, muted, handRaised }` |
| `call.localStream`, `muted`, `handRaised`, `micUnavailable`, `connectedAt`, `isCaller`, `endReason` | |
| `setMuted`, `toggleMute`, `switchMicrophone`, `setOutgoingAudioTrack(track, replaceLocal?)`, `sendReaction`, `raiseHand`, `hangup` | |
| Event call | `state`, `participantJoined`, `participantLeft(p, 'left' \| 'disconnected')`, `participantUpdated`, `track`, `activeSpeaker`, `reaction`, `reconnecting`, `reconnected`, `micUnavailable`, `ended(reason)`, `error` |

`CallOptions`: `{ media?, muted?, ringTimeoutMs? = 45000, hangupWhenAlone? = true, autoReconnect? = true, reconnectTimeoutMs? = 30000 }`

## `client.meetings` / `Meeting`

`meetings`: `room(id)`, `create`, `startInstant`, `list`, `get`, `history`, `end`, `invite`, `link`, `parseLink`.

**Properti `Meeting`:** `roomId`, `state`, `self`, `participants`, `info`, `messages`, `polls`, `questions`, `whiteboard`, `waitingList`, `breakout`, `activeSpeakerId`, `localStream`, `screenStream`, `micUnavailable`, `elapsedSeconds`, `isModerator`.

**Siklus hidup:** `join(opts)`, `leave()`, `endForAll()`, `moveTo(roomId)` → `Meeting`

**Opsi `join`:** `displayName`, `pin`, `media`, `micEnabled`, `cameraEnabled`, `stopMediaOnLeave`, `autoReconnect`, `obeyModerator`, `simulcast`, `reportQuality`, `noiseSuppression`

**Media:** `setMicEnabled`, `setCameraEnabled`, `toggleMic`, `toggleCamera`, `switchMicrophone`, `switchCamera`, `setOutgoingVideoTrack`, `setOutgoingAudioTrack`, `replaceLocalTrack(kind, track)`, `startScreenShare`, `stopScreenShare`

**Interaksi:** `sendChat`, `sendReaction`, `raiseHand`, `setDisplayName`, `sendCaption`, `createPoll`, `votePoll`, `closePoll`, `askQuestion`, `upvoteQuestion`, `toggleAnswered`, `drawWhiteboard`, `clearWhiteboard`

**Moderasi:** `admit`, `admitAll`, `deny`, `setParticipantMic`, `setParticipantCamera`, `muteAll`, `kick`, `setCoHost`, `transferHost`, `setLocked`, `setPin`, `openBreakouts`, `closeBreakouts`, `broadcastToBreakouts`

**Event:** `state`, `lobby`, `joined`, `participantJoined`, `participantLeft`, `participantUpdated`, `track`, `trackRemoved`, `activeSpeaker`, `selfUpdated`, `localTrackChanged`, `chatMessage`, `reaction`, `handRaised`, `caption`, `pollAdded`, `pollUpdated`, `questionAdded`, `questionUpdated`, `whiteboardSegment`, `whiteboardCleared`, `lockChanged`, `pinChanged`, `hostChanged`, `waitingListChanged`, `moderatorRequest`, `breakoutOpened`, `breakoutClosed`, `breakoutMessage`, `quality`, `disconnected`, `reconnected`, `mediaError`, `left`, `error`. Detail ada di [meetings.md](meetings.md).

## `client.agenda` / `client.bookings` (kerangka Tahap 2)

| | |
|---|---|
| `agenda.list({ from, to })`, `get(id)`, `create(input)`, `update(id, changes)`, `cancel(id, { keepRoomBooking? })` | |
| `agenda.respond(id, 'yes' \| 'maybe' \| 'no', note?)` | |
| `agenda.freeBusy(userIds, from, to)` | |
| Event agenda | `invited`, `updated`, `cancelled`, `response` |
| `bookings.sites()`, `rooms(siteId, type?)`, `availability(siteId, 'YYYY-MM-DD')` | |
| `bookings.book(input)`, `mine()`, `cancel(id, { withEvent? })` | |

Detail ada di [agenda-booking.md](agenda-booking.md).

## `client.calendar`, `client.activity`, `client.media`, rekaman

Tidak berubah dari 0.1.0: lihat [calendar-activity.md](calendar-activity.md) dan [meetings.md §11](meetings.md#11-rekaman-lokal). Tambahan di rekaman: opsi `keepInMemory: false` (wajib bersama `onChunk`).

## Main process / Preload

`setupTeleconfMain(options)`, `ensureMediaAccess()`, `exposeTeleconfBridge()`. Lihat [electron-setup.md](electron-setup.md).

## Kode error (`TeleconfError.code`)

| Kode | Arti |
|---|---|
| `unauthorized` | Token tidak ada atau kedaluwarsa, atau password salah |
| `session-revoked` | Perangkat ini dikeluarkan (logout, dicabut, akun dinonaktifkan) |
| `inactive` | Akun dinonaktifkan |
| `unverified` | Login sebelum email diverifikasi |
| `forbidden` | Tidak diizinkan (bukan pemilik, bukan host, grup resmi HR, tamu) |
| `admins-only` | Khusus admin grup (termasuk mode pengumuman) |
| `muted` | Anda dibisukan admin grup |
| `read-only` | Kanal sistem |
| `edit-window` | Batas edit 15 menit sudah lewat |
| `not-found` | Room, percakapan, pesan, atau agenda tidak ada |
| `conflict` | Sudah ada / ruangan sudah dibooking (`details.bookedBy`) / sudah ada panggilan aktif |
| `bad-request` | Input tidak valid (termasuk file > 25 MB, teruskan > 5 chat) |
| `locked`, `pin`, `denied`, `breakout-closed` | Join meeting ditolak |
| `call-ended` | Panggilan berakhir (ditolak, dibatalkan) saat masih disiapkan |
| `timeout` | Server tidak menjawab tepat waktu |
| `not-connected` | Belum login, atau belum berada di dalam meeting |
| `network` | Server tidak terjangkau (cek URL dan CORS) |
| `unsupported` | Fitur butuh bridge/preload, atau tidak didukung platform |
| `server` | Error lain dari server (lihat `message`) |

`TeleconfError.details` berisi data tambahan dari server, misalnya `{ bookedBy, start, end }` untuk bentrok ruangan.
