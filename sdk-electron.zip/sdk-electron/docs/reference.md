# Referensi API

Semua tipe tersedia dari `@teleconf/electron-sdk` (TypeScript `.d.ts` ikut di paket). Semua method yang mengembalikan `Promise` gagal dengan `TeleconfError`.

Semua kelas yang memancarkan event memakai pola yang sama:

```ts
const off = obj.on('event', handler);  // mengembalikan fungsi unsubscribe
obj.once('event', handler);
obj.off('event', handler);
```

## `TeleconfClient`

```ts
new TeleconfClient({ serverUrl, webUrl?, sessionStore? })
```

| Anggota | Keterangan |
|---|---|
| `init(): Promise<User \| null>` | Pulihkan sesi tersimpan dan sambungkan |
| `user`, `token`, `isGuest` | Sesi saat ini |
| `connectionState` | `'disconnected' \| 'connecting' \| 'connected' \| 'reconnecting'` |
| `waitUntilConnected(ms?)` | Tunggu sampai koneksi realtime siap |
| `destroy()` | Tutup panggilan dan koneksi |
| `auth`, `users`, `chat`, `calls`, `meetings`, `calendar`, `activity`, `media` | Modul-modul SDK |
| Event `session`, `sessionExpired`, `connection` | Lihat [auth.md](auth.md#event-klien) |

## `client.auth` / `client.users`

| Method | |
|---|---|
| `login(email, password)` | → `User` |
| `loginWithGoogle(idToken)` | → `User` |
| `loginAsGuest(displayName)` | → `User` (guest, berlaku 12 jam) |
| `register({ email, username, password })` | Mengirim email verifikasi |
| `verifyEmail(token)`, `resendVerification(email)` | |
| `forgotPassword(email)`, `resetPassword(token, password)` | |
| `me()` | Profil terbaru dari server |
| `logout()` | |
| `users.search(query?)` | → `User[]` (tidak termasuk diri sendiri, maks 200) |

## `client.chat`

| Method | |
|---|---|
| `listConversations()` | → `ConversationSummary[]` (dengan `lastMessage`, `hasUnread`) |
| `getConversation(id)` | → `Conversation` |
| `openDirect(userId)` | → `Conversation` (1-on-1, dipakai ulang kalau sudah ada) |
| `createGroup(name, userIds)` | → `Conversation` |
| `addMember(id, userId)`, `removeMember(id, userId)`, `leaveGroup(id)` | |
| `listMessages(id, { before?, limit? })` | → `ChatMessage[]` lama→baru |
| `subscribe(id)` → `unsubscribe()`, `unsubscribe(id)` | Event realtime untuk satu thread |
| `send(id, text \| { content?, file?, fileName?, onProgress?, attachment? })` | → `ChatMessage` |
| `uploadAttachment(file, name?, onProgress?)` | → `Attachment` |
| `attachmentUrl(path)`, `downloadAttachment(path)` | |
| `markRead(id, at?)` | |
| `setTyping(id, bool)`, `typingIndicator(id)` → `{ keystroke, stop }` | |
| `titleOf(conversation)` | Judul untuk ditampilkan |

Event: `message`, `notify`, `typing`, `read`, `conversationAdded`, `conversationRemoved`, `memberAdded`, `memberRemoved`. Detail ada di [chat.md](chat.md#event).

## `client.calls` / `VoiceCall`

| | |
|---|---|
| `calls.start(conversationId, opts?)` | → `VoiceCall` |
| `calls.accept(invite \| conversationId, opts?)` | → `VoiceCall` |
| `calls.decline(invite \| conversationId)` | |
| `calls.active` | Panggilan yang sedang berjalan, atau `null` |
| `calls.ringing` | `Map` undangan yang belum dijawab |
| Event modul | `incoming`, `cancelled`, `declined`, `ended` |
| `call.state` | `'connecting' \| 'ringing' \| 'connected' \| 'ended'` |
| `call.participants`, `call.localStream`, `call.muted`, `call.connectedAt`, `call.isCaller` | |
| `call.setMuted(b)`, `toggleMute()`, `switchMicrophone(id)`, `hangup()` | |
| Event call | `state`, `participantJoined`, `participantLeft`, `track`, `activeSpeaker`, `ended(reason)`, `error` |

`CallOptions`: `{ media?, muted?, ringTimeoutMs? = 45000, hangupWhenAlone? = true }`

## `client.meetings`

| Method | |
|---|---|
| `room(roomId)` | → `Meeting` (belum join) |
| `create({ name, description?, scheduledAt?, durationMinutes? })` | → `Room` |
| `startInstant(name?)` | → `{ room, link }` |
| `list()`, `get(id)`, `history()` | |
| `end(id)`, `invite(id, emails)` | |
| `link(id)`, `parseLink(text)` | |

## `Meeting`

**Properti:** `roomId`, `state`, `self`, `participants` (Map), `info` (`{ roomId, isBreakout, breakout, locked, hasPin, pin, startedAt }`), `messages`, `polls`, `questions`, `whiteboard`, `waitingList`, `breakout` (`{ open, rooms, myRoom }`), `activeSpeakerId`, `localStream`, `screenStream`, `elapsedSeconds`, `isModerator`.

**Siklus hidup:** `join(opts)`, `leave()`, `endForAll()`, `moveTo(roomId)` → `Meeting`

**Media:** `setMicEnabled`, `setCameraEnabled`, `toggleMic`, `toggleCamera`, `switchMicrophone`, `switchCamera`, `setOutgoingVideoTrack`, `startScreenShare({ sourceId?, audio?, frameRate? })`, `stopScreenShare`

**Interaksi:** `sendChat(text, { file?, attachment?, onProgress? })`, `sendReaction(emoji)`, `raiseHand(bool)`, `setDisplayName(name)`, `sendCaption(text, isFinal)`, `createPoll`, `votePoll`, `closePoll`, `askQuestion`, `upvoteQuestion`, `toggleAnswered`, `drawWhiteboard`, `clearWhiteboard`

**Moderasi:** `admit`, `admitAll`, `deny`, `setParticipantMic`, `setParticipantCamera`, `muteAll`, `kick`, `setCoHost`, `transferHost`, `setLocked`, `setPin`, `openBreakouts`, `closeBreakouts`, `broadcastToBreakouts`

**Event:**

| Event | Payload |
|---|---|
| `state` | `MeetingState` |
| `lobby`, `joined`, `disconnected`, `reconnected` | — |
| `participantJoined` / `participantLeft` / `participantUpdated` | `Participant` |
| `track` / `trackRemoved` | `{ participant, source, track }` |
| `activeSpeaker` | `peerId \| null` |
| `selfUpdated` | `LocalParticipant` |
| `localTrackChanged` | `{ kind, track }` |
| `chatMessage` | `MeetingChatMessage` |
| `reaction` | `{ peerId, displayName, emoji }` |
| `handRaised` | `{ peerId, raised, raisedAt }` |
| `caption` | `{ peerId, displayName, text, isFinal }` |
| `pollAdded` / `pollUpdated` | `Poll` |
| `questionAdded` / `questionUpdated` | `Question` |
| `whiteboardSegment` / `whiteboardCleared` | `WhiteboardStroke` / — |
| `lockChanged` / `pinChanged` | `boolean` |
| `hostChanged` | `{ hostPeerId }` |
| `waitingListChanged` | `WaitingPeer[]` |
| `moderatorRequest` | `{ kind: 'mic' \| 'camera', enabled }` |
| `breakoutOpened` | `{ rooms, myRoom }` |
| `breakoutClosed` | `{ returnTo }` |
| `breakoutMessage` | `string` |
| `quality` | `'good' \| 'ok' \| 'poor'` |
| `left` | `LeaveReason` |
| `error` | `Error` (tidak fatal, misalnya gagal menerima satu track) |

### `Participant`

```ts
{
  peerId, displayName, isHost, isCoHost, micEnabled, cameraEnabled,
  handRaised, raisedAt, quality,                 // 'good' | 'ok' | 'poor' | null
  audioTrack, videoTrack, screenVideoTrack, screenAudioTrack,
  stream,        // MediaStream stabil: kamera + mic
  screenStream,  // MediaStream | null
}
```

`peerId` adalah id koneksi, dan berubah setiap kali seseorang bergabung ulang. Server tidak mengirim `userId` peserta lain.

## `client.calendar`

`list({ from?, to? })`, `month(year, month0)`, `week(date?)`, `upcoming(limit?)`, `schedule({ name, start, durationMinutes?, description?, inviteEmails? })`, `groupByDay(list)`, `toICS(meeting | meeting[])`. Setiap item bertipe `ScheduledMeeting = Room & { start: Date; end: Date }`.

## `client.activity`

`feed(filter?)` → `ActivityItem[]`, `unreadCount()`, event `changed`.

```ts
ActivityItem = { key, kind: 'meeting' | 'scheduled' | 'message', time: Date, title, text, unread,
                 target: { type: 'meeting', roomId } | { type: 'conversation', conversationId } }
```

## `client.media`

| Method | |
|---|---|
| `list()` | → `{ microphones, cameras, speakers }` (label kosong sebelum izin diberikan) |
| `onChange(cb)` | Perangkat dicolok atau dicabut |
| `getLocalStream({ audio?, video?, microphoneId?, cameraId? })` | Jatuh ke audio saja kalau kamera gagal dibuka |
| `setSpeaker(el, deviceId)` | |
| `getScreenSources({ types?, thumbnailSize? })` | → `ScreenSource[]` (perlu bridge) |
| `getDisplayStream({ sourceId?, audio?, frameRate? })` | |

## Rekaman

`new MeetingRecorder(stream, { passphrase?, onChunk?, timeslice? })` → `start()`, `stop(): Blob`, `recording`, `elapsed`, `encrypted`, `extension`. Juga tersedia `decryptRecording(blob, passphrase, onProgress?)`, `ENCRYPTED_EXTENSION`, dan `MIN_PASSPHRASE_LENGTH`.

## Main process (`@teleconf/electron-sdk/main`)

`setupTeleconfMain(options)` → `dispose()`, `ensureMediaAccess()` → `{ camera, microphone }`. Lihat [electron-setup.md](electron-setup.md#1-main-process).

## Preload (`@teleconf/electron-sdk/preload`)

`exposeTeleconfBridge()` memasang `window.teleconfBridge: TeleconfBridge`:

```ts
{
  session: { get(), set(session) },
  screen: { getSources(opts?), select(sourceId) },
  onDeepLink(cb): () => void,
  platform: string,
}
```

## Kode error (`TeleconfError.code`)

| Kode | Arti |
|---|---|
| `unauthorized` | Token tidak ada atau kedaluwarsa, atau password salah saat login |
| `unverified` | Login sebelum email diverifikasi |
| `forbidden` | Tidak diizinkan (bukan host, bukan anggota, atau sesi tamu) |
| `not-found` | Room/percakapan tidak ada, atau meeting sudah berakhir |
| `conflict` | Email/username sudah dipakai, atau sudah ada panggilan aktif |
| `bad-request` | Input tidak valid |
| `locked` | Meeting dikunci host |
| `pin` | Meeting butuh PIN, atau PIN salah |
| `denied` | Moderator menolak permintaan masuk |
| `breakout-closed` | Breakout sudah ditutup, atau Anda tidak ditugaskan ke sana |
| `timeout` | Server tidak menjawab tepat waktu |
| `not-connected` | Belum login, atau belum berada di dalam meeting |
| `network` | Server tidak terjangkau (cek URL dan CORS) |
| `unsupported` | Fitur butuh bridge/preload, atau tidak didukung platform |
| `server` | Error lain dari server (lihat `message`) |
