# Calendar & Activity

## Calendar

Calendar menampilkan **meeting terjadwal milik Anda**, yaitu meeting yang Anda buat dengan `scheduledAt`. Undangan ke meeting milik orang lain tidak muncul di sini, karena server tidak menyimpan daftar undangan.

```ts
const nov = await client.calendar.month(2026, 10);   // bulan 0-based → November 2026
const week = await client.calendar.week(new Date()); // minggu (mulai Minggu) yang berisi tanggal ini
const range = await client.calendar.list({ from, to });
const next = await client.calendar.upcoming(5);      // belum selesai, paling dekat dulu

// Setiap item: Room + { start: Date, end: Date }
for (const [day, items] of client.calendar.groupByDay(nov)) {
  renderDay(day /* 'YYYY-MM-DD' */, items);
}
```

### Menjadwalkan

```ts
const m = await client.calendar.schedule({
  name: 'Sprint review',
  description: 'Demo fitur Q4',
  start: new Date('2026-11-10T09:00:00+07:00'),
  durationMinutes: 90,
  inviteEmails: ['a@x.com'],      // opsional: undangan email langsung dikirim
});
```

### Ekspor ke kalender OS (`.ics`)

```ts
const ics = client.calendar.toICS(m);       // atau array meeting
// renderer → main via IPC milik Anda, lalu:
//   fs.writeFileSync(file, ics); shell.openPath(file);   // terbuka di Outlook / Calendar
```

File `.ics` berisi link join (perlu opsi `webUrl` di client).

### Mengingatkan sebelum meeting

SDK tidak menjadwalkan notifikasi; itu urusan aplikasi. Pola sederhana:

```ts
const soon = await client.calendar.upcoming(20);
for (const m of soon) {
  const ms = m.start.getTime() - Date.now() - 5 * 60_000;
  if (ms > 0) setTimeout(() => new Notification(`${m.name} mulai 5 menit lagi`), ms);
}
```

## Activity

Feed aktivitas dengan aturan yang sama seperti halaman Activity di web:

- meeting yang Anda ikuti dalam 30 hari terakhir (`kind: 'meeting'`)
- meeting terjadwal yang akan datang, atau yang lewat dalam 2 hari terakhir (`kind: 'scheduled'`)
- pesan terakhir di setiap percakapan (`kind: 'message'`, lengkap dengan status `unread`)

```ts
const items = await client.activity.feed();          // 'all' | 'meetings' | 'chats'
for (const it of items) {
  renderRow({ title: it.title, text: it.text, time: it.time, unread: it.unread });
  onClick(() =>
    it.target.type === 'meeting'
      ? openMeeting(it.target.roomId)
      : openChat(it.target.conversationId)
  );
}

// Muat ulang feed saat ada pesan baru, read receipt, atau panggilan selesai
client.activity.on('changed', debounce(reloadFeed, 500));
```

### Badge di taskbar / dock

```ts
const n = await client.activity.unreadCount();   // jumlah percakapan yang belum dibaca
// kirim ke main lewat IPC Anda: app.setBadgeCount(n) (macOS/Linux), win.setOverlayIcon(...) (Windows)
```

Feed ini tidak tersedia untuk sesi tamu.
