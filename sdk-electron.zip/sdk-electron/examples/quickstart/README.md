# Quickstart: aplikasi desktop minimal

Contoh paling kecil yang memakai `@teleconf/electron-sdk`: login, meeting (kamera, mic, share layar, lobby, breakout), notifikasi chat, telepon masuk, dan deep link `teleconf://room/<id>`.

```bash
cd sdk-electron && npm install && npm run build   # build SDK dulu
cd examples/quickstart
npm install
npm start
```

Atur `serverUrl` / `webUrl` di `src/renderer.ts`. Halaman dimuat lewat `loadFile`, jadi tambahkan `null` ke `CLIENT_ORIGIN` di backend (lihat [docs/electron-setup.md §4](../../docs/electron-setup.md#4-cors-wajib)).

| File | Isi |
|---|---|
| `main.js` | `setupTeleconfMain()` + jendela dengan preload siap pakai |
| `index.html` | UI polos |
| `src/renderer.ts` | Semua logika SDK |
