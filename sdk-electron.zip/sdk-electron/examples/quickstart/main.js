// Main process: one window, SDK helpers for media permissions, screen
// sharing, encrypted session storage and teleconf:// deep links.
const { app, BrowserWindow } = require('electron');
const path = require('node:path');
const { setupTeleconfMain, ensureMediaAccess } = require('@teleconf/electron-sdk/main');

if (!app.requestSingleInstanceLock()) app.quit();

app.whenReady().then(async () => {
  setupTeleconfMain({ deepLink: { scheme: 'teleconf' } });
  await ensureMediaAccess();

  const win = new BrowserWindow({
    width: 1280,
    height: 800,
    webPreferences: {
      // Ready-made preload — no bundling needed, works with sandbox: true.
      preload: require.resolve('@teleconf/electron-sdk/preload-script'),
      contextIsolation: true,
      sandbox: true,
    },
  });
  win.loadFile(path.join(__dirname, 'index.html'));
});

app.on('window-all-closed', () => app.quit());
