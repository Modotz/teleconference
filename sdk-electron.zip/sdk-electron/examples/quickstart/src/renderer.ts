import { TeleconfClient, TeleconfError, type Meeting, type Participant } from '@teleconf/electron-sdk';

// Point these at your deployment.
const client = new TeleconfClient({
  serverUrl: 'http://localhost:4000',
  webUrl: 'http://localhost:3000',
});

const $ = <T extends HTMLElement = HTMLElement>(id: string) => document.getElementById(id) as T;
const log = (msg: string) => ($('log').textContent = `${new Date().toLocaleTimeString()} ${msg}\n` + $('log').textContent);
const show = (id: 'login' | 'home' | 'meeting') =>
  (['login', 'home', 'meeting'] as const).forEach((s) => ($(s).hidden = s !== id));

let meeting: Meeting | null = null;
const tiles = new Map<string, HTMLVideoElement>();

// ------------------------------------------------------------ session

async function boot() {
  const user = await client.init();
  if (user) enterHome();
  else show('login');
}

client.on('sessionExpired', () => {
  log('Sesi berakhir, silakan login lagi');
  show('login');
});
client.on('connection', (s) => log(`realtime: ${s}`));

$('btnLogin').onclick = async () => {
  try {
    await client.auth.login($<HTMLInputElement>('email').value, $<HTMLInputElement>('password').value);
    enterHome();
  } catch (e) {
    log(`Login gagal: ${(e as TeleconfError).code} ${(e as Error).message}`);
  }
};

$('btnLogout').onclick = async () => {
  await client.auth.logout();
  show('login');
};

function enterHome() {
  $('who').textContent = `Halo, ${client.user?.username}`;
  show('home');
}

// ------------------------------------------- notifications & calls

client.chat.on('notify', ({ message }) => {
  new Notification(message.sender?.username ?? 'Pesan baru', { body: message.content || '📎 Lampiran' });
});

client.calls.on('incoming', async (invite) => {
  if (!confirm(`${invite.fromUsername} menelepon. Angkat?`)) return client.calls.decline(invite);
  const call = await client.calls.accept(invite);
  call.on('track', (p) => {
    const a = new Audio();
    a.autoplay = true;
    a.srcObject = p.stream;
  });
  call.on('ended', (r) => log(`telepon selesai: ${r}`));
});

// Opened from a teleconf://room/<id> link.
window.teleconfBridge?.onDeepLink((url) => {
  const id = client.meetings.parseLink(url);
  if (id && client.user) void joinMeeting(id);
});

// ------------------------------------------------------------ meeting

$('btnNew').onclick = async () => {
  const { room, link } = await client.meetings.startInstant('Meeting desktop');
  log(`Link: ${link ?? room.id}`);
  await joinMeeting(room.id);
};

$('btnJoin').onclick = () => {
  const id = client.meetings.parseLink($<HTMLInputElement>('joinLink').value);
  if (id) void joinMeeting(id);
  else log('Link tidak valid');
};

async function joinMeeting(roomId: string) {
  const m = client.meetings.room(roomId);
  wire(m);
  show('meeting');
  try {
    await m.join({ displayName: client.user?.username });
  } catch (e) {
    const code = (e as TeleconfError).code;
    log(`Gagal join: ${code}`);
    if (code === 'pin') {
      const pin = prompt('PIN meeting?');
      if (pin) {
        const retry = client.meetings.room(roomId);
        wire(retry);
        return retry.join({ pin });
      }
    }
    show('home');
  }
}

/** Attach UI listeners — called again after moveTo() (breakouts). */
function wire(m: Meeting) {
  meeting = m;
  m.on('state', (s) => ($('status').textContent = s));
  m.on('lobby', () => log('Menunggu diizinkan masuk oleh host…'));
  m.on('joined', () => {
    addTile('self', 'Anda', m.localStream, true);
    log(`Masuk sebagai ${m.self.isHost ? 'host' : 'peserta'}`);
  });
  m.on('localTrackChanged', () => {
    const v = tiles.get('self');
    if (v) v.srcObject = m.localStream;
  });
  m.on('participantJoined', (p) => addTile(p.peerId, p.displayName, p.stream, false));
  m.on('participantUpdated', (p) => updateTile(p));
  m.on('participantLeft', (p) => removeTile(p.peerId));
  m.on('activeSpeaker', (id) =>
    tiles.forEach((v, key) => (v.style.outline = key === id || (key === 'self' && id === m.self.peerId) ? '3px solid #22c55e' : ''))
  );
  m.on('waitingListChanged', (list) => list.forEach((w) => confirm(`${w.username} ingin masuk. Izinkan?`) ? m.admit(w.peerId) : m.deny(w.peerId)));
  m.on('chatMessage', (msg) => log(`💬 ${msg.username}: ${msg.content}`));
  m.on('breakoutOpened', async ({ myRoom }) => {
    if (myRoom) wireAfterMove(await m.moveTo(myRoom.boId));
  });
  m.on('breakoutClosed', async ({ returnTo }) => {
    if (m.info.isBreakout) wireAfterMove(await m.moveTo(returnTo));
  });
  m.on('left', (reason) => {
    if (reason === 'moved') return;
    log(`Keluar meeting: ${reason}`);
    tiles.forEach((_v, id) => removeTile(id));
    enterHome();
  });
}

function wireAfterMove(next: Meeting) {
  tiles.forEach((_v, id) => removeTile(id));
  wire(next);
  addTile('self', 'Anda', next.localStream, true);
  next.participants.forEach((p) => addTile(p.peerId, p.displayName, p.stream, false));
}

function addTile(id: string, name: string, stream: MediaStream | null, isSelf: boolean) {
  if (tiles.has(id)) return;
  const v = document.createElement('video');
  v.autoplay = true;
  v.playsInline = true;
  v.muted = isSelf; // never play your own mic back
  v.title = name;
  v.srcObject = stream;
  tiles.set(id, v);
  $('grid').appendChild(v);
}

function updateTile(p: Participant) {
  const v = tiles.get(p.peerId);
  if (!v) return;
  v.title = `${p.displayName}${p.micEnabled ? '' : ' (mute)'}${p.handRaised ? ' ✋' : ''}`;
  v.style.opacity = p.cameraEnabled && p.videoTrack ? '1' : '0.4';
}

function removeTile(id: string) {
  tiles.get(id)?.remove();
  tiles.delete(id);
}

$('btnMic').onclick = () => meeting?.toggleMic();
$('btnCam').onclick = () => meeting?.toggleCamera();
$('btnLeave').onclick = () => meeting?.leave();
$('btnShare').onclick = async () => {
  if (!meeting) return;
  if (meeting.screenStream) return meeting.stopScreenShare();
  const sources = await client.media.getScreenSources({ types: ['screen'] });
  if (sources[0]) await meeting.startScreenShare({ sourceId: sources[0].id });
};

window.addEventListener('beforeunload', () => void client.destroy());
void boot();

declare global {
  interface Window {
    teleconfBridge?: import('@teleconf/electron-sdk').TeleconfBridge;
  }
}
