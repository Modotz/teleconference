# @teleconf/electron-sdk

SDK lengkap untuk membangun **aplikasi desktop Teleconference dengan Electron**. Satu paket untuk semua fitur yang ada di versi web:

| Modul | Isi |
|---|---|
| `client.auth` | Login email/password, Google, tamu (guest), registrasi, verifikasi email, reset password, sesi per perangkat yang bisa dicabut |
| `client.users` / `client.admin` | Direktori per organisasi dengan profil HR, status online; administrasi HR/IT |
| `client.chat` | Chat 1-on-1 & grup: balas, teruskan, edit, hapus, reaksi, bintang, sematkan, laporkan, cari, status diterima/dibaca, jumlah belum dibaca, pengaturan per chat, admin grup & mode pengumuman, lampiran |
| `client.calls` | Voice call di dalam percakapan (1-on-1 / grup): sambung ulang otomatis, reaksi, angkat tangan, status mute |
| `client.meetings` | Buat/kelola meeting + **sesi meeting live**: kamera, mic, screen share, chat, reaksi, angkat tangan, lobby, moderasi, polling, Q&A, whiteboard, breakout room, caption |
| `client.calendar` | Meeting terjadwal per bulan/minggu, upcoming, ekspor `.ics` |
| `client.agenda` / `client.bookings` | Kerangka Tahap 2: agenda dengan peserta & jawaban, free/busy, booking ruangan per site |
| `client.activity` | Feed aktivitas (riwayat meeting, jadwal, pesan terakhir) + jumlah belum dibaca |
| `client.media` | Daftar perangkat, ganti mic/kamera/speaker, daftar layar/jendela untuk dibagikan |
| `MeetingRecorder` | Rekam lokal, opsional terenkripsi (kompatibel dengan halaman web `/recording/decrypt`) |

Ditambah helper khusus Electron:

- **`@teleconf/electron-sdk/main`**: izin kamera/mic otomatis, screen share (`getDisplayMedia`) dengan picker sendiri, penyimpanan sesi terenkripsi (`safeStorage`), deep link `teleconf://room/<id>`.
- **`@teleconf/electron-sdk/preload`**: bridge aman antara main dan renderer (aman dengan `contextIsolation` + `sandbox`).

Desktop dan web **saling kompatibel**: user desktop bisa meeting, chat, dan telepon dengan user web dalam room yang sama.

---

## Instalasi

```bash
npm install @teleconf/electron-sdk
```

Selama paket belum dipublikasikan ke registry, build dari repo lalu pasang lewat path:

```bash
cd sdk-electron && npm install && npm run build
# di proyek Electron:
npm install ../teleconference/sdk-electron
```

Butuh **Electron 28+**. `mediasoup-client` dan `socket.io-client` ikut terpasang otomatis.

## Mulai cepat (3 file)

**1. Main process** (`main.ts`)

```ts
import { app, BrowserWindow } from 'electron';
import path from 'node:path';
import { setupTeleconfMain, ensureMediaAccess } from '@teleconf/electron-sdk/main';

app.whenReady().then(async () => {
  setupTeleconfMain();          // izin media, screen share, sesi terenkripsi
  await ensureMediaAccess();    // macOS: minta izin kamera & mic

  const win = new BrowserWindow({
    width: 1280,
    height: 800,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      sandbox: true,
    },
  });
  win.loadFile('index.html');
});
```

**2. Preload** (`preload.ts`)

```ts
import { exposeTeleconfBridge } from '@teleconf/electron-sdk/preload';
exposeTeleconfBridge();
```

> Preload tidak di-bundle? Pakai file siap pakai:
> `preload: require.resolve('@teleconf/electron-sdk/preload-script')`.

**3. Renderer**

```ts
import { TeleconfClient } from '@teleconf/electron-sdk';

const client = new TeleconfClient({
  serverUrl: 'https://api.example.com',      // backend (tanpa /api)
  webUrl: 'https://meet.example.com',        // untuk link share meeting
});

// Pulihkan sesi tersimpan (login otomatis), atau login baru.
const user = (await client.init()) ?? (await client.auth.login(email, password));

// Chat
client.chat.on('notify', ({ message }) => new Notification(message.sender?.username ?? '', { body: message.content }));

// Telepon masuk
client.calls.on('incoming', async (invite) => {
  if (confirm(`${invite.fromUsername} menelepon`)) await client.calls.accept(invite);
  else client.calls.decline(invite);
});

// Meeting
const { room } = await client.meetings.startInstant('Daily standup');
const meeting = client.meetings.room(room.id);
meeting.on('participantJoined', (p) => renderTile(p));
await meeting.join({ displayName: user.username });
```

> ⚠️ **Wajib dibaca sebelum mulai:** backend menolak request dari origin yang tidak terdaftar (CORS).
> Tambahkan origin aplikasi desktop ke `CLIENT_ORIGIN` di server. Lihat [Setup Electron → CORS](docs/electron-setup.md#4-cors-wajib).

## Dokumentasi

| Dokumen | Isi |
|---|---|
| [Setup Electron](docs/electron-setup.md) | Main, preload, renderer, CORS, keamanan, screen share, deep link, packaging (macOS/Windows) |
| [Autentikasi & sesi](docs/auth.md) | Login, guest, Google, registrasi, penyimpanan sesi, sesi kedaluwarsa |
| [Chat](docs/chat.md) | Percakapan, pesan, lampiran, typing, read receipt, notifikasi |
| [Voice call](docs/calls.md) | Menelepon, menerima, menolak, mute, ganti mic |
| [Meeting](docs/meetings.md) | Join, lobby, media, layar, chat, moderasi, polling, Q&A, whiteboard, breakout, rekaman |
| [Agenda & Booking](docs/agenda-booking.md) | Kerangka Tahap 2: agenda, jawaban peserta, ruangan |
| [Calendar & Activity](docs/calendar-activity.md) | Jadwal, tampilan bulan/minggu, `.ics`, feed aktivitas, badge |
| [Referensi API](docs/reference.md) | Semua method, event, tipe data, kode error |
| [Troubleshooting](docs/troubleshooting.md) | Masalah umum dan solusinya |

Contoh aplikasi minimal: [`examples/quickstart`](examples/quickstart).

Riwayat perubahan: [CHANGELOG.md](CHANGELOG.md). Versi ini (0.2.0) membutuhkan server dengan migrasi `pasti_tahap1`.

## Build

```bash
npm install
npm run build       # dist/: index (renderer), main, preload, preload-script + .d.ts
npm run typecheck
```
