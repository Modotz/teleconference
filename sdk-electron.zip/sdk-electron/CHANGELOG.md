# Changelog

## 0.2.0: 13 November 2026

Butuh server dengan migrasi `20261113090000_pasti_tahap1` (`npx prisma migrate deploy`). Kode untuk tiap butir mengacu ke `ANALISIS_SDK.md` dan `PERTANYAAN_TIM_DEVELOPER.md` tim PASTI.

### Perbaikan bug
- **A1** Upload: batas 25 MB dicek sebelum mengirim; error 413 dan error proxy diberi pesan jelas. Server tidak lagi crash saat upload gagal.
- **A2** `VoiceCall`: listener dipasang sebelum `await` pertama. Penerima yang menjawab sangat cepat tidak lagi terlewat.
- **A3** Token bisa dicabut. `auth.logout()` mencabut sesi di server, dan token langsung tidak berlaku.
- **A4** `users.search()` hanya mengembalikan karyawan aktif dari organisasi yang sama.
- **A5** `VoiceCall` tersambung ulang otomatis (`reconnecting`/`reconnected`). `participantLeft` membedakan `left` dan `disconnected`.
- **A6** Panggilan yang ditolak saat masih disiapkan: mikrofon dilepas, socket ditutup, dan `calls.start()` gagal dengan kode `call-ended`.
- **A7** Server mengakhiri panggilan begitu peserta terakhir terputus. Panggilan kosong yang tertinggal tidak lagi menelan dering berikutnya.
- **A8** Semua anggota menerima `conversationAdded` saat grup dibuat.
- **A9** Mikrofon yang gagal dibuka tidak membatalkan rapat atau panggilan (`micUnavailable`, event `mediaError`/`micUnavailable`).
- **A10** `join({ cameraEnabled: false })` / `micEnabled: false` tidak membuka perangkatnya sama sekali.
- **A11** API umum `meeting.setOutgoingAudioTrack()`, `meeting.replaceLocalTrack()`, dan opsi `join({ noiseSuppression })`.
- **A12** `new MeetingRecorder(stream, { keepInMemory: false, onChunk })` tidak menimbun rekaman di memori.
- **A14** Masuk ruang diskusi tidak lagi ditolak server (foreign key `Participant_roomId_fkey`).
- **A15** `call.sendReaction()`, `call.raiseHand()`, event `reaction`.

### Baru: akun dan sesi
- `auth.sessions()`, `auth.revokeSession(id)`, `auth.revokeOtherSessions()`. Event klien `sessionRevoked`.
- Opsi klien `device` (default `{ deviceType: 'desktop' }`), dicatat per sesi.
- `users.get(id)`, profil karyawan (`fullName`, `nik`, `title`, `division`, `company`, `site`, `managerId`, `photoUrl`, `roles`).
- `users.presence(ids)` dan event `presence` (status online, tanpa "terakhir dilihat").
- `client.admin` (peran `hr_admin`/`it_admin`): `updateUser`, `setActive`, `sessions`, `revokeSessions`.

### Baru: chat
- `send()` menerima `clientId` (dibuat otomatis kalau tidak diisi, aman untuk kirim ulang), `replyToId`, `mentions`, `type` + `data`.
- `edit`, `deleteMessage(id, 'me' | 'everyone')`, `react`, `star` / `starred`, `forward` (maks. 5), `receipts`, `report`, `pinMessage`, `search`, `listAttachments`.
- Tanda diterima otomatis (`delivered`) dan `markDelivered()`.
- `ConversationSummary.unreadCount`, `pinned`, `mutedUntil`, `archived`, `markedUnread`, `myRole`. Helper `setPreferences`, `pin`, `mute`, `archive`, `markUnread`.
- Grup: peran owner/admin/member, `setAdmin`, `transferOwnership`, `muteMember`, `updateGroup` (nama, deskripsi, mode pengumuman). Pemilik bisa keluar, dan kepemilikan pindah otomatis.
- Pesan sistem tersimpan (`type: 'system'`, `data.event`).
- `notify` membawa `muted` dan `mentioned`.

### Baru: kerangka Tahap 2
- `client.agenda`: agenda Meeting/Aktivitas, online/offline/hybrid, peserta dan jawaban, free/busy.
- `client.bookings`: site, ruangan, ketersediaan, booking dengan pemeriksaan bentrok atomik.

### Perubahan perilaku
- `chat.titleOf()` memakai nama lengkap dari data HR bila ada.
- Menambah anggota grup sekarang khusus admin (PRD GRP-03).
- `ChatMessage` punya field baru. Pesan yang dihapus untuk semua datang dengan `type: 'deleted'` dan isi kosong.

## 0.1.0: 6 November 2026
Rilis pertama.
