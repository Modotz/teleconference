import { defineConfig } from 'tsup';

// JavaScript only — type declarations come from `tsc -p tsconfig.build.json`
// (tsup's dts bundler runs out of memory on Electron's type definitions).
export default defineConfig([
  // Renderer: pure browser code (WebRTC, fetch, socket.io). Bundled by the app.
  {
    entry: { index: 'src/index.ts' },
    format: ['esm', 'cjs'],
    platform: 'browser',
    clean: true,
    sourcemap: true,
  },
  // Main process + preload helpers. `electron` is provided by the runtime.
  {
    entry: { main: 'src/main/index.ts', preload: 'src/preload/index.ts' },
    format: ['esm', 'cjs'],
    platform: 'node',
    external: ['electron'],
    sourcemap: true,
  },
  // Drop-in preload file for apps that don't bundle their preload. Sandboxed
  // preloads may only require('electron'), so this must be a self-contained CJS.
  {
    entry: { 'preload-script': 'src/preload/script.ts' },
    format: ['cjs'],
    platform: 'node',
    external: ['electron'],
    sourcemap: true,
  },
]);
